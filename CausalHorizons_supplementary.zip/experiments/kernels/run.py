"""Kernels calculations for the causal-horizon experiments."""
from pathlib import Path
import csv
import gzip
import hashlib
import json
import platform
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'vendor'))
import finite_frontier as original

M=1.;B=.75;ALPHA=.05;T=24;REPS=1000;SEED=2026091901


def cells(periods,kappa,stress_h=0):
    length,group,cat=np.meshgrid(np.arange(periods+1),np.arange(2),np.arange(3),indexing='ij')
    length=length.ravel();group=group.ravel();cat=cat.ravel()
    x=2*group-1;y=np.array([-B,B,M])[cat]
    lp=np.where(length<periods,np.exp2(-length-1.),np.exp2(-float(periods)))
    py=np.where(cat==group,(1+kappa)/2,(1-kappa)/2)
    py=np.where(cat==2,0.,py)
    if stress_h:
        py=np.where(length>=stress_h,.85*py+.15*(cat==2),py)
    prob=.5*lp*py
    assert abs(prob.sum()-1)<1e-12
    h=np.arange(1,periods+1)
    indicator=(length[:,None]>=h).astype(float)
    ratios=indicator*np.exp2(h)
    return length,group,x,y,prob,indicator,ratios


def fit_group_means(counts,group,y):
    pred=[]
    for s in [0,1]:
        mask=group==s;num=counts[:,mask]@y[mask];den=counts[:,mask].sum(1)
        pred.append(np.divide(num,den,out=np.zeros_like(num),where=den>0))
    return np.clip(np.column_stack(pred),-M,M)


def score_moments(counts,group,y,ratios,pred):
    size=counts.sum(1)
    q=pred[:,group];res=y[None,:]-q
    sums=(counts*q).sum(1)[:,None]+(counts*res)@ratios
    sums2=(counts*q*q).sum(1)[:,None]+2*(counts*q*res)@ratios+(counts*res*res)@(ratios*ratios)
    mean=sums/size[:,None]
    variance=np.maximum(0,(sums2-size[:,None]*mean*mean)/(size[:,None]-1))
    return mean,variance


def conditional_moments(counts,y,indicator):
    size=counts@indicator;sy=(counts*y)@indicator;sy2=(counts*y*y)@indicator
    mean=np.divide(sy,size,out=np.zeros_like(sy),where=size>0)
    variance=np.divide(sy2-size*mean*mean,size-1,out=np.zeros_like(sy2),where=size>1)
    return mean,np.maximum(0,variance),size


def eb(variance,size,ranges,budget):
    ell=np.log(4/np.asarray(budget))
    size=np.asarray(size);valid=size>=2
    safe=np.maximum(size,2)
    width=np.sqrt(2*variance*ell/safe)+7*np.asarray(ranges)*ell/(3*(safe-1))
    return np.where(valid,width,np.inf)


def pilot(variance,size,ranges,epsilon,alpha,k0=0):
    reps,periods=variance.shape
    cap=np.full(reps,k0,dtype=int)
    size=np.broadcast_to(size,variance.shape)
    ranges=np.broadcast_to(ranges,(periods,))
    for k in range(1,periods+1):
        widths=eb(variance[:,:k],size[:,:k],ranges[:k],original.budgets(k,alpha))
        cap[np.all(widths<=epsilon,axis=1)]=np.maximum(k,cap[np.all(widths<=epsilon,axis=1)])
    return cap


def selected(variance,size,ranges,cap,epsilon,alpha,k0=0,allocation='geometric'):
    h=np.arange(1,variance.shape[1]+1)
    # Entries beyond the selected cap are not reported; keep their arithmetic
    # well-defined without changing any in-cap budget or decision.
    if allocation=='geometric':budget=alpha*np.exp2(np.minimum(h[None,:]-cap[:,None]-1.,-1.))
    elif allocation=='uniform':budget=alpha/np.maximum(cap[:,None],1)
    else:raise ValueError(allocation)
    widths=eb(variance,size,ranges,budget)
    inside=h[None,:]<=cap[:,None]
    good=(widths<=epsilon)&inside
    empirical=np.cumprod(good,axis=1).sum(1)
    return np.maximum(k0,empirical).astype(int),widths,inside


def checks():
    rng=np.random.default_rng(729)
    max_score=0.;max_variance=0.;max_formula=0.
    for kappa in [0.,.9,1.]:
        periods=6;l,s,x,y,p,ind,ratios=cells(periods,kappa)
        train=rng.multinomial(4096,p,size=3);valid=rng.multinomial(4096,p,size=3)
        pred=fit_group_means(train,s,y)
        tm,tv=score_moments(train,s,y,ratios,pred)
        vm,vv=score_moments(valid,s,y,ratios,pred)
        baseline=original.fallback(4096,periods,M,.2,ALPHA)
        caps=pilot(tv,4096,original.score_ranges(periods,M),.2,ALPHA/2,baseline)
        hh,ww,_=selected(vv,4096,original.score_ranges(periods,M),caps,.2,ALPHA/2,baseline)
        for rep in range(3):
            expanded=[]
            for counts in [train[rep],valid[rep]]:
                idx=np.repeat(np.arange(len(p)),counts)
                A=rng.integers(0,2,(len(idx),periods)).astype(float)
                for j,c in enumerate(idx):
                    A[j,:l[c]]=1
                    if l[c]<periods:A[j,l[c]]=0
                z=np.empty((len(idx),periods))
                for group in [0,1]:
                    mask=s[idx]==group
                    z[mask]=original.known_scores(A[mask],y[idx[mask]],(pred[rep,group],0.),M)
                expanded.append(z)
            max_score=max(max_score,float(np.max(abs(expanded[1].mean(0)-vm[rep]))))
            max_variance=max(max_variance,float(np.max(abs(expanded[1].var(0,ddof=1)-vv[rep]))))
            cap,k0=original.pilot_cap(expanded[0],4096,M,.2,ALPHA)
            assert cap==caps[rep] and k0==baseline
            est,width,h=original.evaluate_band(expanded[1],cap,M,.2,ALPHA,k0)
            assert h==hh[rep]
            np.testing.assert_allclose(width,ww[rep,:cap],rtol=1e-10,atol=1e-10)
        # Population variance with a training-fixed, possibly inaccurate predictor.
        a=.03;beta=kappa*B-.07;prediction=a+beta*x
        z=prediction[:,None]+ratios*(y-prediction)[:,None]
        expected=kappa*kappa*B*B+(np.exp2(np.arange(1,periods+1))-1)*(a*a+(beta-kappa*B)**2)+np.exp2(np.arange(1,periods+1))*B*B*(1-kappa*kappa)
        actual=p@(z*z)-(p@z)**2
        max_formula=max(max_formula,float(np.max(abs(actual-expected))))
    assert max_score<1e-9 and max_variance<1e-8 and max_formula<1e-10
    return dict(aggregated_mean_max_error=max_score,aggregated_variance_max_error=max_variance,
                population_variance_identity_max_error=max_formula,
                original_pilot_and_selector_agree=True)


def run():
    raw=[];summary=[];paired=[];start=time.time()
    def condition(n,kappa,stress_h,epsilons):
        l,s,x,y,p,ind,ratios=cells(T,kappa,stress_h)
        rng=np.random.default_rng(np.random.SeedSequence([SEED,n,round(100*kappa),stress_h]))
        N=n//2;train=rng.multinomial(N,p,size=REPS);valid=rng.multinomial(N,p,size=REPS)
        pred=fit_group_means(train,s,y)
        tm,tv=score_moments(train,s,y,ratios,pred)
        vm,vv=score_moments(valid,s,y,ratios,pred)
        im,iv=score_moments(train,s,y,ratios,np.zeros((REPS,2)))
        izm,izv=score_moments(valid,s,y,ratios,np.zeros((REPS,2)))
        cm,cv,cn=conditional_moments(train,y,ind)
        dm,dv,dn=conditional_moments(valid,y,ind)
        fm,fv,fn=conditional_moments(train+valid,y,ind)
        full_ipw=np.clip(((train+valid)*y)@ratios/n,-M,M)
        truth=np.zeros(T) if not stress_h else .15*M*np.minimum(1,np.exp2(np.arange(1,T+1)-stress_h))
        scope='stress' if stress_h else 'main'
        for epsilon in epsilons:
            k0=original.fallback(N,T,M,epsilon,ALPHA)
            cap=pilot(tv,N,original.score_ranges(T,M),epsilon,ALPHA/2,k0)
            methods=[]
            for label,allocation in [('original_localized','geometric'),('original_uniform_cap','uniform')]:
                h,width,inside=selected(vv,N,original.score_ranges(T,M),cap,epsilon,ALPHA/2,k0,allocation)
                methods.append((label,h,vm,width,inside,cap))
            zcap=pilot(iv,N,original.score_ranges(T,M),epsilon,ALPHA/2,k0)
            zh,zw,zi=selected(izv,N,original.score_ranges(T,M),zcap,epsilon,ALPHA/2,k0)
            methods.append(('ipw_localized_same_range',zh,izm,zw,zi,zcap))
            ccap=pilot(cv,cn,2*M,epsilon,ALPHA)
            ch,cw,ci=selected(dv,dn,2*M,ccap,epsilon,ALPHA)
            methods.append(('conditional_eb_cap_validation',ch,dm,cw,ci,ccap))
            fcap=np.full(REPS,T)
            fh,fw,fi=selected(fv,fn,2*M,fcap,epsilon,ALPHA,allocation='uniform')
            methods.append(('conditional_eb_uniform_full_data',fh,fm,fw,fi,fcap))
            fixed=max(0,min(T,int(np.floor(np.log2(n*epsilon**2/(3*M*M*np.log(4/ALPHA)))))))
            methods.extend([
                ('minimum_validation',np.full(REPS,k0),vm,None,None,np.full(REPS,k0)),
                ('fixed_ipw_full_data',np.full(REPS,fixed),full_ipw,None,None,np.full(REPS,fixed))])
            horizons={}
            for name,h,est,width,inside,cap_ in methods:
                chosen=np.arange(1,T+1)[None,:]<=h[:,None]
                error=np.max(np.where(chosen,abs(est-truth),0),axis=1)
                success=error<=epsilon+1e-12
                cover=None if width is None else np.all((abs(est-truth)<=width+1e-12)|~inside,axis=1)
                row=dict(scope=scope,n=n,T=T,kappa=kappa,stress_h=stress_h,epsilon=epsilon,method=name,reps=REPS,
                    mean_h=float(h.mean()),h_mcse=float(h.std(ddof=1)/np.sqrt(REPS)),fallback=k0,
                    mean_gain_over_fallback=float(h.mean()-k0),zero_horizon=float(np.mean(h==0)),
                    full_selection=float(np.mean(h==T)),selected_success=float(success.mean()),
                    candidate_coverage=float(cover.mean()) if cover is not None else None,
                    mean_cap=float(cap_.mean()),mean_selected_max_error=float(error.mean()))
                summary.append(row);horizons[name]=h
                for rep in range(REPS):
                    raw.append(dict(scope=scope,n=n,kappa=kappa,stress_h=stress_h,epsilon=epsilon,
                        method=name,replicate=rep,H=int(h[rep]),fallback=k0,cap=int(cap_[rep]),
                        selected_max_error=float(error[rep]),selected_success=bool(success[rep]),
                        candidate_coverage=bool(cover[rep]) if cover is not None else None))
            for other in horizons:
                if other=='original_localized':continue
                diff=horizons['original_localized']-horizons[other]
                paired.append(dict(scope=scope,n=n,kappa=kappa,stress_h=stress_h,epsilon=epsilon,
                    comparator=other,reps=REPS,mean_h_difference=float(diff.mean()),
                    difference_mcse=float(diff.std(ddof=1)/np.sqrt(REPS)),
                    fraction_original_longer=float(np.mean(diff>0)),fraction_equal=float(np.mean(diff==0))))
        print(f'{scope} n={n} kappa={kappa} stress_h={stress_h} elapsed={time.time()-start:.1f}s',flush=True)
    for n in [16384,65536,262144]:
        for kappa in [0.,.9,1.]:condition(n,kappa,0,[.2,.1,.05,.025])
    for stress_h in [4,8,12]:condition(65536,1.,stress_h,[.05])
    for filename,data in [('summary.csv',summary),('paired.csv',paired)]:
        with (OUT/filename).open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
    with gzip.open(OUT/'replicates.csv.gz','wt',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(raw[0]));writer.writeheader();writer.writerows(raw)
    return dict(summary_rows=len(summary),raw_rows=len(raw),elapsed_seconds=time.time()-start)


if __name__=='__main__':
    test=checks();(OUT/'checks.json').write_text(json.dumps(test,indent=2)+'\n');print(test,flush=True)
    meta=run()
    meta.update(date='2026-09-17',seed=SEED,reps=REPS,alpha=ALPHA,M=M,b=B,T=T,
        python=platform.python_version(),numpy=np.__version__,
        protocol_sha256=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest(),
        original_code_sha256=hashlib.sha256((ROOT/'vendor/finite_frontier.py').read_bytes()).hexdigest())
    (OUT/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
