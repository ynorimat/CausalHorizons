# Kernels

Exact multinomial trajectory categories and bounded-mean interval kernels. The code defines fair assignment, baseline groups, conditional moments, training-group means, and empirical Bernstein certificates. Settings and seeds are explicit in run.py. The main paper uses these functions through the experiment modules.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
