# Reporting

Compute reporting probabilities and necessary ceilings from all saved vanishing-noise records. Compare O and a fixed 17-bet mixture W on the same four-population datasets, with predictor, cap, split, support and error allocation fixed. The mixture is a diagnostic, not an optimized betting benchmark. All cells and failures to improve are retained.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
