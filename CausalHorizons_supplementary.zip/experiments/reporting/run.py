"""Reporting calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import importlib.util
import itertools
import json
import math
import os
import platform
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
spec = importlib.util.spec_from_file_location('comparison', PACKAGE/'binary/run.py')
comparison = importlib.util.module_from_spec(spec)
spec.loader.exec_module(comparison)
ALPHA, BETA, M, B = .05, .10, 1., .75
BETS = np.exp2(-np.arange(17, dtype=float))


def save_csv(path, rows):
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'wt', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def logwealth(values, counts, candidate):
    """Log of the fixed positive-bet mixture, one row per dataset."""
    logs = []
    delta = (values-candidate[:, None])/candidate[:, None]
    for bet in BETS:
        with np.errstate(divide='ignore', invalid='ignore'):
            lf = np.log1p(np.maximum(-1., bet*delta))
            terms = np.where(counts > 0, counts*lf, 0.)
        logs.append(terms.sum(axis=1))
    a = np.stack(logs, axis=1)
    top = a.max(axis=1)
    finite = np.isfinite(top)
    result = np.full(len(top), -np.inf)
    result[finite] = top[finite]+np.log(np.exp(a[finite]-top[finite, None]).mean(axis=1))
    return result


def lower_endpoint(values, counts, level):
    n = counts.sum(axis=1)
    mean = (values*counts).sum(axis=1)/n
    left = np.zeros(len(n))
    right = mean.copy()
    active = mean > 0
    for _ in range(42):
        mid = (left+right)/2
        candidate = np.where(active, mid, .5)
        rejected = active & (logwealth(values, counts, candidate) > np.log(2/level))
        left = np.where(rejected, mid, left)
        right = np.where(active & ~rejected, mid, right)
    # The excluded-side endpoint is conservative for the non-rejection set.
    return left


def betting_interval(values, counts, level):
    values = np.asarray(values, dtype=float)
    counts = np.asarray(counts, dtype=np.int64)
    level = np.broadcast_to(np.asarray(level, dtype=float), len(counts))
    assert np.all((values >= -1e-13) & (values <= 1+1e-13))
    assert np.all(counts >= 0) and np.all(counts.sum(axis=1) > 0)
    values = np.clip(values, 0., 1.)
    lower = lower_endpoint(values, counts, level)
    upper = 1-lower_endpoint(1-values, counts, level)
    mean = (counts*values).sum(axis=1)/counts.sum(axis=1)
    assert np.all(lower <= mean+1e-12) and np.all(upper >= mean-1e-12)
    return lower, upper


def score_histogram(counts, group, outcome, length, predictor, horizon):
    """Compress by score formula, independent of any outcome selection."""
    z, cc = [], []
    ratio = 2.**horizon
    for g in [0, 1]:
        outside = (group == g) & (length < horizon)
        z.append(predictor[:, g])
        cc.append(counts[:, outside].sum(axis=1))
        for y in np.unique(outcome[(group == g) & (length >= horizon)]):
            inside = (group == g) & (length >= horizon) & (outcome == y)
            z.append(predictor[:, g]+ratio*(y-predictor[:, g]))
            cc.append(counts[:, inside].sum(axis=1))
    return np.stack(z, axis=1), np.stack(cc, axis=1)


def frequent_horizon(horizons, grid):
    survival = np.array([np.mean(horizons >= h) for h in range(1, grid+1)])
    eligible = np.flatnonzero(survival >= 1-BETA)
    return int(eligible[-1]+1) if len(eligible) else 0


def ceilings(n, T, kappa, epsilon):
    d = 1-BETA-2*ALPHA
    exact = (2*epsilon/M)/(-math.expm1(math.log(BETA+2*ALPHA)/n))
    applicable = epsilon < B*(1-kappa)/4
    variance = B*B*(1-kappa*kappa)
    noise = 4*n*epsilon*epsilon/(variance*d*d) if applicable else None
    def horizon(x):
        return max(0, min(T, math.floor(math.log2(x))))
    kr = max([0]+[h for h in range(1, T+1)
                 if 7*(2*M*(2**(h+1)-1))*math.log(16/ALPHA)/(3*(n//2-1)) <= epsilon])
    fallback = comparison.old.original.fallback(n//2, T, M, epsilon, ALPHA)
    return dict(range_ceiling=horizon(exact), noise_applicable=applicable,
                noise_ceiling=horizon(noise) if applicable else '',
                information_ceiling=horizon(min(exact, noise)) if applicable else horizon(exact),
                selector_range_ceiling=max(kr, fallback), range_cap=kr,
                fallback=fallback, range_log2=math.log2(exact),
                noise_log2=math.log2(noise) if applicable else '')


def wilson(successes, n, z=1.959963984540054):
    p = successes/n
    center = (p+z*z/(2*n))/(1+z*z/n)
    half = z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return max(0., center-half), min(1., center+half)


def reporting(out):
    grouped = {}
    path = PACKAGE/'noise/results/vanishing_replicates.csv.gz'
    with gzip.open(path, 'rt', newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            key = (float(row['s']), int(row['n']), row['method'])
            grouped.setdefault(key, []).append(row)
    summary, curves = [], []
    for (s, n, method), rows in sorted(grouped.items()):
        assert len(rows) == 1000
        hh = np.array([int(r['H']) for r in rows])
        T, epsilon, kappa = int(rows[0]['T']), float(rows[0]['epsilon']), float(rows[0]['kappa'])
        base = dict(s=s, n=n, log2_n=int(math.log2(n)), T=T, kappa=kappa,
                    epsilon=epsilon, method=method)
        summary.append(dict(base, repetitions=len(rows), empirical_h90=frequent_horizon(hh, T),
                            mean_h=float(hh.mean()), **ceilings(n, T, kappa, epsilon)))
        for h in range(1, T+1):
            count = int(np.sum(hh >= h))
            lower, upper = wilson(count, len(rows))
            curves.append(dict(base, horizon=h, successes=count, repetitions=len(rows),
                               reporting_frequency=count/len(rows), wilson_lower=lower, wilson_upper=upper))
    save_csv(out/'reporting_summary.csv', summary)
    save_csv(out/'reporting_survival.csv', curves)
    return dict(source_sha256=sha(path), source_records=sum(map(len, grouped.values())),
                summary_rows=len(summary), survival_rows=len(curves))


def matched_betting(out):
    n, T, epsilon, reps, seed = 262144, 24, .025, 1000, 2026092503
    populations = [('noise', 0., 0), ('near', .99, 0), ('perfect', 1., 0), ('changing', 1., 6)]
    records, summary, paired = [], [], []
    for index, (name, kappa, d) in enumerate(populations):
        length, group, x, y, p, ind, ratios, truth = comparison.population(T, kappa, d)
        rng = np.random.default_rng(np.random.SeedSequence([seed, index]))
        train = rng.multinomial(n//2, p, size=reps)
        valid = rng.multinomial(n//2, p, size=reps)
        methods, fallback = comparison.evaluate(train, valid, group, y, ind, ratios, epsilon)
        ho, estimates, wo, inside, cap = methods['O']
        predictor = comparison.old.fit_group_means(train, group, y)
        wb = np.full_like(wo, np.inf)
        for h in range(1, int(cap.max())+1):
            ids = np.flatnonzero(cap >= h)
            values, counts = score_histogram(valid[ids], group, y, length, predictor[ids], h)
            support = M*(2**(h+1)-1)
            levels = (ALPHA/2)*np.exp2(h-cap[ids]-1.)
            lower, upper = betting_interval((values+support)/(2*support), counts, levels)
            low, high = 2*support*lower-support, 2*support*upper-support
            wb[ids, h-1] = np.maximum(estimates[ids, h-1]-low, high-estimates[ids, h-1])
        hw = np.maximum(fallback, np.cumprod((wb <= epsilon) & inside, axis=1).sum(axis=1)).astype(int)
        radii = {}
        horizons = {}
        for label, hh, widths in [('O', ho, wo), ('W', hw, wb)]:
            selected = np.arange(1, T+1)[None, :] <= hh[:, None]
            errors = np.max(np.where(selected, abs(estimates-truth), 0.), axis=1)
            accuracy = errors <= epsilon+1e-12
            coverage = np.all((abs(estimates-truth) <= widths+1e-12) | ~inside, axis=1)
            radius = np.max(np.where(selected, widths/epsilon, 0.), axis=1)
            at_oh = np.where(ho > 0, widths[np.arange(reps), np.maximum(ho-1, 0)]/epsilon, np.nan)
            base = dict(population=name, n=n, T=T, kappa=kappa, d=d, epsilon=epsilon, method=label)
            summary.append(dict(base, repetitions=reps, mean_h=float(hh.mean()),
                h_mcse=float(hh.std(ddof=1)/math.sqrt(reps)), empirical_h90=frequent_horizon(hh, T),
                selected_accuracy=float(accuracy.mean()), candidate_coverage=float(coverage.mean()),
                abstention=float(np.mean(hh == 0)), mean_max_radius_ratio=float(radius[hh > 0].mean()),
                radius_at_O_horizon_ratio=float(np.nanmean(at_oh)), error_q95=float(np.quantile(errors, .95))))
            for rep in range(reps):
                records.append(dict(base, replicate=rep, H=int(hh[rep]), cap=int(cap[rep]),
                    selected_max_error=float(errors[rep]), selected_success=bool(accuracy[rep]),
                    candidate_coverage=bool(coverage[rep]), max_radius_ratio=float(radius[rep]),
                    radius_at_O_horizon_ratio=float(at_oh[rep])))
            horizons[label], radii[label] = hh, at_oh
        hd, rd = horizons['W']-horizons['O'], radii['W']-radii['O']
        paired.append(dict(population=name, horizon_difference=float(hd.mean()),
            horizon_difference_mcse=float(hd.std(ddof=1)/math.sqrt(reps)),
            radius_ratio_difference=float(rd.mean()), radius_ratio_difference_mcse=float(rd.std(ddof=1)/math.sqrt(reps))))
        print(name, {x['method']:(x['mean_h'],x['radius_at_O_horizon_ratio']) for x in summary if x['population']==name}, flush=True)
    save_csv(out/'betting_summary.csv', summary)
    save_csv(out/'betting_paired.csv', paired)
    save_csv(out/'betting_replicates.csv.gz', records)
    # This study reconstructs existing datasets; they are not new independent evidence.
    inherited = list(csv.DictReader((PACKAGE/'budgets/results/summary.csv').open(encoding='utf-8')))
    for row in summary:
        if row['method'] == 'O':
            reference = next(x for x in inherited if x['population']==row['population'] and x['method']=='O')
            for field in ['mean_h','selected_accuracy','candidate_coverage','abstention']:
                assert row[field] == float(reference[field]), (row['population'],field)
    return dict(reused_datasets=4000, records=len(records), methods=2,
                original_O_summaries_reproduced=True)


def checks():
    rng = np.random.default_rng(2026092541)
    values = np.array([[.05,.2,.8,1.]])
    counts = np.array([[4,3,5,2]])
    expanded = np.repeat(values[0], counts[0])[None, :]
    expanded_counts = np.ones_like(expanded, dtype=int)
    log_errors = []
    for m in [.02,.15,.4,.7,.98]:
        one = logwealth(values, counts, np.array([m]))
        two = logwealth(expanded, expanded_counts, np.array([m]))
        log_errors.append(float(abs(one[0]-two[0])))
        np.testing.assert_allclose(one,two,atol=2e-12)
    a = betting_interval(values, counts, .05)
    b = betting_interval(expanded, expanded_counts, .05)
    np.testing.assert_allclose(a,b,atol=2e-12)
    # Enumerate all multisets from bounded ternary iid laws; this is an exact
    # finite-sample calculation, not a Monte Carlo assertion of validity.
    n, states, alpha = 6, np.array([0.,.3,1.]), .20
    cc = np.array([(i,j,n-i-j) for i in range(n+1) for j in range(n-i+1)])
    enumerated_multisets = len(cc)
    vv = np.broadcast_to(states, cc.shape)
    low, high = betting_interval(vv, cc, alpha)
    minimum_coverage = 1.
    for probabilities in [[.1,.2,.7],[.7,.2,.1],[.05,.9,.05],[.45,.1,.45]]:
        prob = np.array(probabilities)
        masses = np.array([math.factorial(n)/math.prod(math.factorial(int(k)) for k in row)*np.prod(prob**row) for row in cc])
        mean = float(states@prob)
        coverage = float(masses[(low <= mean) & (mean <= high)].sum())
        assert coverage >= 1-alpha-1e-12
        minimum_coverage = min(minimum_coverage,coverage)
    edge = betting_interval(np.array([[0.],[1.]]),np.array([[10],[10]]),.05)
    assert edge[0][0]==0 and edge[1][1]==1
    # Independently expanded trajectory scores check the category compression.
    length, group, x, y, p, ind, ratios, truth = comparison.population(4, .7)
    train = rng.multinomial(32, p, size=3)
    valid = rng.multinomial(32, p, size=3)
    predictor = comparison.old.fit_group_means(train, group, y)
    histogram_error = 0.
    for h in [1,2,4]:
        zz, cc = score_histogram(valid, group, y, length, predictor, h)
        support = M*(2**(h+1)-1)
        lo, hi = betting_interval((zz+support)/(2*support), cc, .05)
        for rep in range(3):
            ids = np.repeat(np.arange(len(p)), valid[rep])
            qq = predictor[rep, group[ids]]
            expanded_scores = qq+2.**h*(length[ids] >= h)*(y[ids]-qq)
            np.testing.assert_allclose((zz[rep]*cc[rep]).sum()/32,expanded_scores.mean(),atol=1e-12)
            a2,b2 = betting_interval(((expanded_scores+support)/(2*support))[None,:],
                                    np.ones((1,32),dtype=int),.05)
            histogram_error = max(histogram_error,abs(lo[rep]-a2[0]),abs(hi[rep]-b2[0]))
    assert histogram_error < 2e-12
    # Count and inverse-count moments entering the stratified proof.
    count_cases = 0
    for n in [2,4,8,16,32]:
        for h in [1,2,3]:
            p = 2.**(-h-1)
            mass = [math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(n+1)]
            threshold = n*2.**(-h-2)
            bad = sum(mass[j] for j in range(n+1) if j<threshold)
            assert bad <= math.exp(-n*2.**(-h)/16)+1e-12
            inverse = sum(mass[j]/j for j in range(2,n+1) if j>=threshold)
            assert inverse <= 4*2.**h/n+1e-12
            count_cases += 1
    ceiling_cases = 0
    for exponent in [14,20,26,32]:
        n=2**exponent
        for kappa in [0.,.9,.99,1.]:
            eps=n**(-.25)
            c=ceilings(n,exponent,kappa,eps)
            upper=c['range_ceiling']
            if upper<exponent:
                h=upper+1
                bound=2*ALPHA-math.expm1(n*math.log1p(-2*eps*2.**(-h)/M))
                assert bound<1-BETA
            ceiling_cases+=1
    return dict(aggregate_logwealth_max_error=max(log_errors),
        aggregate_interval_max_error=float(np.max(abs(np.array(a)-np.array(b)))),
        enumerated_distributions=4,enumerated_multisets=enumerated_multisets,minimum_coverage=minimum_coverage,
        endpoint_cases_passed=True,expanded_score_histogram_cases=9,
        expanded_score_interval_max_error=float(histogram_error),
        stratum_count_cases=count_cases,reporting_ceiling_cases=ceiling_cases)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    start=time.time()
    check=checks()
    (args.out/'checks.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf-8')
    if args.check:
        print(json.dumps(check,indent=2)); return
    protocol=sha(ROOT/'PROTOCOL.md')
    reporting_meta=reporting(args.out)
    betting_meta=matched_betting(args.out)
    assert sha(ROOT/'PROTOCOL.md')==protocol
    metadata=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),
        elapsed_seconds=time.time()-start,openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),
        omp_threads=os.getenv('OMP_NUM_THREADS'),protocol_sha256=protocol,source_sha256=sha(Path(__file__)),
        reporting=reporting_meta,betting=betting_meta)
    (args.out/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(metadata,indent=2),flush=True)


if __name__=='__main__':
    main()
