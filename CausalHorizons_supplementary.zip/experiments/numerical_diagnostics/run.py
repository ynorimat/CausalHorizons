"""Check reported tables and finite-sample calculations (standard library only).

Run from the supplement: python experiments/numerical_diagnostics/run.py --paper PATH
Add --write-tex to regenerate the two new manuscript fragments.
Original simulation records are read, never modified.
"""
from collections import defaultdict
import argparse
import csv
from decimal import Decimal, localcontext
import gzip
from itertools import product
import json
import math
from pathlib import Path
import statistics

HERE = Path(__file__).resolve().parent
EXP = HERE.parent


def rows(relative):
    with (EXP / relative).open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def audit_records(summary_path, records_path, keys, select=lambda row: True):
    summary = [r for r in rows(summary_path) if select(r)]
    groups = defaultdict(list)
    with gzip.open(EXP / records_path, 'rt', encoding='utf-8', newline='') as f:
        for r in csv.DictReader(f):
            if select(r):
                groups[tuple(r[k] for k in keys)].append(int(r['H']))
    assert len(groups) == len(summary)
    for r in summary:
        values = groups[tuple(r[k] for k in keys)]
        assert len(values) == int(r.get('reps', r.get('repetitions')))
        assert abs(statistics.mean(values) - float(r['mean_h'])) < 1e-12
        mcse = statistics.stdev(values) / math.sqrt(len(values))
        assert abs(mcse - float(r['h_mcse'])) < 1e-12
    return {'summary_rows': len(summary), 'records': sum(map(len, groups.values()))}


def finite_illustration():
    with localcontext() as ctx:
        ctx.prec = 60
        D = Decimal
        n, M, b, alpha, beta, T = D(2)**32, D(1), D('.75'), D('.05'), D('.10'), D(32)
        eps = D(1)/256
        ep = ((D(4)/alpha).ln()/(2*n)).sqrt()
        dp = ((D(4)/beta).ln()/(2*n)).sqrt()
        L = (8*T*17/alpha).ln()
        def lhs(m):
            return 2*b*ep + (M+2*b*(ep+dp))*(1-(-L/D(m)).exp()) + 2*M*D(2)**-25
        value = lhs(2932)
        assert lhs(2931) > eps > value
        tail = 2*(-D(4096-2932)**2/(2*4096)).exp()
        assert tail < beta/2
        return {k: str(v) for k,v in dict(m=2932, sufficient_lhs=value, tolerance=eps,
                margin=eps-value, previous_m_lhs=lhs(2931), chernoff_upper=tail).items()}


def drift_diagnostic():
    max_error = 0.
    # Enumerate both outcome signs and every action sequence. Directly form
    # the longitudinal DR sum before comparing to its closed form.
    for h in range(1, 9):
        for a in (0., .01, .1, .5):
            b = .5
            total = []
            for actions in product((0, 1), repeat=h):
                for y in (-.5, .5):
                    score, weight = b, 1.
                    for t, action in enumerate(actions):
                        weight *= action * 2*(1+a)
                        score += weight * ((y if t == h-1 else b) - b)
                    total.append(score)
            mean = math.fsum(total) / len(total)
            expected = -b*math.expm1(h*math.log1p(a))
            max_error = max(max_error, abs(mean-expected))
            assert math.isclose(mean, expected, rel_tol=1e-12, abs_tol=1e-12)
    result = []
    for exponent in (12, 20, 28):
        n, h = 2**exponent, exponent//2
        epsilon = n**(-.25)
        for u in (.125, .25, .5):
            a = n**(-u)
            drift = .5*math.expm1(h*math.log1p(a))
            result.append(dict(log2_n=exponent, h=h, u=u, a=a,
                epsilon=epsilon, drift=drift, drift_over_epsilon=drift/epsilon))
    return result, max_error


def table_fragment(data):
    header = r'''\begin{table}[t]\centering\small
\caption{Continuous nonlinear baseline study: mean report length (MCSE),
300 datasets per population. All eight tolerance cells are shown. A bare
integer has zero empirical MCSE. Methods share datasets within a cell;
O7/G8/L1/I use independent training and validation halves, while C/F use
all observations.}
\label{tab:continuous-summary}
\begin{tabular}{@{}ccc rrrrrr@{}}\toprule
$\log_2n$ & $\sigma$ & $\varepsilon$ & O7 & G8 & L1 & I & C & F\\\midrule
'''
    lines = []
    for n, sigma, eps in sorted({(int(r['n']),float(r['sigma']),float(r['epsilon'])) for r in data}):
        cells = [str(round(math.log2(n))), f'{sigma:g}', f'{eps:g}']
        for method in ('O7','G8','L1','I','C','F'):
            r, = [r for r in data if (int(r['n']),float(r['sigma']),float(r['epsilon']),r['method']) == (n,sigma,eps,method)]
            mean, se = float(r['mean_h']), float(r['h_mcse'])
            cells.append(f'{mean:.3f} ({se:.3f})' if se else f'{mean:g}')
        lines.append(' & '.join(cells) + r'\\')
    return header+'\n'.join(lines)+'\n'+r'\bottomrule\end{tabular}\end{table}'+'\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paper', type=Path)
    parser.add_argument('--write-tex', action='store_true')
    parser.add_argument('--out', type=Path, default=HERE/'results')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    audit = {}
    audit['continuous'] = audit_records('noise/results/continuous_summary.csv',
        'noise/results/continuous_replicates.csv.gz', ['n','sigma','epsilon','method'])
    audit['budgets'] = audit_records('budgets/results/summary.csv',
        'budgets/results/replicates.csv.gz', ['population','method'])
    audit['matched_betting'] = audit_records('betting/results/summary.csv',
        'betting/results/replicates.csv.gz', ['study','population','method'], lambda r:r['study']=='matched')
    interval = [r for r in rows('intervals/results/summary.csv') + rows('three_set/results/summary.csv')
                if r['method'] in ('C','S','A2','A3','C-B','S-B','A2-B','A3-B')]
    assert len(interval) == 288
    assert max(float(r['h_mcse']) for r in interval) <= .016
    assert all(float(r['h_mcse']) == 0 for r in interval if float(r['mean_h']).is_integer())
    action = [r for r in rows('action_adjustment/results/summary.csv') if r['study']=='matched']
    nonconstant = [(float(r['mean_h']), float(r['h_mcse'])) for r in action if float(r['h_mcse'])>0]
    assert len(nonconstant)==2
    assert all(abs(m-e)<1e-10 and abs(s-t)<.00005 for (m,s),(e,t) in zip(nonconstant,[(4.814,.0174),(6.020,.0063)]))
    audit['table_uncertainty'] = dict(interval_means=288, largest_interval_mcse=max(float(r['h_mcse']) for r in interval),
        action_nonzero_mcses=nonconstant, scope='Existing summaries; compact package omits these detailed interval/action records.')
    audit['perfect_prediction'] = finite_illustration()
    drift, error = drift_diagnostic()
    audit['drift'] = dict(enumeration_cases=32, maximum_absolute_error=error, grid_rows=len(drift),
        scope='Controlled deterministic nuisance perturbations, not fitted-propensity simulations.')
    with (args.out/'nuisance_drift.csv').open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(drift[0])); w.writeheader(); w.writerows(drift)
    selected = [r for r in drift if r['log2_n']==28]
    fragment = (r'For $M=1$, $n=2^{28}$, $h=14$, $\varepsilon_n=n^{-1/4}$ and'
        +'\n'+r'$a=n^{-u}$, the drift divided by tolerance is '+ '\n'
        + ', '.join(f"${r['drift_over_epsilon']:.3f}$" for r in selected)
        + r' for $u=1/8,1/4,1/2$, respectively.'+'\n')
    fragments = {'continuous_summary_table.tex': table_fragment(rows('noise/results/continuous_summary.csv')),
                 'nuisance_drift_values.tex': fragment}
    if args.paper:
        for filename, content in fragments.items():
            p = args.paper/'generated'/filename
            if args.write_tex: p.write_text(content, encoding='utf-8', newline='\n')
            assert p.read_text(encoding='utf-8') == content, filename
        audit['new_manuscript_fragments_match'] = True
    audit['all_passed'] = True
    (args.out/'checks.json').write_text(json.dumps(audit, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(audit, indent=2))


if __name__=='__main__': main()
