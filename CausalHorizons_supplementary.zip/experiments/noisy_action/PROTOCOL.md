# Noisy action-dependent theory checks

This module accompanies the general action-dependent attainment theorem
and the noisy growing-grid corollary. It is a set of numerical identity
and implementation checks, not an empirical performance study.

- Enumerate all action paths for T = 3, 5, 7, three baseline values with
  unequal probabilities, a nonlinear conditional outcome mean, and
  baseline/action-dependent symmetric residual noise. Compare the exact
  variance decomposition, mean, orthogonality and variance upper bound
  for the oracle, a nonlinear inaccurate predictor, and a clipped predictor.
  This gives 45 predictor/prefix cases.
- Enumerate the ordinary-risk counterexample for prefixes 1 through 12.
- Use the eight-row design containing both baseline signs and all four
  T = 2 action sequences. Enumerate all 256 binary response-noise vectors
  at kappa = 0, .7, .97. Check the exact conditional least-squares covariance,
  clipped prefix prediction risk, and its upper bound. Independently compare
  binomial integration against every action path at T = 2, 5, 7, including
  coefficients for which clipping is active.
- With seed 2026092611, draw three independent sets of equal size N = 2048
  or 16384, T = ceil(log2(3N)), kappa = 0, .8, .995, and Y = .3 V + .6 Abar.
  Use epsilon = (3N)^(-1/4), M = 1 and alpha = .05. Compare the candidate
  cap and selected prefix with direct exhaustive evaluation of the formulas;
  replace validation to check that it cannot affect the fit or pilot cap.
  These six cases are consistency checks, not estimates of coverage.

`run.py` includes a reference `evaluate` function for the three-set
certificate. Disjoint independent fitting, pilot and validation samples
are a caller requirement. The existing paired experiments in the paper
use two-set fitted pilots and are not relabeled as tests of this method.

Run `python experiments/noisy_action/run.py --out work/noisy_action` to
write diagnostics outside the saved results. `python reproduce.py check`
includes these checks; `python reproduce.py replay` regenerates and
compares the saved diagnostics. The supplied versions are Python 3.12
and NumPy 2.3.5. These checks are not independent formal proof verification.
