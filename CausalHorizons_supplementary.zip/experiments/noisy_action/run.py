"""Finite-support checks and a reference implementation for the three-set rule.

These checks validate numerical identities and implementation consistency;
they are not a performance study or a formal proof checker.
"""
from pathlib import Path
import argparse
import itertools
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parent


def actions(T):
    return np.array(list(itertools.product([0, 1], repeat=T)), dtype=float)


def integrate(coef, T, M=1.):
    """Exact integration of a clipped linear fit, for X=-1 and X=+1."""
    result = np.empty((2, T))
    for h in range(1, T+1):
        k = np.arange(T-h+1)
        prob = np.array([math.comb(T-h, int(j))*2.**(-(T-h)) for j in k])
        for g, x in enumerate([-1, 1]):
            pred = np.clip(coef[0]+coef[1]*x+coef[2]*(h+k)/T, -M, M)
            result[g, h-1] = prob @ pred
    return result


def fit(sample, M=1.):
    x, a, y = sample
    design = np.column_stack([np.ones(len(x)), x, a.mean(axis=1)])
    # NumPy returns the minimum-norm least-squares solution if singular.
    return np.linalg.lstsq(design, y, rcond=None)[0]


def scores(sample, coef, M=1.):
    x, a, y = sample
    T = a.shape[1]
    factual = np.clip(coef[0]+coef[1]*x+coef[2]*a.mean(axis=1), -M, M)
    policy = integrate(coef, T, M)[((x+1)//2).astype(int)]
    R = np.cumprod(a, axis=1)*2.**np.arange(1, T+1)
    return policy + R*(y-factual)[:, None]


def widths(variance, N, K, M=1., alpha=.05):
    h = np.arange(1, K+1)
    lam = math.log(16/alpha)+(K-h)*math.log(2)
    length = 2*M*(2.**(h+1)+1)
    return np.sqrt(2*variance[:K]*lam/N)+7*length*lam/(3*(N-1))


def select(pilot_variance, validation_variance, N, epsilon, M=1., alpha=.05):
    T = len(pilot_variance)
    fallback = max(0, min(T, math.floor(math.log2(
        N*epsilon**2/(10*M*M*math.log(8/alpha))))))
    K = fallback
    for k in range(1, T+1):
        if np.all(widths(pilot_variance, N, k, M, alpha) <= epsilon):
            K = max(K, k)
    radius = widths(validation_variance, N, K, M, alpha)
    H = max(fallback, int(np.cumprod(radius <= epsilon).sum()))
    return dict(cap=K, horizon=H, fallback=fallback, radius=radius)


def evaluate(fitting, pilot, validation, epsilon, M=1., alpha=.05):
    """Inputs must be three independently drawn, disjoint sets of equal size."""
    N = len(fitting[0])
    assert N >= 2 and len(pilot[0]) == len(validation[0]) == N
    assert 0 < epsilon <= M and 0 < alpha < 1
    coef = fit(fitting, M)
    pilot_z = scores(pilot, coef, M)
    valid_z = scores(validation, coef, M)
    selected = select(pilot_z.var(axis=0, ddof=1), valid_z.var(axis=0, ddof=1),
                      N, epsilon, M, alpha)
    return {**selected, 'coefficients': coef, 'means': valid_z.mean(axis=0)}


def check_variance():
    max_mean = max_variance = max_cross = 0.
    count = 0
    xs = np.array([-1., 0., 2.])
    px = np.array([.2, .3, .5])
    for T in [3, 5, 7]:
        a = actions(T)
        x = xs[:, None]
        f = .25*np.sin(x+a.sum(axis=1))+.15*x*a[:, 0]*a[:, -1]
        amplitude = .04+.04*x*x+.1*a[:, 1]
        y = f[:, :, None]+amplitude[:, :, None]*np.array([-1., 1.])
        assert np.max(abs(y)) < 1
        mass = np.broadcast_to(px[:, None, None]/(len(a)*2), y.shape)
        predictors = [f, np.tanh(.3*x+.4*a[:, 0]-.7*a[:, -1]),
                      np.clip(1.2*x+1.5*a[:, 0]*a[:, -1]-.7, -1, 1)]
        for fitted in predictors:
            e = fitted-f
            for h in range(1, T+1):
                mask = np.all(a[:, :h] == 1, axis=1)
                R = 2**h*mask
                v = fitted[:, mask].mean(axis=1)
                v_star = f[:, mask].mean(axis=1)
                e_bar = e[:, mask].mean(axis=1)
                z = v[:, None, None]+R[None, :, None]*(y-fitted[:, :, None])
                target = px @ v_star
                actual = np.sum(mass*(z-target)**2)
                noise = px @ (amplitude[:, mask]**2).mean(axis=1)
                risk = px @ (e[:, mask]**2).mean(axis=1)
                base_var = px @ (v_star-target)**2
                expected = base_var+2**h*(noise+risk)-px @ (e_bar**2)
                max_mean = max(max_mean, abs(np.sum(mass*z)-target))
                max_variance = max(max_variance, abs(actual-expected))
                terms = [np.broadcast_to((v_star-target)[:, None, None], y.shape),
                         R[None, :, None]*(y-f[:, :, None]),
                         np.broadcast_to((e_bar[:, None]-R*e)[:, :, None], y.shape)]
                for first, second in itertools.combinations(terms, 2):
                    max_cross = max(max_cross, abs(np.sum(mass*first*second)))
                assert actual <= 1+2**h*(noise+risk)+1e-10
                assert np.max(abs(z)) <= 2**(h+1)+1+1e-12
                count += 1
    assert max(max_mean, max_variance, max_cross) < 1e-10
    return dict(cases=count, max_mean_error=max_mean, max_variance_error=max_variance,
                max_orthogonality_error=max_cross)


def check_counterexample():
    err = 0.
    for m in range(1, 13):
        mask = np.all(actions(m) == 1, axis=1)
        z = 1-2**m*mask
        err = max(err, abs(z.mean()), abs(z.var()-(2**m-1)),
                  abs(np.mean(mask.astype(float)**2)-2.**(-m)))
    assert err < 1e-10
    return dict(prefixes=12, max_error=err)


def check_learned_risk():
    # Fixed full-rank fitting design, with every possible noisy response vector.
    T = 2
    a = np.tile(actions(T), (2, 1))
    x = np.repeat([-1., 1.], 2**T)
    N = len(x)
    design = np.column_stack([np.ones(N), x, a.mean(axis=1)])
    gram = design.T @ design/N
    assert np.linalg.eigvalsh(gram)[0] >= 1/(6*T)
    flips = 2*actions(N)-1
    max_covariance = max_integration = 0.
    max_risk_ratio = 0.
    for kappa in [0., .7, .97]:
        V = flips*x
        probability = np.prod(np.where(flips == 1, (1+kappa)/2, (1-kappa)/2), axis=1)
        np.testing.assert_allclose(probability.sum(), 1., atol=1e-12)
        Y = .3*V+.6*a.mean(axis=1)
        coefs = Y @ np.linalg.pinv(design).T
        truth_coef = np.array([0., .3*kappa, .6])
        errors = coefs-truth_coef
        cov = (errors*probability[:, None]).T @ errors
        sigma = .09*(1-kappa*kappa)
        expected = sigma*np.linalg.inv(gram)/N
        max_covariance = max(max_covariance, float(np.max(abs(cov-expected))))
        predictions = np.clip(coefs @ design.T, -1., 1.)
        conditional_risk = probability @ (predictions-design @ truth_coef)**2
        for h in range(1, T+1):
            mask = np.all(a[:, :h] == 1, axis=1)
            rho = conditional_risk[mask].mean()
            max_risk_ratio = max(max_risk_ratio, rho/(108*sigma*T/N))
            assert rho <= 108*sigma*T/N+1e-12
    for T in [2, 5, 7]:
        a = actions(T)
        for coef in [np.array([.1, .2, .6]), np.array([-2., 3., 4.])]:
            got = integrate(coef, T)
            for g, x_value in enumerate([-1., 1.]):
                factual = np.clip(coef[0]+coef[1]*x_value+coef[2]*a.mean(axis=1), -1, 1)
                for h in range(1, T+1):
                    mask = np.all(a[:, :h] == 1, axis=1)
                    max_integration = max(max_integration, abs(got[g, h-1]-factual[mask].mean()))
    assert max(max_covariance, max_integration) < 1e-10
    return dict(response_vectors=256, noise_levels=3,
                max_covariance_error=max_covariance, max_risk_to_bound_ratio=max_risk_ratio,
                max_integration_error=max_integration)


def draw(rng, N, T, kappa):
    x = rng.choice([-1., 1.], size=N)
    a = rng.integers(0, 2, size=(N, T)).astype(float)
    v = x*np.where(rng.random(N) < (1+kappa)/2, 1., -1.)
    return x, a, .3*v+.6*a.mean(axis=1)


def check_selector():
    rng = np.random.default_rng(2026092611)
    checked = 0
    for N in [2048, 16384]:
        n = 3*N
        T = math.ceil(math.log2(n))
        epsilon = n**(-.25)
        for kappa in [0., .8, .995]:
            fitting, pilot, validation = [draw(rng, N, T, kappa) for _ in range(3)]
            out = evaluate(fitting, pilot, validation, epsilon)
            co = out['coefficients']
            zp, zv = scores(pilot, co), scores(validation, co)
            pv, vv = zp.var(axis=0, ddof=1), zv.var(axis=0, ddof=1)
            def direct_radius(variance, h, cap):
                lam = math.log(16/.05)+(cap-h)*math.log(2)
                return math.sqrt(2*variance[h-1]*lam/N)+7*2*(2**(h+1)+1)*lam/(3*(N-1))
            k0 = out['fallback']
            feasible = [k for k in range(1, T+1)
                        if all(direct_radius(pv, h, k) <= epsilon for h in range(1, k+1))]
            K = max([k0]+feasible)
            passing = [k for k in range(1, K+1)
                       if all(direct_radius(vv, h, K) <= epsilon for h in range(1, k+1))]
            H = max([k0]+passing)
            assert K == out['cap'] and H == out['horizon']
            np.testing.assert_allclose(out['means'], zv.mean(axis=0), atol=1e-12)
            # Replacing validation must leave both fit and cap unchanged.
            other = evaluate(fitting, pilot, draw(rng, N, T, kappa), epsilon)
            np.testing.assert_array_equal(out['coefficients'], other['coefficients'])
            assert out['cap'] == other['cap']
            checked += 1
    return dict(seed=2026092611, three_set_cases=checked,
                cap_validation_separation=True, exhaustive_prefix_comparison=True)


def checks():
    return dict(variance=check_variance(), ordinary_risk_counterexample=check_counterexample(),
                learned_risk=check_learned_risk(), selector=check_selector())


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--out', type=Path, default=ROOT/'results')
    args = p.parse_args()
    result = checks()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'checks.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
