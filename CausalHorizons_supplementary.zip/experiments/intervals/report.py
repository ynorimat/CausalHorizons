"""Audit saved matched-interval summaries and finite-ceiling records."""
from pathlib import Path
import csv
import json

ROOT = Path(__file__).resolve().parent

def rows(path):
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

new = rows(ROOT/'results/summary.csv')
old = rows(ROOT.parent/'three_set/results/summary.csv')

def key(r):
    return r['law'], int(r['n']), float(r['tau']), r['tolerance']

index = {(key(r), r['method']): r for r in new + old}
conditions = 0
main_rows = 0
for law in ['additive', 'interaction']:
    for n in [6144, 49152, 393216]:
        for tau in [0., .05, .15]:
            for tol in ['fixed', 'shrinking']:
                k = (law, n, tau, tol)
                for method in ['C', 'S', 'A2', 'A3']:
                    for suffix in ['', '-B']:
                        float(index[k, method + suffix]['mean_h'])
                conditions += 1
                main_rows += n == 393216 and tol == 'fixed'
assert conditions == 36 and main_rows == 6
bounds = rows(ROOT/'theory_results/noise_grid.csv')
focused = rows(ROOT/'focused_results/summary.csv')
sb = next(r for r in focused if r['method'] == 'S-B')
assert len(bounds) == 40 and int(sb['h90']) == 19
checks = dict(conditions=conditions, main_rows=main_rows,
              noise_ceiling_rows=len(bounds), focused_S_betting_h90=int(sb['h90']),
              oracle_diagnostic_only=True)
(ROOT/'results/report_checks.json').write_text(
    json.dumps(checks, indent=2)+'\n', encoding='utf-8')
print(json.dumps(checks, indent=2))
