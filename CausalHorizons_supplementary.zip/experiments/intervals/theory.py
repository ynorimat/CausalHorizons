"""Explicit finite-sample bounds, numeric witnesses and validity checks."""
from pathlib import Path
import argparse, csv, json, math
import numpy as np
ROOT=Path(__file__).resolve().parent

def kl_bern(p,q):
    return (p*math.log(p/q) if p else 0)+((1-p)*math.log((1-p)/(1-q)) if p<1 else 0)

def response_at(lam,kappa,b=.75,M=1.):
    """KKT solution with fixed baseline weights and freely bounded responses."""
    ps=np.array([(1-kappa)/2,(1+kappa)/2]) # P(Y=+b | X=-1,+1)
    if lam==0:etas=np.ones(2)
    else:
        etas=[]
        for p in ps:
            if p==0:eta=1-lam*b
            elif p==1:eta=1+lam*b
            else:eta=(1+math.sqrt(1+4*(lam*b)**2+4*lam*b*(2*p-1)))/2
            etas.append(max(eta,lam*M))
        etas=np.asarray(etas)
    P=np.stack([1-ps,ps,np.zeros(2)],axis=1)
    ys=np.array([-b,b,M])
    Q=np.zeros((2,3))
    denom=etas[:,None]-lam*ys[None,:2]
    Q[:,:2]=P[:,:2]/denom
    Q[:,2]=1-Q[:,:2].sum(1)
    assert Q.min()>-2e-14
    Q[:,2]=np.maximum(Q[:,2],0)
    D=float(np.sum(np.where(P[:,:2]>0,P[:,:2]*np.log(denom),0))/2)
    mean=float((Q@ys).mean())
    return mean,D,P,Q,etas

def projection(kappa,epsilon,b=.75,M=1.):
    assert 0<2*epsilon<M and 0<=kappa<=1
    lo=0.;hi=1.
    while response_at(hi,kappa,b,M)[0]<2*epsilon:hi*=2
    for _ in range(90):
        mid=(lo+hi)/2
        if response_at(mid,kappa,b,M)[0]<2*epsilon:lo=mid
        else:hi=mid
    lam=hi
    mean,D,P,Q,eta=response_at(lam,kappa,b,M)
    return dict(mean=mean,divergence=D,lam=lam,P=P.tolist(),Q=Q.tolist(),eta=eta.tolist())

def old_ceiling(n,kappa,eps,T,b=.75,M=1.,alpha=.05,beta=.1):
    ran=(2*eps/M)/(-math.expm1(math.log(beta+2*alpha)/n))
    if eps < b*(1-kappa)/4:
        noise=4*n*eps**2/(b*b*(1-kappa*kappa)*(1-beta-2*alpha)**2)
        ran=min(ran,noise)
    return max(0,min(T,math.floor(math.log2(ran))))

def binom_cdf(k,n,p):
    """Exact finite sum evaluated in log scale; intended for small rare counts."""
    if k<0:return 0.
    if k>=n:return 1.
    logp=n*math.log1p(-p)
    logs=[logp]
    for j in range(1,k+1):
        logp+=math.log(n-j+1)-math.log(j)+math.log(p)-math.log1p(-p)
        logs.append(logp)
    top=max(logs)
    if top < -750:return 0.
    return min(1.,math.exp(top)*math.fsum(math.exp(z-top) for z in logs))

def sufficient(n,eps,T,b=.75,M=1.,alpha=.05,beta=.1):
    ep=math.sqrt(math.log(4/alpha)/(2*n))
    dp=math.sqrt(math.log(4/beta)/(2*n)) # fail prob beta/2
    # Match the 25-step excluded-side endpoint inversion in run.py.
    numerical_padding=2*M*2.**(-25)
    residual=eps-2*b*ep-numerical_padding
    if residual<=0:return dict(h90_sufficient=0,min_group_count=None)
    amplitude=M+2*b*(ep+dp)
    L=math.log(8*T*17/alpha)
    needed=math.ceil(L/(-math.log1p(-residual/amplitude)))
    # Baseline proportion failure beta/2; two group tails share beta/2.
    feasible=[]
    for h in range(1,T+1):
        failure=2*binom_cdf(needed-1,n,2.**(-h-1))
        if failure<=beta/2:feasible.append(h)
    return dict(h90_sufficient=max([0]+feasible),min_group_count=needed,baseline_width=2*b*ep,conditional_range_amplitude=amplitude)

def checks():
    max_error=0.;max_duality_gap=0.;rng=np.random.default_rng(2026092615)
    witnesses=[]
    for k in [0,.5,.9,.99,1.]:
        for eps in [.001,.025,.1,.3]:
            res=projection(k,eps);P=np.array(res['P']);Q=np.array(res['Q']);eta=np.array(res['eta']);lam=res['lam']
            max_error=max(max_error,abs(res['mean']-2*eps),float(np.max(abs(Q.sum(1)-1))))
            direct=math.fsum(float(p)*math.log(float(p/q))/2 for p,q in zip(P.flat,Q.flat) if p>0)
            max_error=max(max_error,abs(direct-res['divergence']))
            dual=res['divergence']+1-eta.mean()+lam*2*eps
            max_duality_gap=max(max_duality_gap,abs(dual-res['divergence']))
            # Off-support KKT coefficient nonnegative for all bounded outcomes.
            assert min(eta-lam)>=-1e-12
            assert np.max(abs(Q[:,2]*(eta-lam)))<1e-12
            # A larger target must not reduce the minimum divergence.
            if eps<.3:assert projection(k,eps*1.1)['divergence']>res['divergence']
            witnesses.append(dict(kappa=k,epsilon=eps,**res))
    # Closed forms in their interior regimes, independently of the optimizer.
    for eps in [.001,.025,.1]:
        np.testing.assert_allclose(projection(0,eps)['divergence'],-.5*math.log1p(-4*eps**2/.75**2),rtol=1e-9)
        np.testing.assert_allclose(projection(1,eps)['divergence'],-.5*math.log1p(-4*eps/1.75),rtol=1e-10)
    # Finite binomial sums agree with direct enumerations at small n.
    for n in [5,20,70]:
        for p in [.01,.1,.5]:
            for k in [0,n//4,n//2]:
                exact=math.fsum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in range(k+1))
                max_error=max(max_error,abs(exact-binom_cdf(k,n,p)))
    assert max_error<1e-11 and max_duality_gap<1e-11
    return dict(max_identity_error=max_error,max_primal_dual_gap=max_duality_gap,witness_cases=len(witnesses),closed_forms_checked=True,binomial_sums_checked=True),witnesses

def run(out=None):
    out=ROOT/'theory_results' if out is None else out;out.mkdir(parents=True,exist_ok=True)
    check,witnesses=checks();C=kl_bern(.85,.05)
    rows=[]
    for n,T in [(49152,16),(393216,19),(2**32,32)]:
        eps=.025 if n<2**32 else n**(-.25)
        for kappa in [0,.99,math.sqrt(1-.25*n**(-.25)),1.]:
            pr=projection(kappa,eps)
            # Explicit feasible witnesses with strictly separated targets.
            # The padding rounds the witness divergence conservatively upward.
            upper_D=projection(kappa,eps*(1+1e-9))['divergence']+1e-11
            new=max(0,min(T,math.floor(math.log2(n*upper_D/C))))
            reduced=projection(0,eps*(1+1e-9))['divergence']+1e-11
            red_h=max(0,min(T,math.floor(math.log2(n*reduced/C))))
            rows.append(dict(n=n,T=T,epsilon=eps,kappa=kappa,old_necessary_h90=old_ceiling(n,kappa,eps,T),new_necessary_h90=new,response_projection=pr['divergence'],witness_divergence_upper=upper_D,event_kl_constant=C,reduced_data_necessary_h90=red_h,**(sufficient(n,eps,T) if kappa==1 else dict(h90_sufficient='',min_group_count='',baseline_width='',conditional_range_amplitude=''))))
    with (out/'bounds.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'checks.json').write_text(json.dumps(check,indent=2)+'\n')
    (out/'witnesses.json').write_text(json.dumps(witnesses,indent=2)+'\n')
    figure=projection(math.sqrt(1-.25*(2**32)**(-.25)),(2**32)**(-.25)*(1+1e-9))
    (out/'figure_witness.json').write_text(json.dumps(figure,indent=2)+'\n')
    grid=[]
    for rate in [0.,.125,.25,.5]:
        for exponent in range(14,33,2):
            n=2**exponent;eps=n**(-.25);kappa=math.sqrt(1-.25*n**(-rate))
            witness=projection(kappa,eps*(1+1e-9))
            D=witness['divergence']+1e-11
            ceiling=max(0,min(exponent,math.floor(math.log2(n*D/C))))
            grid.append(dict(s=rate,n=n,log2_n=exponent,kappa=kappa,epsilon=eps,
                             necessary_ceiling=ceiling,witness_divergence_upper=D))
    with (out/'noise_grid.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(grid[0]));w.writeheader();w.writerows(grid)
    print(json.dumps(dict(checks=check,grid_rows=len(grid)),indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path);run(p.parse_args().out)
