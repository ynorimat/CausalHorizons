"""Paired fixed-mixture interval comparison."""
from pathlib import Path
import os
os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
import argparse, csv, gzip, hashlib, importlib.util, json, math, time
import numpy as np

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj)
    return obj
ref=module('three_set_ref',SOURCE/'three_set/run.py')
oldbet=module('betting_ref',SOURCE/'reporting/run.py')
ALPHA=.05
BETS=2.**(-np.arange(17))

def logwealth(values,counts,candidate):
    """Candidate strictly inside (0,1); zero counts remove impossible cells."""
    delta=(values-candidate[:,None])/candidate[:,None]
    acc=np.full(len(counts),-np.inf)
    for bet in BETS:
        with np.errstate(divide='ignore',invalid='ignore'):
            v=np.log1p(np.maximum(-1,bet*delta))
            part=np.where(counts>0,counts*v,0).sum(1)
        acc=np.logaddexp(acc,part)
    return acc-math.log(len(BETS))

def endpoints(values,counts,level,steps=25):
    count=counts.sum(1)
    mean=(values*counts).sum(1)/np.maximum(count,1)
    def lower(v,mu):
        left=np.zeros(len(count));right=mu.copy()
        active=(mu>0)&(count>0)
        for _ in range(steps):
            mid=(left+right)/2
            candidate=np.where(active,mid,.5)
            rejected=active&(logwealth(v,counts,candidate)>np.log(2/level))
            left=np.where(rejected,mid,left)
            right=np.where(active&~rejected,mid,right)
        return left
    return lower(values,mean),1-lower(1-values,1-mean),mean

def evidence(values,counts,epsilon):
    n=counts.sum(1)
    mean=(values*counts).sum(1)/np.maximum(n,1)
    low=mean-epsilon;high=mean+epsilon
    l=logwealth(values,counts,np.where(low>0,low,.5))
    u=logwealth(1-values,counts,np.where(high<1,1-high,.5))
    ev=np.minimum(np.where(low>0,l,np.inf),np.where(high<1,u,np.inf))
    return np.where(n>0,ev,-np.inf),mean

def cover(values,counts,target,level):
    target=np.broadcast_to(np.asarray(target),len(counts))
    # All targets in this study are strictly inside the certified range.
    assert np.all((target>0)&(target<1))
    return (logwealth(values,counts,target)<=np.log(2/level)) & (logwealth(1-values,counts,1-target)<=np.log(2/level))

def outcome_hist(counts,pop,h,g=None):
    mask=pop['ell']>=h
    if g is not None:mask &= pop['x']==g
    vals=np.unique(pop['y'][mask])
    cc=np.stack([counts[:,mask&(pop['y']==y)].sum(1) for y in vals],axis=1)
    return np.broadcast_to((vals[None,:]+1)/2,cc.shape),cc

def score_hist(counts,pop,coef,q,h):
    # Outside-prefix scores depend only on X; inside scores on (X,U,E).
    vals=[];cc=[];scale=2.**h
    for gi,x in enumerate([-1,1]):
        out=(pop['x']==x)&(pop['ell']<h)
        vals.append(q[:,gi,h-1]);cc.append(counts[:,out].sum(1))
        for total in range(h,pop['T']+1):
            for e in [-1,1]:
                mask=(pop['x']==x)&(pop['ell']>=h)&(pop['total']==total)&(pop['e']==e)
                if not np.any(mask):continue
                ix=np.flatnonzero(mask)[0]
                fitted=np.clip(coef@pop['design'][ix],-1,1)
                z=q[:,gi,h-1]+scale*(pop['y'][ix]-fitted)
                vals.append(z);cc.append(counts[:,mask].sum(1))
    values=np.stack(vals,axis=1);cc=np.stack(cc,axis=1)
    bound=2.**(h+1)+1
    assert np.all(abs(values)<=bound+1e-10)
    return (values+bound)/(2*bound),cc,bound

def full_methods(counts,pop,epsilons):
    R,T=len(counts),pop['T'];n=int(counts[0].sum())
    phat=counts[:,pop['x']==1].sum(1)/n
    pe=math.sqrt(math.log(4/ALPHA)/(2*n))
    pl,pu=np.maximum(0,phat-pe),np.minimum(1,phat+pe)
    output={}
    for method in ['C-B','S-B']:
        good=np.zeros((R,T,len(epsilons)),bool)
        means=np.zeros((R,T));covered=np.ones(R,bool)
        checked=np.zeros((R,T),bool)
        active=np.ones(R,bool)
        for h in range(1,T+1):
            ids=np.flatnonzero(active)
            if not len(ids):break
            checked[ids,h-1]=True
            if method=='C-B':
                v,c=outcome_hist(counts[ids],pop,h)
                for j,eps in enumerate(epsilons):
                    ev,mu=evidence(v,c,eps/2)
                    good[ids,h-1,j]=ev>math.log(2*T/ALPHA)
                means[ids,h-1]=2*mu-1
                covered[ids]&=cover(v,c,(pop['truth'][h-1]+1)/2,ALPHA/T)
            else:
                lows=[];highs=[];mus=[]
                for g in [-1,1]:
                    v,c=outcome_hist(counts[ids],pop,h,g)
                    low,high,mu=endpoints(v,c,ALPHA/(4*T))
                    lows.append(2*low-1);highs.append(2*high-1);mus.append(np.where(c.sum(1)>0,2*mu-1,0))
                mu=(1-phat[ids])*mus[0]+phat[ids]*mus[1]
                lo=np.minimum((1-pl[ids])*lows[0]+pl[ids]*lows[1],(1-pu[ids])*lows[0]+pu[ids]*lows[1])
                hi=np.maximum((1-pl[ids])*highs[0]+pl[ids]*highs[1],(1-pu[ids])*highs[0]+pu[ids]*highs[1])
                rad=np.maximum(mu-lo,hi-mu)
                for j,eps in enumerate(epsilons):good[ids,h-1,j]=rad<=eps
                means[ids,h-1]=mu
                covered[ids]&=(lo<=pop['truth'][h-1])&(hi>=pop['truth'][h-1])
            active &= good[:,h-1,int(np.argmax(epsilons))]
        output[method]=[dict(H=np.cumprod(good[:,:,j],axis=1).sum(1),cap=np.full(R,T),means=means,covered=covered,checked=checked.sum(1),fallback=0) for j in range(len(epsilons))]
    return output

def split_method(blocks,pop,name,epsilons,coef):
    R,T=len(blocks[0]),pop['T'];q=ref.integrate(coef,T)
    if name=='A2':pilot=blocks[0]+blocks[1]+blocks[2];valid=blocks[3]+blocks[4]+blocks[5]
    else:pilot=blocks[2]+blocks[3];valid=blocks[4]+blocks[5]
    N=int(valid[0].sum())
    pe=np.empty((R,T,len(epsilons)));ve=np.empty_like(pe)
    means=np.empty((R,T));null_ev=np.empty((R,T))
    for h in range(1,T+1):
        for kind,counts in [('pilot',pilot),('valid',valid)]:
            v,c,bound=score_hist(counts,pop,coef,q,h)
            for j,eps in enumerate(epsilons):
                ev,mu=evidence(v,c,eps/(2*bound))
                (pe if kind=='pilot' else ve)[:,h-1,j]=ev
            if kind=='valid':
                means[:,h-1]=(2*mu-1)*bound
                target=np.full(R,(pop['truth'][h-1]+bound)/(2*bound))
                null_ev[:,h-1]=np.maximum(logwealth(v,c,target),logwealth(1-v,c,1-target))
    output=[];hs=np.arange(1,T+1)
    for j,eps in enumerate(epsilons):
        k0=max(0,min(T,math.floor(math.log2(N*eps**2/(10*math.log(8/ALPHA))))))
        feasible=np.minimum.accumulate(pe[:,:,j]+hs*math.log(2),axis=1) > math.log(8/ALPHA)+hs*math.log(2)
        cap=np.maximum(k0,np.max(np.where(feasible,hs,0),axis=1))
        cutoff=math.log(8/ALPHA)+(cap[:,None]-hs)*math.log(2)
        inside=hs<=cap[:,None]
        H=np.maximum(k0,np.cumprod((ve[:,:,j]>cutoff)&inside,axis=1).sum(1))
        covered=np.all((null_ev<=cutoff)|~inside,axis=1)
        output.append(dict(H=H,cap=cap,means=means,covered=covered,checked=cap,fallback=k0))
    return output

def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def checks():
    rng=np.random.default_rng(2026092614)
    values=np.broadcast_to(np.array([0,.13,.55,.9,1]),(8,5));counts=rng.integers(0,10,(8,5))
    cand=rng.uniform(.05,.95,8)
    np.testing.assert_allclose(logwealth(values,counts,cand),oldbet.logwealth(values,counts,cand),atol=1e-12)
    lo,hi,mean=endpoints(values,counts,.03)
    ol,ou=oldbet.betting_interval(values,counts,.03)
    assert np.all(lo<=ol+1e-12) and np.all(hi>=ou-1e-12)
    assert max(np.max(ol-lo),np.max(hi-ou))<6e-8
    # Compressed wealth agrees with expanded independent observations.
    expanded=[]
    for row in range(8):
        v=np.repeat(values[row],counts[row])[None,:]
        expanded.append(logwealth(v,np.ones_like(v,dtype=int),cand[row:row+1])[0])
    np.testing.assert_allclose(expanded,logwealth(values,counts,cand),atol=1e-12)
    pop=ref.population(5,.3,.5,.15)
    blocks=[rng.multinomial(32,pop['p'],size=3) for _ in range(6)]
    co=ref.fit(blocks[0]+blocks[1],pop);q=ref.integrate(co,5)
    mu,var=ref.score_moments(blocks[5],pop,co,q)
    err=0.
    for h in range(1,6):
        v,c,b=score_hist(blocks[5],pop,co,q,h)
        z=(2*v-1)*b
        direct=(z*c).sum(1)/32
        err=max(err,float(np.max(abs(direct-mu[:,h-1]))))
        np.testing.assert_allclose((c*(z-direct[:,None])**2).sum(1)/31,var[:,h-1],atol=1e-10)
    assert err<1e-10
    return dict(wealth_matches_existing=True,expanded_wealth_matches=True,inversion_conservative=True,score_mean_max_error=err,score_variances_match=True)

def run(out,reps=1000,limit=None):
    start=time.time();out.mkdir(parents=True,exist_ok=True)
    protocol_hash=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    report=checks();summaries=[];paired=[];survival=[];records=[]
    saved=np.load(SOURCE/'three_set/results/horizon_estimates.npz')
    original={}
    with gzip.open(SOURCE/'three_set/results/replicates.csv.gz','rt',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            if int(row['replicate'])<reps:
                key=(row['law'],int(row['n']),float(row['tau']),row['tolerance'],row['method'])
                original.setdefault(key,[]).append(int(row['H']))
    max_replay_error=0.;num=0
    for li,(law,d,lam) in enumerate(ref.LAWS):
        for ni,n in enumerate(ref.SIZES):
            T=math.ceil(math.log2(n))
            for ti,tau in enumerate(ref.NOISE):
                if limit is not None and num>=limit:break
                pop=ref.population(T,d,lam,tau)
                seeds=np.random.SeedSequence([ref.SEED,li,ni,ti]).spawn(6)
                # Generate all original rows before slicing so the replay is exact.
                blocks=[np.random.default_rng(seed).multinomial(n//6,pop['p'],size=1000)[:reps] for seed in seeds]
                epsilons=[.025,n**(-.25)];labels=['fixed','shrinking']
                outputs=full_methods(sum(blocks),pop,epsilons)
                for name in ['A2','A3','A3-oracle']:
                    if name=='A2':co=ref.fit(blocks[0]+blocks[1]+blocks[2],pop)
                    elif name=='A3':co=ref.fit(blocks[0]+blocks[1],pop)
                    else:co=np.broadcast_to([0.,ref.B,ref.A,d],(reps,4)).copy()
                    outputs[name+'-B']=split_method(blocks,pop,name,epsilons,co)
                    error=np.max(abs(outputs[name+'-B'][0]['means']-saved[f'{li}_{ni}_{ti}_{name}'][:reps]))
                    max_replay_error=max(max_replay_error,float(error));assert error<2e-9
                for j,(label,eps) in enumerate(zip(labels,epsilons)):
                    base=dict(law=law,n=n,T=T,tau=tau,tolerance=label,epsilon=eps)
                    horizons={}
                    for name,items in outputs.items():
                        item=items[j];hh=item['H'];horizons[name]=hh
                        mask=np.arange(1,T+1)[None,:]<=hh[:,None]
                        error=np.max(np.where(mask,abs(item['means']-pop['truth']),0),axis=1)
                        success=error<=eps+1e-12
                        surv=np.array([np.mean(hh>=h) for h in range(1,T+1)])
                        lo,hi=ref.wilson(int(success.sum()),reps)
                        summaries.append(dict(base,method=name,reps=reps,mean_h=float(hh.mean()),h_mcse=float(hh.std(ddof=1)/math.sqrt(reps)),h90=max([0]+[h for h in range(1,T+1) if surv[h-1]>=.9]),abstention=float(np.mean(hh==0)),selected_accuracy=float(success.mean()),accuracy_wilson_low=lo,accuracy_wilson_high=hi,checked_prefix_coverage=float(item['covered'].mean()),validation_shorter=float(np.mean(hh<item['cap'])) if name.startswith('A') else '',oracle_diagnostic='oracle' in name))
                        for h in range(1,T+1):survival.append(dict(base,method=name,h=h,reported=int(np.sum(hh>=h)),reps=reps))
                        for r in range(reps):records.append(dict(base,method=name,replicate=r,H=int(hh[r]),cap=int(item['cap'][r]),fallback=item['fallback'],selected_max_error=float(error[r]),selected_success=int(success[r]),checked_prefix_covered=int(item['covered'][r]),checked_coordinates=int(item['checked'][r])))
                        before=np.asarray(original[(law,n,tau,label,name.removesuffix('-B'))])
                        horizons[name.removesuffix('-B')+'-EB']=before
                    pairs=[('A3-B','C-B'),('A3-B','S-B'),('A3-B','A2-B'),('A3-B','A3-oracle-B'),('S-B','C-B')]
                    pairs += [(name,name.removesuffix('-B')+'-EB') for name in outputs]
                    for left,right in pairs:
                        diff=horizons[left]-horizons[right]
                        paired.append(dict(base,left=left,right=right,mean_difference=float(diff.mean()),mcse=float(diff.std(ddof=1)/math.sqrt(reps)),win=float(np.mean(diff>0)),tie=float(np.mean(diff==0)),loss=float(np.mean(diff<0))))
                    print(law,n,tau,label,{name:round(float(items[j]['H'].mean()),3) for name,items in outputs.items()},flush=True)
                num+=1
                # Persist completed populations so interrupted exploratory runs remain auditable.
                for file,rows in [('summary.csv',summaries),('paired.csv',paired),('survival.csv',survival)]:write_csv(out/file,rows)
    with gzip.open(out/'replicates.csv.gz','wt',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
    report.update(replayed_point_estimate_max_error=max_replay_error,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),protocol_sha256=protocol_hash,source_protocol_sha256=hashlib.sha256((SOURCE/'three_set/PROTOCOL.md').read_bytes()).hexdigest(),reps=reps,populations=num,distinct_reused_datasets=num*reps,summary_rows=len(summaries),method_condition_records=len(records),elapsed_seconds=time.time()-start,numpy=np.__version__)
    assert hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()==protocol_hash
    (out/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'results');p.add_argument('--reps',type=int,default=1000);p.add_argument('--limit',type=int);p.add_argument('--check',action='store_true');a=p.parse_args()
    if a.check:print(json.dumps(checks(),indent=2))
    else:run(a.out,a.reps,a.limit)
