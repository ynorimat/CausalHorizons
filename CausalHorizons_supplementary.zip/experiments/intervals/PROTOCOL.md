# Matched fixed-mixture interval comparison

This exploratory design was recorded before evaluating these methods,
after the empirical-Bernstein comparison had been observed. It is not an
independent preregistration. Reuse all 18 populations and 1,000 paired
datasets per population from three_set/PROTOCOL.md, with both tolerances:
36 conditions, 18,000 distinct reused datasets. No population is selected
by method ranking. Regenerate the original six blocks from seed 2026092612.

C-B, S-B, A2-B, A3-B and A3-oracle-B use the same fixed mixture of 17 bets,
2^(-j), j=0,...,16. No bet is tuned on validation. C uses all n outcomes in
each prefix, range [-1,1], and level alpha/T. S uses all n, the original
baseline-proportion Hoeffding CI at level alpha/2, and conditional-mean CIs
at alpha/(4T). It extremizes the mixture over these intervals. Empty
conditional samples use the full known range. The data's smaller realized
support is never substituted for the supplied bound M=1.

The A methods retain the original fits and splits, known score range
[-M(2^(h+1)+1), M(2^(h+1)+1)], geometric allocation, and alpha/2 fallback.
Their caps are recomputed from betting evidence with the same family used
in validation. A2 may reuse fitting data for cap selection; validation is
independent. A3 uses an independent pilot. The oracle is a diagnostic only.

One-sided wealth is the mean over bets c of product(1+c*(v/m-1)), with
v in [0,1]. The upper side uses 1-v and 1-m. Two-sided rejection uses
2/level. S endpoints use 25 conservative outer bisection steps. C and A
certify the two tolerance endpoints directly. C/S scan only through the
first failed prefix for the larger tolerance: later coordinates cannot
resume a prefix report. Their empirical interval-coverage diagnostic is
checked-prefix coverage; the A diagnostic concerns the selected cap.
This computational shortcut does not alter reported lengths or the
simultaneous mathematical coverage argument.

Retain mean lengths, MCSEs, 90%-report thresholds, abstention, selected
accuracy, paired differences and all records, including unfavorable cells.
The fixed mixture is not asserted to reproduce optimized betting methods
or their optimality constants. Replicate and mean/error replay checks use
the original saved arrays; numerical checks do not substitute for proofs.
