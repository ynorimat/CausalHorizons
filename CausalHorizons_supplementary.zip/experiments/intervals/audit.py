"""Independent saved-record aggregation and mean/error replay checks."""
from pathlib import Path
import csv,gzip,itertools,json,math
import numpy as np
import run as study
ROOT=Path(__file__).resolve().parent

def main():
    with np.load(study.SOURCE/'three_set/results/horizon_estimates.npz') as saved:
        archive={key:saved[key] for key in saved.files}
    groups={};max_error=0.
    with gzip.open(ROOT/'results/replicates.csv.gz','rt',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            li=['additive','interaction'].index(r['law']);ni=study.ref.SIZES.index(int(r['n']));ti=study.ref.NOISE.index(float(r['tau']))
            name=r['method'].removesuffix('-B');rep=int(r['replicate']);H=int(r['H']);T=int(r['T'])
            means=archive[f'{li}_{ni}_{ti}_{name}'][rep]
            truth=.1*np.arange(1,T+1)/T
            expected=np.max(abs(means[:H]-truth[:H])) if H else 0.
            max_error=max(max_error,abs(expected-float(r['selected_max_error'])))
            assert int(r['selected_success'])==int(expected<=float(r['epsilon'])+1e-12)
            key=(r['law'],r['n'],r['tau'],r['tolerance'],r['method'])
            groups.setdefault(key,[]).append(r)
    assert max_error<1e-9 and len(groups)==180
    with (ROOT/'results/summary.csv').open(encoding='utf-8') as f:
        for row in csv.DictReader(f):
            key=tuple(row[k] for k in ['law','n','tau','tolerance','method'])
            records=groups[key];assert len(records)==1000
            hh=np.array([int(r['H']) for r in records])
            assert float(row['mean_h'])==hh.mean()
            assert int(row['h90'])==max([0]+[h for h in range(1,int(row['T'])+1) if np.mean(hh>=h)>=.9])
    oracle_mismatches=0
    for key,rs in groups.items():
        if key[-1]=='A3-B':
            other=groups[key[:-1]+('A3-oracle-B',)]
            oracle_mismatches+=sum(r['H']!=s['H'] for r,s in zip(rs,other))
    # Fixed-bet wealth under an i.i.d. Bernoulli null has exact expectation one.
    max_wealth_error=0.
    for m in [.05,.2,.5,.8,.95]:
        rows=np.array(list(itertools.product([0.,1.],repeat=8)))
        probs=m**rows.sum(1)*(1-m)**(8-rows.sum(1))
        w=study.logwealth(rows,np.ones_like(rows,dtype=int),np.full(len(rows),m))
        max_wealth_error=max(max_wealth_error,abs(float(probs@np.exp(w))-1))
    assert max_wealth_error<1e-12
    checks=dict(records=180000,summary_rows=180,original_estimate_selected_error_max_difference=max_error,all_summary_means_and_h90_recomputed=True,A3_oracle_paired_horizon_mismatches=oracle_mismatches,exact_null_wealth_expectation_max_error=max_wealth_error)
    (ROOT/'results/audit.json').write_text(json.dumps(checks,indent=2)+'\n')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
