"""Paired comparison at the terminal noise-study condition."""
from pathlib import Path
import argparse,csv,gzip,hashlib,json,math
import numpy as np
import run as followup
ROOT=Path(__file__).resolve().parent

def main(out=None):
    out=ROOT/'focused_results' if out is None else out;out.mkdir(parents=True,exist_ok=True)
    phash=hashlib.sha256((ROOT/'FOCUSED_PROTOCOL.md').read_bytes()).hexdigest()
    n,T,s=2**32,32,.25;eps=n**(-.25);kappa=math.sqrt(1-.25*n**(-s))
    binary=followup.ref.binary
    ell,g,x,y,p,ind,ratios,truth=binary.population(T,kappa)
    rng=np.random.default_rng(np.random.SeedSequence([2026092527,2,T,round(1000*s)]))
    train=rng.multinomial(n//2,p,size=1000);valid=rng.multinomial(n//2,p,size=1000)
    original,_=binary.evaluate(train,valid,g,y,ind,ratios,eps)
    saved={name:[] for name in ['C','S']}
    with gzip.open(followup.SOURCE/'noise/results/vanishing_replicates.csv.gz','rt',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if int(r['n'])==n and float(r['s'])==s and r['method'] in saved:saved[r['method']].append(int(r['H']))
    for name in saved:np.testing.assert_array_equal(saved[name],original[name][0])
    pop=dict(ell=ell,x=x,y=y,T=T,truth=truth)
    methods=followup.full_methods(train+valid,pop,[eps])
    rows=[];records=[]
    for name in ['C','S','C-B','S-B']:
        if name in original:
            hh,mean,w,inside,cap=original[name]
            covered=np.all((abs(mean-truth)<=w)|~inside,axis=1)
        else:
            item=methods[name][0];hh=item['H'];mean=item['means'];covered=item['covered']
        error=np.max(np.where(np.arange(1,T+1)[None,:]<=hh[:,None],abs(mean-truth),0),axis=1)
        good=error<=eps+1e-12
        h90=max([0]+[h for h in range(1,T+1) if np.mean(hh>=h)>=.9])
        rows.append(dict(n=n,T=T,s=s,kappa=kappa,epsilon=eps,method=name,reps=1000,mean_h=float(hh.mean()),h_mcse=float(hh.std(ddof=1)/math.sqrt(1000)),h90=h90,selected_accuracy=float(good.mean()),checked_prefix_coverage=float(covered.mean())))
        for i in range(1000):records.append(dict(method=name,replicate=i,H=int(hh[i]),selected_max_error=float(error[i]),selected_success=int(good[i])))
    followup.write_csv(out/'summary.csv',rows);followup.write_csv(out/'replicates.csv',records)
    assert phash==hashlib.sha256((ROOT/'FOCUSED_PROTOCOL.md').read_bytes()).hexdigest()
    (out/'checks.json').write_text(json.dumps(dict(original_C_S_lengths_match=True,reused_datasets=1000,seed=2026092527,protocol_sha256=phash,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
    print(json.dumps(rows,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path);main(p.parse_args().out)
