# Terminal noise-study comparison

Reuse all 1,000 original datasets at n=2^32, T=32, s=r=1/4, b=.75,
M=1, alpha=.05, epsilon=1/256. This specific finite-gap diagnostic was
recorded before evaluating C-B/S-B, after the EB results were known.
Use the same definitions and fixed bets as the matched-interval protocol.
Regenerate the original noise-study seed 2026092527 and verify the original
C/S lengths exactly. No new population or independently collected dataset
is introduced. Save all four old/new method records and empirical thresholds.
The count-based sufficient theorem is evaluated at perfect predictability
separately; it is not applied to this noisy law.
