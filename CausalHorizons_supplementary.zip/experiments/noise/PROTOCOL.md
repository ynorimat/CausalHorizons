# Noise

Continuous baseline: 1200 independent datasets shared across eight tolerance cells and six methods. Vanishing noise: 40 populations, 1000 datasets per population, seven methods sharing each dataset. The laws, grids, clipping, regression dictionaries and exact seeds are specified in run.py and Appendix D. No validation-based method selection is used.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
