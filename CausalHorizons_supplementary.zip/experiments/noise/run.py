"""Noise calculations for the causal-horizon experiments."""
from pathlib import Path
import csv, gzip, hashlib, importlib.util, json, math, os, platform, sys, time
import numpy as np

ROOT=Path(__file__).resolve().parent
SUP=ROOT.parent
spec=importlib.util.spec_from_file_location('revision_comparison',SUP/'binary/run.py')
rev=importlib.util.module_from_spec(spec); spec.loader.exec_module(rev)
old=rev.old
OUT=ROOT/'results'
M=1.; ALPHA=.05; SEED=2026092527

def moments(ell,y,q,T):
    """Exact moments of q(X)+2^h 1{ell>=h}(Y-q(X)), without n by T arrays."""
    n=len(y); res=y-q; h=np.arange(1,T+1); w=np.exp2(h)
    def tail(v): return np.cumsum(np.bincount(ell,weights=v,minlength=T+1)[::-1])[::-1][1:]
    sy=q.sum()+w*tail(res)
    sy2=np.dot(q,q)+2*w*tail(q*res)+w*w*tail(res*res)
    mu=sy/n
    return mu,np.maximum(0,(sy2-n*mu*mu)/(n-1))

def conditional(ell,y,T):
    def tail(v): return np.cumsum(np.bincount(ell,weights=v,minlength=T+1)[::-1])[::-1][1:]
    size=tail(np.ones(len(y))); sy=tail(y); sy2=tail(y*y)
    mean=np.divide(sy,size,out=np.zeros(T),where=size>0)
    var=np.divide(sy2-size*mean*mean,size-1,out=np.zeros(T),where=size>1)
    return mean,np.maximum(0,var),size

def predictors(x0,y0,x1):
    b0=np.polynomial.legendre.legvander(x0,7)
    b1=np.polynomial.legendre.legvander(x1,7)
    result={}
    for degree,name in [(7,'O7'),(1,'L1')]:
        design=b0[:,:degree+1]
        coef=np.linalg.solve(design.T@design,design.T@y0)
        result[name]=(np.clip(design@coef,-M,M),np.clip(b1[:,:degree+1]@coef,-M,M))
    groups0=np.minimum(7,((x0+1)*4).astype(int)); groups1=np.minimum(7,((x1+1)*4).astype(int))
    counts=np.bincount(groups0,minlength=8)
    means=np.divide(np.bincount(groups0,weights=y0,minlength=8),counts,out=np.zeros(8),where=counts>0)
    result['G8']=(means[groups0],means[groups1])
    result['I']=(np.zeros(len(x0)),np.zeros(len(x1)))
    return result

def new_data(rng,N,T,sigma):
    x=rng.uniform(-1,1,N); ell=np.minimum(rng.geometric(.5,N)-1,T)
    u=2*rng.integers(0,2,N)-1
    y=.55*np.sin(np.pi*x)+.1*x+.2*np.minimum(ell,6)/6+sigma*u
    assert np.max(abs(y))<=1
    return x,ell,y

def metrics(h,estimate,width,inside,cap,truth,eps):
    chosen=np.arange(1,len(truth)+1)<=h
    err=float(np.max(np.where(chosen,abs(estimate-truth),0)))
    cover='' if width is None else bool(np.all((abs(estimate-truth)<=width+1e-12)|~inside))
    return dict(H=int(h),cap=int(cap),selected_max_error=err,
                selected_success=bool(err<=eps+1e-12),candidate_coverage=cover)

def summaries(records,keys):
    groups={}
    for row in records:
        key=tuple(row[k] for k in keys); groups.setdefault(key,[]).append(row)
    out=[]
    for key,rows in groups.items():
        H=np.array([r['H'] for r in rows]); E=np.array([r['selected_max_error'] for r in rows])
        cov=[r['candidate_coverage'] for r in rows if r['candidate_coverage']!='']
        out.append(dict(zip(keys,key),reps=len(rows),mean_h=float(H.mean()),
                        h_mcse=float(H.std(ddof=1)/np.sqrt(len(rows))),
                        h_q05=float(np.quantile(H,.05)),h_q95=float(np.quantile(H,.95)),
                        selected_accuracy=float(np.mean([r['selected_success'] for r in rows])),
                        abstention=float(np.mean(H==0)),error_q95=float(np.quantile(E,.95)),
                        candidate_coverage=float(np.mean(cov)) if cov else ''))
    return out

def save_csv(name,rows,compressed=False):
    opener=gzip.open if compressed else open
    with opener(OUT/name,'wt',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def checks():
    rng=np.random.default_rng(2026092528); max_moment=0.; max_risk_slack=0.
    x,e,y=new_data(rng,4096,8,.1); q=np.clip(.4*np.sin(np.pi*x)+.3,-1,1)
    mean,var=moments(e,y,q,8)
    z=q[:,None]+(e[:,None]>=np.arange(1,9))*np.exp2(np.arange(1,9))*(y-q)[:,None]
    max_moment=max(float(np.max(abs(mean-z.mean(0)))),float(np.max(abs(var-z.var(0,ddof=1)))))
    np.testing.assert_allclose(mean,z.mean(0),atol=1e-12)
    np.testing.assert_allclose(var,z.var(0,ddof=1),atol=1e-10)
    # Exact binomial risk verifies the finite bound, including empty groups.
    count=0
    for N in [2,3,4,8,16,32,64]:
        for kappa in [0,.5,.9,.99,1.]:
            sig2=.75**2*(1-kappa*kappa)
            exact=kappa*kappa*.75**2*2.**(-N)
            exact+=sum(math.comb(N,j)*2.**(-N)*sig2/j for j in range(1,N+1))
            bound=4*sig2/(N+1)+.75**2*2.**(-N)
            assert exact<=bound+1e-14
            max_risk_slack=max(max_risk_slack,exact-bound);count+=1
    # Enumerate all (X,Y) training samples of N=3; integrate actions analytically.
    max_training_gap=-math.inf
    for kappa in [0,.5,.99,1.]:
        N=3; states=[(-1.,-.75),(-1.,.75),(1.,-.75),(1.,.75)]
        p=np.array([.5*((1+kappa)/2 if y==.75*x else (1-kappa)/2) for x,y in states])
        for h in [1,3,6]:
            expected=0.
            for ids in np.ndindex(*(4,)*N):
                prob=float(np.prod(p[list(ids)]))
                xx=np.array([states[i][0] for i in ids]); yy=np.array([states[i][1] for i in ids])
                qq=np.array([yy[xx==x].mean() for x in xx]); rr=yy-qq
                ez2=yy*yy+(2.**h-1)*rr*rr
                # Conditional independent actions: E[sum Zi^2-N mean(Z)^2].
                es2=(ez2.sum()-((ez2-yy*yy).sum()+yy.sum()**2)/N)/(N-1)
                expected+=prob*es2
            bound=N/(N-1)*(.75**2+(2.**h-1)*.75**2*(1-kappa*kappa))
            assert expected<=bound+1e-12
            max_training_gap=max(max_training_gap,expected-bound)
    # Product quadrature: independently specified q and exact run-length law.
    nodes,weights=np.polynomial.legendre.leggauss(80);weights/=2
    T=18; ls=np.arange(T+1); ps=np.where(ls<T,np.exp2(-ls-1.),np.exp2(-float(T)))
    h=np.arange(1,T+1); truth=.2*np.where(h<6,(h+1-np.exp2(h-6))/6,1.)
    ztruth=np.zeros(T)
    for x,w in zip(nodes,weights):
        yy=.55*np.sin(np.pi*x)+.1*x+.2*np.minimum(ls,6)/6
        qx=.3*x+.2
        zz=qx+(ls[:,None]>=h)*np.exp2(h)*(yy[:,None]-qx)
        ztruth+=w*(ps@zz)
    np.testing.assert_allclose(ztruth,truth,atol=2e-14)
    return dict(grouped_moment_max_error=max_moment,binomial_risk_cases=count,
                training_moment_cases=12,training_bound_largest_difference=max_training_gap,
                quadrature_truth_max_error=float(np.max(abs(ztruth-truth))))

def continuous():
    records=[]; start=time.time(); T=18; hh=np.arange(1,T+1)
    truth=.2*np.where(hh<6,(hh+1-np.exp2(hh-6))/6,1.)
    for n in [65536,262144]:
        for sigma in [0.,.1]:
            rng=np.random.default_rng(np.random.SeedSequence([SEED,1,n,round(100*sigma)]))
            N=n//2
            for rep in range(300):
                x0,e0,y0=new_data(rng,N,T,sigma); x1,e1,y1=new_data(rng,N,T,sigma)
                fitted=predictors(x0,y0,x1)
                tm={}; vm={}
                for name,(q0,q1) in fitted.items():
                    tm[name]=moments(e0,y0,q0,T);vm[name]=moments(e1,y1,q1,T)
                cm,cv,cn=conditional(np.r_[e0,e1],np.r_[y0,y1],T)
                fullipw=np.clip((tm['I'][0]+vm['I'][0])/2,-M,M)
                for eps in [.025,.05]:
                    k0=old.original.fallback(N,T,M,eps,ALPHA)
                    base=dict(n=n,T=T,sigma=sigma,epsilon=eps,replicate=rep)
                    for name in ['O7','G8','L1','I']:
                        ran=2*M*np.exp2(hh) if name=='I' else old.original.score_ranges(T,M)
                        cap=old.pilot(tm[name][1][None,:],N,ran,eps,ALPHA/2,k0)
                        sh,w,inside=old.selected(vm[name][1][None,:],N,ran,cap,eps,ALPHA/2,k0)
                        records.append(dict(base,method=name,**metrics(sh[0],vm[name][0],w[0],inside[0],cap[0],truth,eps)))
                    sh,w,inside=old.selected(cv[None,:],cn[None,:],2*M,np.array([T]),eps,ALPHA,allocation='uniform')
                    records.append(dict(base,method='C',**metrics(sh[0],cm,w[0],inside[0],T,truth,eps)))
                    fixed=max(0,min(T,int(np.floor(np.log2(n*eps*eps/(3*M*M*np.log(4/ALPHA)))))))
                    records.append(dict(base,method='F',**metrics(fixed,fullipw,None,None,fixed,truth,eps)))
                if (rep+1)%100==0: print(f'continuous n={n}, sigma={sigma}, {rep+1}/300; {time.time()-start:.1f}s',flush=True)
    save_csv('continuous_replicates.csv.gz',records,True)
    summary=summaries(records,['n','T','sigma','epsilon','method']);save_csv('continuous_summary.csv',summary)
    pairs=[]
    for n in [65536,262144]:
        for sigma in [0.,.1]:
            for eps in [.025,.05]:
                rows=[x for x in records if x['n']==n and x['sigma']==sigma and x['epsilon']==eps]
                base=np.array([x['H'] for x in rows if x['method']=='O7'])
                for method in ['G8','L1','I','C','F']:
                    other=np.array([x['H'] for x in rows if x['method']==method]);diff=base-other
                    pairs.append(dict(n=n,sigma=sigma,epsilon=eps,comparator=method,
                                      mean_difference=float(diff.mean()),mcse=float(diff.std(ddof=1)/np.sqrt(len(diff)))))
    save_csv('continuous_paired.csv',pairs)

def vanishing():
    records=[];start=time.time()
    for s in [0.,.125,.25,.5]:
        for exponent in range(14,33,2):
            n=2**exponent;T=exponent;N=n//2;eps=n**(-.25);kappa=math.sqrt(1-.25*n**(-s))
            l,g,x,y,p,ind,ratios,truth=rev.population(T,kappa)
            rng=np.random.default_rng(np.random.SeedSequence([SEED,2,exponent,round(1000*s)]))
            train=rng.multinomial(N,p,size=1000);valid=rng.multinomial(N,p,size=1000)
            methods,k0=rev.evaluate(train,valid,g,y,ind,ratios,eps)
            for name,(sh,est,width,inside,cap) in methods.items():
                for rep in range(1000):
                    records.append(dict(n=n,T=T,s=s,kappa=kappa,epsilon=eps,replicate=rep,method=name,
                                        **metrics(sh[rep],est[rep],None if width is None else width[rep],
                                                  None if inside is None else inside[rep],cap[rep],truth,eps)))
            print(f'vanishing s={s}, log2 n={exponent}; {time.time()-start:.1f}s',flush=True)
    save_csv('vanishing_replicates.csv.gz',records,True)
    save_csv('vanishing_summary.csv',summaries(records,['n','T','s','kappa','epsilon','method']))

def diagnostics():
    rows=[]; n=2**26;N=n//2;T=26;eps=n**(-.25);h=np.arange(1,T+1)
    for kappa in [.9,.99,1.]:
        l,g,x,y,p,ind,ratios,truth=rev.population(T,kappa)
        rng=np.random.default_rng(np.random.SeedSequence([SEED,3,round(1000*kappa)]))
        train=rng.multinomial(N,p,size=1);valid=rng.multinomial(N,p,size=1)
        pred=old.fit_group_means(train,g,y);_,tv=old.score_moments(train,g,y,ratios,pred)
        _,vv=old.score_moments(valid,g,y,ratios,pred);ran=old.original.score_ranges(T,M)
        k0=old.original.fallback(N,T,M,eps,ALPHA)
        cap=int(old.pilot(tv,N,ran,eps,ALPHA/2,k0)[0])
        lam=np.log(16/ALPHA)+(cap-h[:cap])*np.log(2)
        st=np.sqrt(2*vv[0,:cap]*lam/N); rt=7*ran[:cap]*lam/(3*(N-1))
        for j in range(cap): rows.append(dict(kappa=kappa,n=n,h=j+1,cap=cap,epsilon=eps,sqrt_term=st[j],range_term=rt[j],total=st[j]+rt[j]))
    save_csv('width_components.csv',rows)

if __name__=='__main__':
    OUT.mkdir(exist_ok=True)
    check=checks();(OUT/'checks.json').write_text(json.dumps(check,indent=2)+'\n')
    if '--check' in sys.argv: print(json.dumps(check,indent=2));sys.exit(0)
    start=time.time(); phash=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    continuous();vanishing();diagnostics()
    meta=dict(seed=SEED,continuous_independent_datasets=1200,continuous_cells=8,continuous_records=14400,
              vanishing_independent_datasets=40000,vanishing_cells=40,vanishing_records=280000,
              diagnostic_datasets=3,python=platform.python_version(),numpy=np.__version__,
              system=platform.system(),processor=platform.processor(),seconds=time.time()-start,
              protocol_sha256=phash,run_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),omp_threads=os.getenv('OMP_NUM_THREADS'))
    assert hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()==phash
    (OUT/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps(meta,indent=2),flush=True)
