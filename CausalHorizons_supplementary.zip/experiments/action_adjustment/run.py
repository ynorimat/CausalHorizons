"""Action Adjustment calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse, importlib.util, itertools, json, math, os, platform, time
import numpy as np

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('duration_v7',ROOT.parent/'additive/run.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
pilot,bet=old.pilot,old.bet
M,ALPHA,EPS=1.,.05,.025

def integrate(coef,T):
    policy=np.zeros((len(coef),2,T))
    for h in range(1,T+1):
        k=np.arange(T-h+1)
        weights=np.array([math.comb(T-h,int(j))*2.**(-(T-h)) for j in k])
        for g,x in enumerate([-1,1]):
            vals=np.clip(coef[:,0,None]+coef[:,1,None]*x+coef[:,2,None]*(h+k)[None,:]/T,-M,M)
            policy[:,g,h-1]=vals@weights
    return policy

def predictions(counts,pop,T):
    pred,coef=old.fits(counts,pop,T)
    factual=np.clip(coef[:,0,None]+coef[:,1,None]*pop[None,:,2]+coef[:,2,None]*pop[None,:,1]/T,-M,M)
    pred['A']=integrate(coef,T)
    return pred,coef,factual

def histogram(counts,pop,q,factual,h):
    keys=[(int(row[2]),float(row[4]) if row[0]>=h else None,int(row[1]) if row[0]>=h else None) for row in pop]
    unique=list(dict.fromkeys(keys));mapping={k:j for j,k in enumerate(unique)}
    membership=np.array([mapping[k] for k in keys])
    cc=np.stack([counts[:,membership==j].sum(1) for j in range(len(unique))],axis=1)
    zz=np.empty_like(cc,dtype=float)
    for j,(x,y,total) in enumerate(unique):
        base=q[:,(x+1)//2]
        if y is None: zz[:,j]=base
        else:
            idx=np.flatnonzero(membership==j)[0]
            zz[:,j]=base+2**h*(y-factual[:,idx])
    return zz,cc

def widths(variance,N,cap):
    h=np.arange(1,variance.shape[1]+1)[None,:]
    caps=np.broadcast_to(np.asarray(cap),len(variance))[:,None]
    lam=math.log(16/ALPHA)+np.maximum(caps-h,0)*math.log(2)
    root=np.sqrt(2*variance*lam/N)
    ran=np.broadcast_to(7*2*M*(2.**(h+1)+1)*lam/(3*(N-1)),root.shape)
    return root+ran,root,ran

def eb_cap(variance,N,epsilon,fallback):
    cap=np.full(len(variance),fallback,dtype=int)
    for k in range(1,variance.shape[1]+1):
        w,_,_=widths(variance[:,:k],N,k)
        cap=np.where(np.max(w,axis=1)<=epsilon,np.maximum(cap,k),cap)
    return cap

def evaluate(train,valid,pop,truth,T,epsilon=EPS,betting=True,verify_inverse=False,labels=('B','H','A')):
    N=int(train[0].sum())
    fallback=max(0,min(T,math.floor(math.log2(N*epsilon**2/(10*M*M*math.log(8/ALPHA))))))
    pred,coef,factual=predictions(train,pop,T)
    outputs={};diags={};inversions=0
    for label in labels:
        q=pred[label];shape=(len(train),T)
        means=np.empty(shape);tv=np.empty(shape);vv=np.empty(shape)
        te=np.empty(shape);ve=np.empty(shape);wealth=np.empty(shape);cached=[]
        for h in range(1,T+1):
            if label=='A':
                z,ct=histogram(train,pop,q[:,:,h-1],factual,h)
                zv,cv=histogram(valid,pop,q[:,:,h-1],factual,h)
            else:
                z,ct=old.histogram(train,pop,q[:,:,h-1],h)
                zv,cv=old.histogram(valid,pop,q[:,:,h-1],h)
            _,tv[:,h-1]=old.moments(z,ct);means[:,h-1],vv[:,h-1]=old.moments(zv,cv)
            support=M*(2**(h+1)+1)
            assert np.max(np.abs(z))<=support+1e-10
            if betting:
                vt=(z+support)/(2*support);vval=(zv+support)/(2*support)
                te[:,h-1]=pilot.evidence(vt,ct,epsilon/(2*support))
                ve[:,h-1]=pilot.evidence(vval,cv,epsilon/(2*support))
                target=np.full(len(train),(truth[h-1]+support)/(2*support))
                wealth[:,h-1]=np.maximum(bet.logwealth(vval,cv,target),bet.logwealth(1-vval,cv,1-target))
                if verify_inverse: cached.append((vval,cv,support))
        cap=eb_cap(tv,N,epsilon,fallback)
        ew,_,_=widths(vv,N,cap);h=np.arange(1,T+1)[None,:];inside=h<=cap[:,None]
        hh=np.maximum(fallback,np.cumprod((ew<=epsilon)&inside,axis=1).sum(1)).astype(int)
        coverage=np.all((abs(means-truth)<=ew+1e-12)|~inside,axis=1)
        outputs['EB-'+label]=(hh,means,cap,coverage)
        nxt=np.minimum(cap+1,T);pw,pr,pg=widths(tv,N,nxt)
        fail=(pw>epsilon)&(h<=nxt[:,None]);index=np.argmax(fail,axis=1)
        hasfail=np.any(fail,axis=1)&(cap<T)
        selected_root=pr[np.arange(len(train)),index]/epsilon
        selected_range=pg[np.arange(len(train)),index]/epsilon
        diags['EB-'+label]=dict(range_blocks=int(np.sum(hasfail&(selected_range>=1))),
            combined_blocks=int(np.sum(hasfail&(selected_range<1))),tested=int(hasfail.sum()),
            mean_root_at_rejection=float(selected_root[hasfail].mean()) if hasfail.any() else 0.,
            mean_range_at_rejection=float(selected_range[hasfail].mean()) if hasfail.any() else 0.,
            validation_shorter=int(np.sum(hh<cap)),mean_validation_variance_h8=float(vv[:,min(8,T)-1].mean()))
        if betting:
            bc=pilot.select_cap(te,fallback);bh=pilot.select(ve,bc,fallback)
            coverage=np.all((wealth<=math.log(8/ALPHA)+(bc[:,None]-h)*math.log(2))|(h>bc[:,None]),axis=1)
            outputs['Bet-'+label]=(bh,means,bc,coverage)
            if verify_inverse:
                good=np.zeros(shape,dtype=bool)
                for hi,(val,cc,support) in enumerate(cached,1):
                    ids=np.flatnonzero(bc>=hi)
                    if not len(ids):continue
                    alpha=(ALPHA/2)*2.**(hi-bc[ids]-1)
                    lo,up=bet.betting_interval(val[ids],cc[ids],alpha)
                    center=(val[ids]*cc[ids]).sum(1)/N
                    radius=2*support*np.maximum(center-lo,up-center)
                    good[ids,hi-1]=radius<epsilon;inversions+=len(ids)
                inverse=np.maximum(fallback,np.cumprod(good,axis=1).sum(1)).astype(int)
                np.testing.assert_array_equal(inverse,bh)
    return outputs,diags,dict(inversions=inversions,max_coefficient_error=float(np.max(abs(coef-np.array([0,.3*np.sum(pop[:,5]*pop[:,2]*pop[:,3]),.6])))))

def checks():
    rng=np.random.default_rng(2026092582);err=0.;cases=0;exp_err=0.;variance_error=0.
    for T in [3,5,8]:
        for kappa in [0.,.9,1.]:
            pop,truth=old.population(T,kappa);mass=pop[:,5]
            ct=rng.multinomial(80,mass,size=4)
            pred,coef,factual=predictions(ct,pop,T)
            for h in range(1,T+1):
                mu=(T+h)/(2*T);R=2**h*(pop[:,0]>=h)
                z=kappa*.3*pop[:,2]+.6*mu+R*(pop[:,4]-kappa*.3*pop[:,2]-.6*pop[:,1]/T)
                expect=kappa*kappa*.09+2**h*.09*(1-kappa*kappa)
                variance_error=max(variance_error,abs(mass@(z-truth[h-1])**2-expect))
                zz,cc=histogram(ct,pop,pred['A'][:,:,h-1],factual,h)
                mm,ss=old.moments(zz,cc)
                for i in range(4):
                    ids=np.repeat(np.arange(len(pop)),ct[i]);group=((pop[ids,2]+1)/2).astype(int)
                    direct=pred['A'][i,group,h-1]+R[ids]*(pop[ids,4]-factual[i,ids])
                    exp_err=max(exp_err,abs(mm[i]-direct.mean()),abs(ss[i]-direct.var(ddof=1)))
    # Full action enumeration; neither the outcome nor the clipped predictor
    # obeys the additive evaluation family. This checks the full-class algebra.
    for T in [3,5,7]:
        paths=np.array(list(itertools.product([0,1],repeat=T)))
        for x in [-1,1]:
            abar=paths.mean(1)
            outcome=np.tanh(.7*x+paths[:,0]-2*paths[:,-1]+.3*np.prod(2*paths-1,axis=1))
            for co in [(-2.,3.,4.),(.2,-.4,.3)]:
                factual=np.clip(co[0]+co[1]*x+co[2]*abar,-1,1)
                for h in range(1,T+1):
                    mask=np.all(paths[:,:h]==1,axis=1);R=2**h*mask
                    q=factual[mask].mean()
                    computed=integrate(np.array([co]),T)[0,(x+1)//2,h-1]
                    err=max(err,abs(computed-q));z=computed+R*(outcome-factual)
                    target=outcome[mask].mean()
                    err=max(err,abs(z.mean()-target));cases+=1
                    assert max(abs(z))<=2**(h+1)+1+1e-12
                    assert z.var()<=4*2**h+1e-12
    assert err<1e-12 and exp_err<1e-9 and variance_error<1e-10
    inverse=0
    for n in [65536,262144,1048576]:
        for kappa in [0.,.9,1.]:
            pop,truth=old.population(16,kappa)
            ct=rng.multinomial(n//2,pop[:,5],size=3);cv=rng.multinomial(n//2,pop[:,5],size=3)
            _,_,info=evaluate(ct,cv,pop,truth,16,verify_inverse=True)
            inverse+=info['inversions']
    return dict(full_class_expectation_cases=cases,max_expectation_error=err,
        max_expanded_moment_error=exp_err,max_population_variance_error=variance_error,
        independent_interval_inversions=inverse)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=ROOT/'results');parser.add_argument('--check',action='store_true');args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True);start=time.time();ph=bet.sha(ROOT/'PROTOCOL.md')
    check=checks();(args.out/'checks.json').write_text(json.dumps(check,indent=2)+'\n')
    if args.check:print(json.dumps(check,indent=2));return
    summaries=[];records=[];survival=[];paired=[];diagnostics=[];estimates={}
    cells=[('matched',n,16,k,500,EPS) for n in [65536,262144,1048576] for k in [0.,.9,1.]]
    cells += [('growing',2**p,p,1.,1000,2**(-p/4)) for p in range(14,33,2)]
    for study,n,T,kappa,reps,epsilon in cells:
        pop,truth=old.population(T,kappa)
        seed=2026092571 if study=='matched' else 2026092581
        rng=np.random.default_rng(np.random.SeedSequence([seed,n,round(1000*kappa)]))
        train=rng.multinomial(n//2,pop[:,5],size=reps);valid=rng.multinomial(n//2,pop[:,5],size=reps)
        output,diag,info=evaluate(train,valid,pop,truth,T,epsilon,betting=study=='matched',labels=('B','H','A') if study=='matched' else ('H','A'))
        base=dict(study=study,n=n,T=T,kappa=kappa,epsilon=epsilon)
        for name,(hh,est,cap,cov) in output.items():
            estimates[f'{study}_{n}_{kappa:g}_{name}']=est
            selected=np.arange(1,T+1)[None,:]<=hh[:,None]
            error=np.max(np.where(selected,abs(est-truth),0.),axis=1);success=error<=epsilon+1e-12
            summaries.append(dict(base,method=name,repetitions=reps,mean_h=float(hh.mean()),h_mcse=float(hh.std(ddof=1)/math.sqrt(reps)),
                empirical_h90=bet.frequent_horizon(hh,T),mean_cap=float(cap.mean()),selected_accuracy=float(success.mean()),candidate_coverage=float(cov.mean()),
                abstention=float(np.mean(hh==0)),error_q95=float(np.quantile(error,.95))))
            for i in range(reps):records.append(dict(base,method=name,replicate=i,H=int(hh[i]),cap=int(cap[i]),selected_max_error=float(error[i]),selected_success=bool(success[i]),candidate_coverage=bool(cov[i])))
            for h in range(1,T+1):
                num=int(np.sum(hh>=h));lo,hi=bet.wilson(num,reps)
                survival.append(dict(base,method=name,horizon=h,successes=num,repetitions=reps,reporting_frequency=num/reps,wilson_lower=lo,wilson_upper=hi))
        for a,b in [('EB-A','EB-H')]+([('Bet-A','Bet-H'),('Bet-H','Bet-B')] if study=='matched' else []):
            delta=output[a][0]-output[b][0]
            paired.append(dict(base,comparison=a+' minus '+b,mean_difference=float(delta.mean()),difference_mcse=float(delta.std(ddof=1)/math.sqrt(reps)),fraction_longer=float(np.mean(delta>0))))
        for method,d in diag.items():diagnostics.append(dict(base,method=method,**d,max_coefficient_error=info['max_coefficient_error']))
        print(study,n,kappa,{k:float(v[0].mean()) for k,v in output.items()},flush=True)
    for name,data in [('summary.csv',summaries),('paired.csv',paired),('survival.csv',survival),('diagnostics.csv',diagnostics),('replicates.csv.gz',records)]:bet.save_csv(args.out/name,data)
    np.savez_compressed(args.out/'horizon_estimates.npz',**estimates)
    assert bet.sha(ROOT/'PROTOCOL.md')==ph
    metadata=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),processor=platform.processor(),elapsed_seconds=time.time()-start,
        openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),omp_threads=os.getenv('OMP_NUM_THREADS'),protocol_sha256=ph,source_sha256=bet.sha(Path(__file__)),reused_datasets=4500,new_datasets=10000,records=len(records))
    (args.out/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n');print(json.dumps(metadata,indent=2),flush=True)

if __name__=='__main__':main()
