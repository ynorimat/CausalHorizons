"""Action Adjustment calculations for the causal-horizon experiments."""
from pathlib import Path
import importlib.util,itertools,json,math
import numpy as np
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('newscore',ROOT/'run.py')
new=importlib.util.module_from_spec(spec);spec.loader.exec_module(new)
rng=np.random.default_rng(2026092583)
max_mean=max_var=max_integral=0.;bounded_cases=0;selector_cases=0
for T in [2,4,6]:
 paths=np.array(list(itertools.product([0,1],repeat=T)))
 for baseline_p in [.13,.5,.91]:
  x=np.repeat([-1,1],len(paths));actions=np.tile(paths,(2,1));abar=actions.mean(1)
  mass=np.repeat([1-baseline_p,baseline_p],len(paths))/len(paths)
  y=np.tanh(.4*x+actions[:,0]-1.7*actions[:,-1]+.3*np.prod(2*actions-1,axis=1))
  for coef in [np.array([-2.,3.,4.]),np.array([.2,-.4,.3])]:
   f=np.clip(coef[0]+coef[1]*x+coef[2]*abar,-1,1);policy=new.integrate(coef[None,:],T)
   for h in range(1,T+1):
    ratio=2**h*np.all(actions[:,:h]==1,axis=1)
    q=policy[0,((x+1)/2).astype(int),h-1];z=q+ratio*(y-f)
    truth=mass@(ratio*y);error=abs(mass@z-truth)
    max_mean=max(max_mean,error);bounded_cases+=1
    assert (mass@(z-truth)**2)<=4*2**h+1e-12
    assert abs(z).max()<=2**(h+1)+1+1e-12
for T in [4,16,32]:
 G=np.array([[1.,0.,.5],[0.,1.,0.],[.5,0.,.25+1/(4*T)]])
 assert np.linalg.eigvalsh(G)[0]>=1/(6*T)
 for _ in range(8):
  N=96;train=rng.normal(size=(N,T));valid=rng.normal(size=(N,T))
  tv=train.var(0,ddof=1)[None,:];vv=valid.var(0,ddof=1)[None,:]
  for eps in [.5,2.,5.,10.]:
   def radius(var,j,k):
    lam=math.log(16/.05)+(k-j)*math.log(2)
    return math.sqrt(2*var*lam/N)+7*2*(2**(j+1)+1)*lam/(3*(N-1))
   cap=0
   for k in range(1,T+1):
    if all(radius(tv[0,j-1],j,k)<=eps for j in range(1,k+1)):cap=k
   selected=0
   for j in range(1,cap+1):
    if radius(vv[0,j-1],j,cap)>eps:break
    selected=j
   computed=new.eb_cap(tv,N,eps,0)
   w,_,_=new.widths(vv,N,computed)
   actual=int(np.cumprod((w<=eps)&(np.arange(1,T+1)[None,:]<=computed[:,None]),axis=1).sum())
   assert int(computed[0])==cap and actual==selected
   selector_cases+=1
ratio_max=0.
for alpha in [.001,.01,.05,.249]:
 for k in range(3,101):
  ratio=(2**(k-1)+1)/(2**(k+1)+1)*(1+2*math.log(2)/math.log(16/alpha))
  ratio_max=max(ratio_max,ratio);assert ratio<.5
result=dict(nonadditive_skew_baseline_cases=bounded_cases,max_unbiasedness_error=max_mean,
 independent_scalar_eb_selections=selector_cases,max_two_period_range_ratio=ratio_max)
(ROOT/'results/independent_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
