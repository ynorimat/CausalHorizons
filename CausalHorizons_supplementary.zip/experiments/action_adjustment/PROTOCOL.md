# Action Adjustment

Use Y=.3V+.6 mean(A) with learned baseline, horizon and known-action-adjusted predictors, crossed with empirical Bernstein and fixed-mixture betting intervals. Match the envelope, split, budgets and fallback across six methods on 4500 datasets. A separate noiseless growing-grid study compares EB-H and EB-A on 1000 datasets at each of ten sizes. Retain every cell, paired uncertainty and range/variance diagnostics.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
