"""Paired calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import platform
import numpy as np

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
OUT = ROOT / 'results'
POPS = ['noise', 'near', 'perfect', 'changing']

def read(path):
    opener = gzip.open if path.suffix == '.gz' else Path.open
    with opener(path, 'rt', encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--replay-c', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    inputs = [BASE/'budgets/results/replicates.csv.gz',
              BASE/'budgets/results/summary.csv',
              BASE/'betting/results/replicates.csv.gz',
              BASE/'reporting/results/reporting_summary.csv']
    hashes = {p.relative_to(BASE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    budget, summary = read(inputs[0]), read(inputs[1])
    pilot = [r for r in read(inputs[2]) if r['study'] == 'matched']
    kb = {(r['population'], r['method'], int(r['replicate'])): r for r in budget}
    kp = {(r['population'], r['method'], int(r['replicate'])): r for r in pilot}
    assert len(kb) == len(budget) == 20000
    assert len(kp) == len(pilot) == 16000
    matched, paired = 0, []
    for pop in POPS:
        for rep in range(1000):
            for old, new in [('O', 'O'), ('S_full', 'S')]:
                a, b = kb[pop, old, rep], kp[pop, new, rep]
                for field in ['H', 'cap', 'selected_success', 'candidate_coverage']:
                    assert a[field] == b[field], (pop, rep, field)
                assert float(a['selected_max_error']) == float(b['selected_max_error'])
                matched += 1
        c = np.array([int(kb[pop, 'C_full', i]['H']) for i in range(1000)])
        expected = next(r for r in summary if r['population'] == pop and r['method'] == 'C_full')
        assert float(c.mean()) == float(expected['mean_h'])
        np.testing.assert_allclose(c.std(ddof=1)/np.sqrt(1000), float(expected['h_mcse']), rtol=1e-13, atol=1e-15)
        for method in ['O', 'WA', 'S']:
            other = np.array([int(kp[pop, method, i]['H']) for i in range(1000)])
            diff = c-other
            paired.append(dict(population=pop, left='C', right=method, reps=1000,
                               mean_difference=float(diff.mean()),
                               mcse=float(diff.std(ddof=1)/np.sqrt(1000))))
    with (OUT/'paired_conditional.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(paired[0]))
        writer.writeheader()
        writer.writerows(paired)
    reporting = read(inputs[3])
    assert len([r for r in reporting if r['method']=='C']) == 40
    final_c = next(r for r in reporting if r['method']=='C' and float(r['s'])==.25 and int(r['log2_n'])==32)
    assert int(final_c['empirical_h90']) == 12
    checks = dict(shared_method_records_matched=matched, c_summary_rows_checked=4,
                  paired_comparisons=len(paired), c_reporting_populations=40,
                  new_independent_datasets=0, input_sha256=hashes)
    (OUT/'checks.json').write_text(json.dumps(checks, indent=2)+'\n', encoding='utf-8')
    if args.replay_c:
        spec = importlib.util.spec_from_file_location('matched_budget', BASE/'budgets/run.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        max_diff = 0.
        for index, pop in enumerate(POPS):
            outputs, truth = module.evaluate(index)
            hh, estimates, widths, inside, cap = outputs['C_full']
            chosen = np.arange(1, 25)[None, :] <= hh[:, None]
            errors = np.max(np.where(chosen, np.abs(estimates-truth), 0.), axis=1)
            coverage = np.all((np.abs(estimates-truth) <= widths+1e-12) | ~inside, axis=1)
            for rep in range(1000):
                record = kb[pop, 'C_full', rep]
                assert int(hh[rep]) == int(record['H'])
                assert bool(errors[rep] <= .025+1e-12) == (record['selected_success']=='True')
                assert bool(coverage[rep]) == (record['candidate_coverage']=='True')
                discrepancy = abs(float(errors[rep])-float(record['selected_max_error']))
                assert discrepancy <= 1e-12
                max_diff = max(max_diff, discrepancy)
        replay = dict(datasets_replayed=4000, method='C_full',
                      max_selected_error_discrepancy=max_diff,
                      python=platform.python_version(), numpy=np.__version__)
        (OUT/'replay.json').write_text(json.dumps(replay, indent=2)+'\n', encoding='utf-8')
        print('Replayed all 4000 inherited C records.', flush=True)
    assert hashes == {p.relative_to(BASE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    print(json.dumps(checks, indent=2), flush=True)

if __name__ == '__main__':
    main()
