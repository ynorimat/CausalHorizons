"""Betting calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
import math
import os
import platform
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
spec = importlib.util.spec_from_file_location('betting_v4', PACKAGE/'reporting/run.py')
betting = importlib.util.module_from_spec(spec)
spec.loader.exec_module(betting)
comparison = betting.comparison
ALPHA, M = .05, 1.


def evidence(values, counts, epsilon):
    """Min log wealth at the two endpoints around the empirical mean.

    values and epsilon are on the normalized [0,1] scale. A mean-zero
    or mean-one null also needs no test when it is on the support endpoint.
    """
    mean = (values*counts).sum(axis=1)/counts.sum(axis=1)
    lower, upper = mean-epsilon, mean+epsilon
    left = betting.logwealth(values, counts, np.where(lower > 0, lower, .5))
    right = betting.logwealth(1-values, counts, np.where(upper < 1, 1-upper, .5))
    return np.minimum(np.where(lower > 0, left, np.inf),
                      np.where(upper < 1, right, np.inf))


def width_evidence(counts, group, y, length, predictor, epsilon, T):
    result = np.empty((len(counts), T))
    for h in range(1, T+1):
        scores, cc = betting.score_histogram(counts, group, y, length, predictor, h)
        support = M*(2**(h+1)-1)
        vv = (scores+support)/(2*support)
        result[:, h-1] = evidence(vv, cc, epsilon/(2*support))
    return result


def select_cap(ev, fallback):
    h = np.arange(1, ev.shape[1]+1)
    # For candidate k, the cutoff is log(8/alpha)+(k-h)*log(2).
    feasible = np.minimum.accumulate(ev+h*math.log(2), axis=1) > (
        math.log(8/ALPHA)+h*math.log(2))
    return np.maximum(fallback, np.max(np.where(feasible, h, 0), axis=1)).astype(int)


def select(ev, cap, fallback):
    h = np.arange(1, ev.shape[1]+1)[None, :]
    inside = h <= cap[:, None]
    good = ev > (math.log(8/ALPHA)+(cap[:, None]-h)*math.log(2))
    return np.maximum(fallback, np.cumprod(good & inside, axis=1).sum(axis=1)).astype(int)


def band_coverage(counts, group, y, length, predictor, cap, truth):
    covered = np.ones(len(counts), dtype=bool)
    for h in range(1, int(cap.max())+1):
        ids = np.flatnonzero(cap >= h)
        scores, cc = betting.score_histogram(counts[ids], group, y, length, predictor[ids], h)
        support = M*(2**(h+1)-1)
        vv = (scores+support)/(2*support)
        target = np.full(len(ids), (truth[h-1]+support)/(2*support))
        cutoff = math.log(8/ALPHA)+(cap[ids]-h)*math.log(2)
        good = (betting.logwealth(vv, cc, target) <= cutoff)
        good &= (betting.logwealth(1-vv, cc, 1-target) <= cutoff)
        covered[ids] &= good
    return covered


def evaluate(train, valid, group, y, length, ind, ratios, truth, epsilon):
    methods, fallback = comparison.evaluate(train, valid, group, y, ind, ratios, epsilon)
    ho, est, wo, inside, cap = methods['O']
    pred = comparison.old.fit_group_means(train, group, y)
    T = ind.shape[1]
    training_ev = width_evidence(train, group, y, length, pred, epsilon, T)
    validation_ev = width_evidence(valid, group, y, length, pred, epsilon, T)
    cap_wa = select_cap(training_ev, fallback)
    out = {'O': (ho, est, cap, np.all((abs(est-truth) <= wo+1e-12) | ~inside, axis=1))}
    for name, selected_cap in [('W', cap), ('WA', cap_wa)]:
        hh = select(validation_ev, selected_cap, fallback)
        cov = band_coverage(valid, group, y, length, pred, selected_cap, truth)
        out[name] = (hh, est, selected_cap, cov)
    hs, es, ws, ins, cs = methods['S']
    out['S'] = (hs, es, cs, np.all(abs(es-truth) <= ws+1e-12, axis=1))
    return out


def contamination(T, hstar, delta):
    l,g,x,y,p,_,_,_ = comparison.population(T, 1.)
    keep = p > 0
    l,g,x,y,p = (a[keep] for a in [l,g,x,y,p])
    prob = delta*(l >= hstar)
    pp = np.concatenate([p*(1-prob), p*prob])
    ll,gg = np.tile(l,2),np.tile(g,2)
    yy = np.concatenate([y,np.ones_like(y)])
    keep = pp > 0
    ll,gg,yy,pp = (a[keep] for a in [ll,gg,yy,pp])
    h = np.arange(1,T+1)
    ind = (ll[:,None] >= h).astype(float)
    ratios = ind*np.exp2(h)
    truth = delta*np.minimum(1.,np.exp2(h-hstar))
    np.testing.assert_allclose(pp.sum(),1.,atol=2e-15)
    np.testing.assert_allclose(pp@(yy[:,None]*ratios),truth,atol=2e-15)
    return ll,gg,yy,pp,ind,ratios,truth


def checks():
    rng = np.random.default_rng(2026092552)
    count = 0
    max_error = 0.
    for n in [8,32,256]:
        vv = rng.uniform(0,1,(12,5))
        cc = rng.multinomial(n,np.ones(5)/5,size=12)
        for eps in [.05,.15,.4]:
            ev = evidence(vv,cc,eps)
            for level in [.01,.05,.2]:
                lo,hi = betting.betting_interval(vv,cc,level)
                mean = (vv*cc).sum(1)/n
                radius = np.maximum(mean-lo,hi-mean)
                reliable = abs(radius-eps) > 2e-10
                assert np.array_equal((ev > np.log(2/level))[reliable],(radius < eps)[reliable])
                count += int(reliable.sum())
    # Independent expansion checks both fitted-score evidence and pilot search.
    T=5
    l,g,x,y,p,ind,ratios,truth = comparison.population(T,.8)
    train = rng.multinomial(128,p,size=5)
    pred = comparison.old.fit_group_means(train,g,y)
    ev = width_evidence(train,g,y,l,pred,.3,T)
    expanded = np.empty_like(ev)
    for rep in range(len(train)):
        ids = np.repeat(np.arange(len(p)),train[rep])
        q = pred[rep,g[ids]]
        for h in range(1,T+1):
            scores = q+2**h*(l[ids]>=h)*(y[ids]-q)
            support=M*(2**(h+1)-1)
            expanded[rep,h-1] = evidence(((scores+support)/(2*support))[None,:],
                np.ones((1,len(ids)),dtype=int),.3/(2*support))[0]
    max_error = float(np.max(abs(expanded-ev)))
    np.testing.assert_allclose(expanded,ev,atol=2e-11)
    brute=[]
    for row in expanded:
        feasible=[0]
        for k in range(1,T+1):
            if all(row[h-1] > math.log(8/ALPHA)+(k-h)*math.log(2) for h in range(1,k+1)):
                feasible.append(k)
        brute.append(max(feasible))
    assert np.array_equal(brute,select_cap(ev,0))
    for hstar in [4,6,8,12]:
        for delta in [.05,.1,.15,.25]:contamination(24,hstar,delta)
    # Nonbinary covariate, nonconstant conditional noise, biased predictor.
    px=np.array([.2,.3,.5]); mu=np.array([-.3,.1,.4]); noise=np.array([.1,.2,.3]); q=np.array([-.2,-.1,.45])
    sigma=float(px@(noise**2)); risk=float(px@((q-mu)**2))
    baseline=float(px@(mu**2)-(px@mu)**2)
    verrors=[]
    for h in [1,3,7]:
        prob=[]; vals=[]
        for j in range(3):
            for sign in [-1,1]:
                for treated in [0,1]:
                    mass=px[j]/2*(2.**(-h) if treated else 1-2.**(-h))
                    prob.append(mass);vals.append(q[j]+2**h*treated*(mu[j]+sign*noise[j]-q[j]))
        prob,vals=np.array(prob),np.array(vals)
        exact=float(prob@(vals**2)-(prob@vals)**2)
        claimed=baseline+2**h*sigma+(2**h-1)*risk
        verrors.append(abs(exact-claimed));assert abs(exact-claimed)<1e-12
    # Validate the actual large-sample pilots and reports by interval inversion.
    # This uses a subset of each prespecified population, with exactly the
    # production sample sizes, support and error allocations.
    actual_cases=0
    for idx,(kappa,d) in enumerate([(0.,0),(.99,0),(1.,0),(1.,6)]):
        T=24;epsilon=.025;N=131072
        l,g,x,y,p,ind,ratios,truth=comparison.population(T,kappa,d)
        rrng=np.random.default_rng(np.random.SeedSequence([2026092503,idx]))
        train=rrng.multinomial(N,p,size=1000)
        valid=rrng.multinomial(N,p,size=1000)
        train,valid=train[:30],valid[:30]
        predictor=comparison.old.fit_group_means(train,g,y)
        te=width_evidence(train,g,y,l,predictor,epsilon,T)
        cap=select_cap(te,0)
        for sample in [train,valid]:
            ev=width_evidence(sample,g,y,l,predictor,epsilon,T)
            direct=select(ev,cap,0)
            widths=np.full(ev.shape,np.inf)
            for h in range(1,int(cap.max())+1):
                ids=np.flatnonzero(cap>=h)
                z,cc=betting.score_histogram(sample[ids],g,y,l,predictor[ids],h)
                support=M*(2**(h+1)-1)
                levels=(ALPHA/2)*np.exp2(h-cap[ids]-1.)
                lo,hi=betting.betting_interval((z+support)/(2*support),cc,levels)
                mean=(z*cc).sum(1)/N
                widths[ids,h-1]=np.maximum(mean-(2*support*lo-support),2*support*hi-support-mean)
                actual_cases+=len(ids)
            inverse=np.cumprod(widths<=epsilon,axis=1).sum(axis=1)
            assert np.array_equal(direct,inverse),(idx,direct,inverse)
    return dict(inversion_decisions_checked=count,actual_sample_interval_decisions=actual_cases,expanded_score_cases=25,
        expanded_evidence_max_error=max_error,brute_force_pilots_checked=5,
        contamination_truth_cases=16,nonbinary_variance_cases=3,variance_max_error=max(verrors))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    start=time.time();check=checks()
    (args.out/'checks.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf-8')
    if args.check: print(json.dumps(check,indent=2));return
    protocol_hash=betting.sha(ROOT/'PROTOCOL.md')
    summaries=[];records=[];paired=[];survival=[]
    def run_population(study,name,n,T,epsilon,parts,seed,hstar=0,delta=0.):
        length,group,y,p,ind,ratios,truth=parts
        rng=np.random.default_rng(np.random.SeedSequence(seed))
        train=rng.multinomial(n//2,p,size=1000);valid=rng.multinomial(n//2,p,size=1000)
        methods=evaluate(train,valid,group,y,length,ind,ratios,truth,epsilon)
        base=dict(study=study,population=name,n=n,T=T,epsilon=epsilon,hstar=hstar,delta=delta)
        for label,(hh,est,cap,cov) in methods.items():
            chosen=np.arange(1,T+1)[None,:]<=hh[:,None]
            errors=np.max(np.where(chosen,abs(est-truth),0.),axis=1)
            success=errors<=epsilon+1e-12
            row=dict(base,method=label,repetitions=1000,mean_h=float(hh.mean()),
                h_mcse=float(hh.std(ddof=1)/math.sqrt(1000)),empirical_h90=betting.frequent_horizon(hh,T),
                mean_cap=float(cap.mean()),selected_accuracy=float(success.mean()),
                candidate_coverage=float(cov.mean()),abstention=float(np.mean(hh==0)),error_q95=float(np.quantile(errors,.95)))
            summaries.append(row)
            for rep in range(1000):
                records.append(dict(base,method=label,replicate=rep,H=int(hh[rep]),cap=int(cap[rep]),
                    selected_max_error=float(errors[rep]),selected_success=bool(success[rep]),candidate_coverage=bool(cov[rep])))
            for h in range(1,T+1):
                num=int(np.sum(hh>=h));lo,hi=betting.wilson(num,1000)
                survival.append(dict(base,method=label,horizon=h,successes=num,repetitions=1000,
                    reporting_frequency=num/1000,wilson_lower=lo,wilson_upper=hi))
        for a,b in [('W','O'),('WA','O'),('WA','W'),('S','WA')]:
            diff=methods[a][0]-methods[b][0]
            paired.append(dict(base,comparison=a+'-'+b,mean_difference=float(diff.mean()),
                difference_mcse=float(diff.std(ddof=1)/math.sqrt(1000)),fraction_longer=float(np.mean(diff>0))))
        print(study,name,{k:float(v[0].mean()) for k,v in methods.items()},flush=True)
    for idx,(name,kappa,d) in enumerate([('noise',0.,0),('near',.99,0),('perfect',1.,0),('changing',1.,6)]):
        l,g,x,y,p,ind,ratios,truth=comparison.population(24,kappa,d)
        run_population('matched',name,262144,24,.025,(l,g,y,p,ind,ratios,truth),[2026092503,idx])
    inherited=list(csv.DictReader((PACKAGE/'reporting/results/betting_summary.csv').open(encoding='utf-8')))
    for row in summaries:
        if row['method'] in ['O','W']:
            old=next(x for x in inherited if x['population']==row['population'] and x['method']==row['method'])
            for field in ['mean_h','empirical_h90','selected_accuracy','candidate_coverage','abstention']:
                assert row[field]==float(old[field]),(row['population'],row['method'],field)
    for hstar in [4,6,8,12]:
        for delta in [.05,.10,.15,.25]:
            run_population('contamination',f'h{hstar}_d{delta}',65536,24,.05,
                contamination(24,hstar,delta),[2026092505,hstar,round(1000*delta)],hstar,delta)
    for filename,rows in [('summary.csv',summaries),('paired.csv',paired),('survival.csv',survival),('replicates.csv.gz',records)]:
        betting.save_csv(args.out/filename,rows)
    assert betting.sha(ROOT/'PROTOCOL.md')==protocol_hash
    meta=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),processor=platform.processor(),
        elapsed_seconds=time.time()-start,openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),omp_threads=os.getenv('OMP_NUM_THREADS'),
        protocol_sha256=protocol_hash,source_sha256=betting.sha(Path(__file__)),reused_datasets=4000,new_datasets=16000,
        populations=20,methods=4,records=len(records),inherited_O_W_summaries_reproduced=True)
    (args.out/'environment.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(meta,indent=2),flush=True)


if __name__=='__main__':main()
