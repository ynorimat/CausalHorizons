# Betting

Compare O, W, WA and S on the same 4000 matched datasets. WA uses the fixed 17-bet mixture to select its own training cap. A separate contamination design has 16 populations and 1000 independent datasets each. Record length, selected accuracy, abstention, candidate coverage, errors, paired differences and survival frequencies in every condition.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
