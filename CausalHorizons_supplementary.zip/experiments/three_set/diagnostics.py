"""Audit stopping stages by reanalyzing saved records; no new simulations."""
from pathlib import Path
import csv
import gzip
import hashlib
import json
import math
import collections

ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'

def generate():
    groups={}
    path=RESULTS/'replicates.csv.gz'
    with gzip.open(path,'rt',newline='',encoding='utf-8') as f:
        for r in csv.DictReader(f):
            if r['method']!='A3': continue
            key=(r['law'],int(r['n']),float(r['tau']),r['tolerance'])
            g=groups.setdefault(key,dict(base={k:r[k] for k in ['law','n','T','tau','tolerance','epsilon']},
                                        counts=collections.Counter(),ratios=[]))
            c=g['counts'];c['reps']+=1
            n=int(r['n']);N=n//3;K=int(r['cap']);H=int(r['H']);T=int(r['T']);eps=float(r['epsilon'])
            assert n%3==0 and K<T and H==K
            # Test the whole next candidate, using only its deterministic range
            # component. A first failing coordinate can instead involve variance.
            k=K+1
            max_range=max(14*(2**(h+1)+1)*(math.log(16/.05)+(k-h)*math.log(2))/(3*(N-1))
                          for h in range(1,k+1))
            ratio=max_range/eps
            assert abs(ratio-1)>1e-10
            range_blocks=ratio>1
            first_range=int(r['range_blocked'])
            assert not first_range or range_blocks
            c['sum_H']+=H;c['sum_K']+=K
            c['cap_below_T']+=1;c['H_equals_cap']+=1
            c['range_alone_blocks_next_cap']+=int(range_blocks)
            c['variance_needed_next_cap']+=int(not range_blocks)
            c['first_failure_range_blocked']+=first_range
            assert int(r['validation_shorter'])==0
            g['ratios'].append(ratio)
    rows=[]
    summary={(r['law'],int(r['n']),float(r['tau']),r['tolerance']):r
             for r in csv.DictReader((RESULTS/'summary.csv').open(encoding='utf-8')) if r['method']=='A3'}
    for key,g in groups.items():
        c=g['counts'];reps=c['reps'];s=summary[key]
        assert reps==1000
        assert c['sum_H']/reps==float(s['mean_h'])
        assert c['first_failure_range_blocked']/reps==float(s['range_blocked'])
        assert c['range_alone_blocks_next_cap'] in [0,reps]
        row=dict(g['base'],reps=reps,mean_H=c['sum_H']/reps,mean_K=c['sum_K']/reps)
        for name in ['cap_below_T','H_equals_cap','range_alone_blocks_next_cap',
                     'variance_needed_next_cap','first_failure_range_blocked']:
            row[name]=c[name]/reps
        row.update(min_next_range_ratio=min(g['ratios']),max_next_range_ratio=max(g['ratios']))
        rows.append(row)
    assert len(rows)==36
    result=dict(conditions=36,method_condition_records=36000,independent_datasets=18000,
                new_datasets=0,all_reports_equal_pilot_cap=True,all_caps_below_T=True,
                range_alone_conditions=sum(r['range_alone_blocks_next_cap']==1 for r in rows),
                variance_required_conditions=sum(r['variance_needed_next_cap']==1 for r in rows),
                first_failure_range_conditions=sum(r['first_failure_range_blocked']==1 for r in rows),
                source_sha256={name:hashlib.sha256((RESULTS/name).read_bytes()).hexdigest()
                               for name in ['replicates.csv.gz','summary.csv']})
    assert result['range_alone_conditions']==30 and result['variance_required_conditions']==6
    assert result['first_failure_range_conditions']==22
    with (RESULTS/'stopping_summary.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (RESULTS/'stopping_checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result

if __name__=='__main__': print(json.dumps(generate(),indent=2))
