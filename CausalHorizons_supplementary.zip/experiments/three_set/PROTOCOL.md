# Three-set performance comparison

The design below is fixed before running the study. This is an exploratory
simulation with a recorded design, not an independent preregistration.
All cells and all methods are retained regardless of their ranking.

## Populations

Let X and E be independent fair signs, independent of T fair binary actions.
Put U = T^(-1) sum_t (2 A_t - 1) and

    Y = .35 X + .10 U + d X U + tau (1 + lambda X U) E.

Use two laws: additive (d = lambda = 0) and interaction
(d = .30, lambda = .5). The supplied outcome bound is M = 1;
all generated outcomes satisfy |Y| <= .975. The true prefix mean is
.10 h/T. Cross each law with tau = 0, .05, .15 and total sample sizes
n = 6 * 2^k for k = 10, 13, 16 (6144, 49152, 393216).
Set T = ceil(log2(n)), alpha = .05, and run 1000 independent datasets
per population: 18 populations and 18000 independent datasets total.

Evaluate both epsilon = .025 and epsilon = n^(-1/4) on each dataset.
These are 36 tolerance/population conditions, not 36000 independent
datasets. The main-text table is fixed to n = 393216, epsilon = .025,
both laws and all three noise levels. Appendix tables include every cell.

## Samples and methods

Generate six independent equal blocks of n/6 observations. Sampling uses
exact multinomial counts indexed by initial treated-run length, total
treated actions, X and E. This is exactly the distribution of the needed
statistics from individual independent trajectories, not an approximation.

- A3: fit least squares on (1, X, U, X U) on blocks 1--2, select its cap
  from blocks 3--4, and validate on blocks 5--6.
- A3-add: same splits, but fit (1, X, U), omitting the interaction.
- A3-noX: same splits, but fit (1, U), omitting the baseline and interaction.
- A3-oracle: same pilot and validation samples, with the true conditional
  mean supplied only as a diagnostic reference. It is not a feasible learner.
- A2: fit the full four-feature model on blocks 1--3, use those same
  observations for its fitted pilot, and validate on blocks 4--6.
- C: the paper's full-data conditional-mean certificate, using all six blocks.
- S: the paper's full-data stratified certificate, using all six blocks and J=T.

Clip all predictions to [-1,1] before exact binomial integration over the
natural suffix actions. All A methods use empirical Bernstein intervals,
range 2 M (2^(h+1)+1), geometric error allocation, and the same fallback
formula evaluated at their own validation size. A2 therefore has n/2
validation observations and the A3 methods n/3. C and S use the paper's
full-data ranges and simultaneous allocations; interval allocation and
sample budget differences are reported, not attributed only to prediction.
No method is selected or tuned using validation performance.

## Outcomes and comparisons

For every method and condition, save mean reported length and its MCSE,
the empirical 90%-report threshold, abstention, simultaneous selected
accuracy, selected-error quantiles, and candidate/fixed-grid coverage.
An empty report is accurate by convention, so accuracy is always paired
with abstention and length. Save all per-dataset errors and selected lengths.

Prespecified paired length differences: A3 minus A2, C, S, A3-add,
A3-noX, and A3-oracle. Report their mean, MCSE, and win/tie/loss fractions.
Also record range-limited caps, validation shortening, and population
prediction risk under natural actions and every prefix. Prediction-risk
and true-mean calculations are diagnostics unavailable to the procedures.
No empirical superiority or positive difference is required for inclusion.

The master seed is 2026092612. Population seeds are constructed from it,
law index, size index, and noise index using NumPy SeedSequence; each block
has its own child seed. Checks use a separate seed 2026092613 and small
samples, and are not used to alter the design. Record protocol and source
hashes and runtime versions. Replaying uses the same child streams and
compares all result records. Numerical checks compare compressed data
against individually expanded trajectories and exact population identities.
