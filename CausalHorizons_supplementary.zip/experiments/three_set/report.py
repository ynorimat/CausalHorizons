"""Audit saved three-set comparisons and write numerical report checks."""
from pathlib import Path
import csv
import json

ROOT=Path(__file__).resolve().parent
def read(name):
    with (ROOT/'results'/name).open(newline='',encoding='utf-8') as f:
        return list(csv.DictReader(f))
rows=read('summary.csv');paired=read('paired.csv')
stopping={(r['law'],int(r['n']),float(r['tau']),r['tolerance']):r for r in read('stopping_summary.csv')}
methods=['C','S','A2','A3','A3-add','A3-noX','A3-oracle']
key=lambda r:(r['law'],int(r['n']),float(r['tau']),r['tolerance'])
table={}
for row in rows:table.setdefault(key(row),{})[row['method']]=row
assert len(rows)==252 and len(table)==36 and all(set(g)==set(methods) for g in table.values())
for law in ['additive','interaction']:
    for tau in [0.,.05,.15]:
        group=table[(law,393216,tau,'fixed')]
        assert all(float(group[m]['h_mcse'])==0 for m in ['C','S','A2','A3'])
    for n in [6144,49152,393216]:
        for tau in [0.,.05,.15]:
            for tol in ['fixed','shrinking']:
                g=table[(law,n,tau,tol)]
                assert all(float(g[m]['selected_accuracy'])==1 for m in methods)
                expected_abstain=1 if n==6144 and tol=='fixed' else 0
                assert all(float(g[m]['abstention'])==expected_abstain for m in methods)
                float(stopping[(law,n,tau,tol)]['range_alone_blocks_next_cap'])

comparison={}
for other in methods:
    if other=='A3':continue
    rr=[r for r in paired if r['right']==other]
    assert len(rr)==36
    differences=[float(r['mean_difference']) for r in rr]
    comparison[other]=dict(lower=sum(d<0 for d in differences),equal=sum(d==0 for d in differences),
                           higher=sum(d>0 for d in differences),min_difference=min(differences),
                           max_difference=max(differences),max_mcse=max(float(r['mcse']) for r in rr),
                           all_pairs_equal=all(float(r['tie'])==1 for r in rr))
assert comparison['A2']['lower']==18 and comparison['A2']['higher']==0
assert comparison['A3-oracle']['all_pairs_equal']
assert comparison['A3-add']['higher']==3 and comparison['A3-noX']['higher']==18
split=[r for r in rows if r['method']=='A3']
audit=dict(independent_datasets=18000,conditions=36,methods=7,records=252000,
           selected_accuracy_min=min(float(r['selected_accuracy']) for r in rows),
           candidate_coverage_min=min(float(r['candidate_coverage']) for r in rows),
           all_abstention_conditions=6,comparison=comparison,
           A3_range_block_fraction_min=min(float(r['range_blocked']) for r in split),
           A3_range_block_fraction_max=max(float(r['range_blocked']) for r in split))
(ROOT/'results/report_checks.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
print(json.dumps(audit,indent=2))
