"""Paired finite-sample study of the three-set action-adjusted certificate."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import importlib.util
import itertools
import json
import math
import os
import platform
import time

os.environ.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
import numpy as np

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stratified_reference',ROOT.parent/'binary/run.py')
binary=importlib.util.module_from_spec(spec)
spec.loader.exec_module(binary)
kernel=binary.old
M,ALPHA,B,A=1.,.05,.35,.10
REPS,SEED=1000,2026092612
METHODS=['C','S','A2','A3','A3-add','A3-noX','A3-oracle']
LAWS=[('additive',0.,0.),('interaction',.30,.5)]
SIZES=[6*2**k for k in [10,13,16]]
NOISE=[0.,.05,.15]


def population(T,d,lam,tau):
    rows=[]
    for ell in range(T+1):
        suffix=T-ell-1
        for k in range(max(suffix+1,1)):
            pa=2.**(-T) if ell==T else math.comb(suffix,k)*2.**(-T)
            for x in [-1.,1.]:
                for e in [-1.,1.]:
                    total=ell+k
                    u=2*total/T-1
                    f=B*x+A*u+d*x*u
                    y=f+tau*(1+lam*x*u)*e
                    rows.append([ell,total,x,e,u,f,y,pa/4])
    data=np.array(rows)
    ell,total,x,e,u,f,y,p=data.T
    ind=(ell[:,None]>=np.arange(1,T+1)).astype(float)
    design=np.column_stack([np.ones(len(x)),x,u,x*u])
    return dict(data=data,ell=ell,total=total,x=x,e=e,u=u,f=f,y=y,p=p,ind=ind,
                design=design,T=T,d=d,lam=lam,tau=tau,truth=A*np.arange(1,T+1)/T)


def fit(counts,pop,columns=(0,1,2,3)):
    design=pop['design'][:,columns]
    n=counts.sum(axis=1)
    gram=np.einsum('rc,ci,cj->rij',counts,design,design,optimize=True)/n[:,None,None]
    rhs=(counts@(design*pop['y'][:,None]))/n[:,None]
    fitted=np.stack([np.linalg.lstsq(g,b,rcond=None)[0] for g,b in zip(gram,rhs)])
    coef=np.zeros((len(counts),4))
    coef[:,columns]=fitted
    return coef


def integrate(coef,T):
    q=np.empty((len(coef),2,T))
    for h in range(1,T+1):
        k=np.arange(T-h+1)
        weight=np.array([math.comb(T-h,int(j))*2.**(-(T-h)) for j in k])
        u=2*(h+k)/T-1
        for g,x in enumerate([-1.,1.]):
            design=np.column_stack([np.ones(len(k)),np.full(len(k),x),u,x*u])
            q[:,g,h-1]=np.clip(coef@design.T,-M,M)@weight
    return q


def score_moments(counts,pop,coef,q=None):
    T=pop['T']
    q=integrate(coef,T) if q is None else q
    factual=np.clip(coef@pop['design'].T,-M,M)
    residual=pop['y'][None,:]-factual
    g=((pop['x']+1)/2).astype(int)
    n=counts.sum(axis=1)
    means=np.empty((len(counts),T)); variances=np.empty_like(means)
    for hi in range(T):
        R=2.**(hi+1)*pop['ind'][:,hi]
        z=q[:,g,hi]+R*residual
        mu=(counts*z).sum(axis=1)/n
        means[:,hi]=mu
        variances[:,hi]=(counts*(z-mu[:,None])**2).sum(axis=1)/(n-1)
    return means,variances


def prediction_risks(coef,pop):
    err=(np.clip(coef@pop['design'].T,-M,M)-pop['f'][None,:])**2
    ordinary=err@pop['p']
    prefix=(err*pop['p'])@pop['ind']*2.**np.arange(1,pop['T']+1)
    return ordinary,prefix


def widths(var,N,cap):
    h=np.arange(1,var.shape[1]+1)[None,:]
    cap=np.broadcast_to(np.asarray(cap),len(var))[:,None]
    lam=math.log(16/ALPHA)+np.maximum(cap-h,0)*math.log(2)
    root=np.sqrt(2*var*lam/N)
    ran=np.broadcast_to(7*2*M*(2.**(h+1)+1)*lam/(3*(N-1)),var.shape)
    return root+ran,root,ran


def select(tv,vv,N,epsilon):
    T=tv.shape[1]
    k0=max(0,min(T,math.floor(math.log2(N*epsilon**2/(10*M*M*math.log(8/ALPHA))))))
    cap=np.full(len(tv),k0,dtype=int)
    for k in range(1,T+1):
        w,_,_=widths(tv[:,:k],N,k)
        cap=np.where(np.all(w<=epsilon,axis=1),np.maximum(cap,k),cap)
    w,_,_=widths(vv,N,cap)
    h=np.arange(1,T+1)[None,:]
    inside=h<=cap[:,None]
    H=np.maximum(k0,np.cumprod((w<=epsilon)&inside,axis=1).sum(axis=1)).astype(int)
    next_cap=np.minimum(cap+1,T)
    pw,root,ran=widths(tv,N,next_cap)
    failing=(pw>epsilon)&(h<=next_cap[:,None])
    first=np.argmax(failing,axis=1)
    blocked=(cap<T)&np.any(failing,axis=1)
    range_blocked=blocked&(ran[np.arange(len(tv)),first]>=epsilon)
    return dict(H=H,cap=cap,width=w,inside=inside,fallback=k0,
                range_blocked=range_blocked,validation_shorter=H<cap)


def prepare(blocks,pop):
    fit3=blocks[0]+blocks[1]
    pilot3=blocks[2]+blocks[3]
    valid3=blocks[4]+blocks[5]
    fit2=fit3+blocks[2]
    valid2=blocks[3]+valid3
    all_counts=fit2+valid2
    R=len(all_counts);T=pop['T']
    coefficients={
        'A2':fit(fit2,pop),'A3':fit(fit3,pop),
        'A3-add':fit(fit3,pop,(0,1,2)),
        'A3-noX':fit(fit3,pop,(0,2)),
        'A3-oracle':np.broadcast_to([0.,B,A,pop['d']],(R,4)).copy()}
    prepared={};risk={}
    for name,co in coefficients.items():
        pilot,valid=(fit2,valid2) if name=='A2' else (pilot3,valid3)
        q=integrate(co,T)
        _,tv=score_moments(pilot,pop,co,q)
        vm,vv=score_moments(valid,pop,co,q)
        prepared[name]=dict(tv=tv,vv=vv,means=vm,N=int(valid[0].sum()))
        if name!='A3-oracle':risk[name]=prediction_risks(co,pop)
    cm,cv,cn=kernel.conditional_moments(all_counts,pop['y'],pop['ind'])
    cr=kernel.eb(cv,cn,2*M,ALPHA/T)
    prepared['C']=dict(means=cm,width=cr)
    sm,sr,_,_=binary.stratified(all_counts,((pop['x']+1)/2).astype(int),pop['y'],pop['ind'])
    prepared['S']=dict(means=sm,width=sr)
    return prepared,risk,coefficients


def evaluate(prepared,pop,epsilon):
    out={};T=pop['T']
    for name in METHODS:
        p=prepared[name]
        if name.startswith('A'):
            item=select(p['tv'],p['vv'],p['N'],epsilon)
        else:
            size=len(p['means'])
            item=dict(H=np.cumprod(p['width']<=epsilon,axis=1).sum(axis=1).astype(int),
                      cap=np.full(size,T),width=p['width'],inside=np.ones_like(p['width'],bool),
                      fallback=0,range_blocked=np.zeros(size,bool),validation_shorter=np.zeros(size,bool))
        out[name]=dict(item,means=p['means'])
    return out


def wilson(success,n):
    p=success/n;z=1.959963984540054
    mid=(p+z*z/(2*n))/(1+z*z/n)
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/(1+z*z/n)
    return mid-half,mid+half


def checks():
    rng=np.random.default_rng(2026092613)
    truth_err=gram_err=variance_err=fit_err=moment_err=integration_err=kl_err=shift_err=0.
    law_cases=expanded_cases=0
    for T in [3,5,7]:
        paths=np.array(list(itertools.product([0,1],repeat=T)))
        law={}
        for path in paths:
            ell=next((i for i,a in enumerate(path) if a==0),T)
            law[(ell,int(sum(path)))]=law.get((ell,int(sum(path))),0)+2.**(-T)
        for d,lam in [(0.,0.),(.3,.5)]:
            p=population(T,d,lam,.15)
            np.testing.assert_allclose(p['p'].sum(),1.,atol=1e-14)
            assert max(abs(p['y']))<=.975+1e-12
            for key,mass in law.items():
                observed=p['p'][(p['ell']==key[0])&(p['total']==key[1])].sum()
                np.testing.assert_allclose(observed,mass,atol=1e-14)
            truth_err=max(truth_err,float(np.max(abs(p['p']@(p['y'][:,None]*p['ind'])*2.**np.arange(1,T+1)-p['truth']))))
            G=p['design'].T@(p['p'][:,None]*p['design'])
            gram_err=max(gram_err,float(np.max(abs(G-np.diag([1,1,1/T,1/T])))))
            for h in range(1,T+1):
                ratio=2.**h*p['ind'][:,h-1]
                q=(B+d*h/T)*p['x']+A*h/T
                z=q+ratio*(p['y']-p['f'])
                sig=.15**2*(1+lam**2*(h*h+T-h)/(T*T))
                expected=(B+d*h/T)**2+2**h*sig
                variance_err=max(variance_err,abs(p['p']@(z-p['truth'][h-1])**2-expected))
                theta=.07
                alternative=p['p']*(1+2*theta*p['e']*p['ind'][:,h-1])
                kl=np.sum(p['p']*np.log(p['p']/alternative))
                expected_kl=2.**(-h)*(-.5*math.log(1-4*theta*theta))
                kl_err=max(kl_err,abs(kl-expected_kl))
                shift=(alternative-p['p'])@(ratio*p['y'])
                shift_err=max(shift_err,abs(shift-2*.15*theta))
                law_cases+=1
            blocks=[rng.multinomial(32,p['p'],size=2) for _ in range(6)]
            prepared,_,coefficients=prepare(blocks,p)
            for name in ['A2','A3','A3-add','A3-noX','A3-oracle']:
                train=blocks[0]+blocks[1]
                pilot=blocks[2]+blocks[3];valid=blocks[4]+blocks[5]
                if name=='A2':train=train+blocks[2];pilot=train;valid=blocks[3]+valid
                cols={'A3-add':(0,1,2),'A3-noX':(0,2)}.get(name,(0,1,2,3))
                co=coefficients[name]
                for rep in range(2):
                    ids=np.repeat(np.arange(len(p['p'])),train[rep])
                    if name!='A3-oracle':
                        direct=np.linalg.lstsq(p['design'][ids][:,cols],p['y'][ids],rcond=None)[0]
                        fit_err=max(fit_err,float(np.max(abs(direct-co[rep,list(cols)]))))
                    q=integrate(co[rep:rep+1],T)[0]
                    for g,x in enumerate([-1,1]):
                        u=2*paths.mean(axis=1)-1
                        fact=np.clip(co[rep]@np.array([np.ones(len(paths)),np.full(len(paths),x),u,x*u]),-M,M)
                        for h in range(1,T+1):
                            integration_err=max(integration_err,abs(fact[np.all(paths[:,:h]==1,axis=1)].mean()-q[g,h-1]))
                    for counts,key_mean,key_var in [(pilot,None,'tv'),(valid,'means','vv')]:
                        ix=np.repeat(np.arange(len(p['p'])),counts[rep])
                        g=((p['x'][ix]+1)/2).astype(int)
                        f=np.clip(p['design'][ix]@co[rep],-M,M)
                        z=q[g,:]+p['ind'][ix]*2.**np.arange(1,T+1)*(p['y'][ix]-f)[:,None]
                        if key_mean:
                            moment_err=max(moment_err,float(np.max(abs(z.mean(axis=0)-prepared[name][key_mean][rep]))))
                        moment_err=max(moment_err,float(np.max(abs(z.var(axis=0,ddof=1)-prepared[name][key_var][rep]))))
                        expanded_cases+=1
            out=evaluate(prepared,p,.25)
            for name in ['A2','A3','A3-add','A3-noX','A3-oracle']:
                N=prepared[name]['N'];k0=out[name]['fallback']
                for rep in range(2):
                    def radius(var,h,k):
                        l=math.log(16/ALPHA)+(k-h)*math.log(2)
                        return math.sqrt(2*var[h-1]*l/N)+7*2*M*(2**(h+1)+1)*l/(3*(N-1))
                    tv=prepared[name]['tv'][rep];vv=prepared[name]['vv'][rep]
                    K=max([k0]+[k for k in range(1,T+1) if all(radius(tv,h,k)<=.25 for h in range(1,k+1))])
                    H=max([k0]+[k for k in range(1,K+1) if all(radius(vv,h,K)<=.25 for h in range(1,k+1))])
                    assert out[name]['cap'][rep]==K and out[name]['H'][rep]==H
            # Hold fitting and pilot fixed while changing validation: A3 cap is unchanged.
            changed=blocks[:4]+[rng.multinomial(32,p['p'],size=2) for _ in range(2)]
            pp,_,cc=prepare(changed,p)
            other=evaluate(pp,p,.25)
            for name in ['A3','A3-add','A3-noX','A3-oracle']:
                np.testing.assert_array_equal(coefficients[name],cc[name])
                np.testing.assert_array_equal(out[name]['cap'],other[name]['cap'])
    # Active clipping and singular-design behavior are checked separately.
    co=np.array([[-2.,3.,4.,-1.]])
    p=population(5,.3,.5,.15)
    q=integrate(co,5)[0];f=np.clip(p['design']@co[0],-1,1)
    for g,x in enumerate([-1,1]):
        for h in range(1,6):
            mask=(p['x']==x)&(p['ell']>=h)
            expect=p['p'][mask]@f[mask]/p['p'][mask].sum()
            integration_err=max(integration_err,abs(expect-q[g,h-1]))
    c=np.zeros((1,len(p['p'])),int);c[0,0]=10
    assert np.all(np.isfinite(fit(c,p)))
    # Enumerate the heteroskedastic least-squares covariance at a fixed design.
    # X=+-1 crossed with all four action paths yields eight fitting rows.
    paths=np.array(list(itertools.product([0,1],repeat=2)))
    uu=np.tile(2*paths.mean(axis=1)-1,2)
    xx=np.repeat([-1.,1.],4)
    D=np.column_stack([np.ones(8),xx,uu,xx*uu])
    beta=np.array([0.,B,A,.3]);G=D.T@D/8
    eta_scale=.15*(1+.5*xx*uu)
    signs=np.array(list(itertools.product([-1.,1.],repeat=8)))
    Y=D@beta+signs*eta_scale
    fitted=Y@np.linalg.pinv(D).T
    error=fitted-beta
    cov=error.T@error/256
    exact=np.linalg.inv(D.T@D)@D.T@np.diag(eta_scale**2)@D@np.linalg.inv(D.T@D)
    covariance_error=float(np.max(abs(cov-exact)))
    bound=.15**2*1.5**2*np.linalg.inv(G)/8
    assert np.linalg.eigvalsh(bound-cov).min()>-1e-12
    clipped=np.clip(fitted@D.T,-M,M)
    risk=np.mean((clipped-D@beta)**2,axis=0)
    assert max(risk)<=32*1.5**2*.15**2*2/8+1e-12
    # Misspecified population projection: ordinary and prefix risks differ.
    misspec_error=0.
    for T in [3,5,7]:
        p=population(T,.3,.5,.15)
        squared=(.3*p['x']*p['u'])**2
        misspec_error=max(misspec_error,abs(p['p']@squared-.3**2/T))
        for h in range(1,T+1):
            actual=(p['p']*p['ind'][:,h-1])@squared*2**h
            misspec_error=max(misspec_error,abs(actual-.3**2*(h*h+T-h)/T**2))
    vals=[truth_err,gram_err,variance_err,fit_err,moment_err,integration_err,kl_err,shift_err,
          covariance_error,misspec_error]
    assert max(vals)<1e-9,vals
    return dict(population_prefix_cases=law_cases,expanded_moment_cases=expanded_cases,
                max_truth_error=truth_err,max_gram_error=gram_err,max_oracle_variance_error=variance_err,
                max_expanded_fit_error=fit_err,max_expanded_moment_error=moment_err,
                max_integration_error=integration_err,max_kl_error=kl_err,max_target_shift_error=shift_err,
                heteroskedastic_response_vectors=256,max_heteroskedastic_covariance_error=covariance_error,
                max_misspecified_risk_error=misspec_error,
                exhaustive_selector_checked=True,validation_cannot_change_A3_cap=True,
                singular_fit_finite=True,active_clipping_checked=True)


def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def run(out):
    start=time.time();out.mkdir(parents=True,exist_ok=True)
    protocol_hash=hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    verification=checks()
    (out/'checks.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
    summaries=[];paired=[];risks=[];survival=[];estimates={};record_count=0
    fields=['law','n','T','tau','tolerance','epsilon','method','replicate','H','cap','fallback',
            'selected_max_error','selected_success','candidate_coverage','range_blocked','validation_shorter']
    with gzip.open(out/'replicates.csv.gz','wt',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
        for li,(law,d,lam) in enumerate(LAWS):
            for ni,n in enumerate(SIZES):
                T=math.ceil(math.log2(n))
                for ti,tau in enumerate(NOISE):
                    pop=population(T,d,lam,tau)
                    seeds=np.random.SeedSequence([SEED,li,ni,ti]).spawn(6)
                    blocks=[np.random.default_rng(seed).multinomial(n//6,pop['p'],size=REPS) for seed in seeds]
                    prepared,risk,_=prepare(blocks,pop)
                    base=dict(law=law,n=n,T=T,tau=tau)
                    for name,(natural,prefix) in risk.items():
                        for h in range(1,T+1):
                            values=prefix[:,h-1]
                            risks.append(dict(base,method=name,h=h,ordinary_risk_mean=float(natural.mean()),
                                              prefix_risk_mean=float(values.mean()),prefix_risk_mcse=float(values.std(ddof=1)/math.sqrt(REPS))))
                    for method in METHODS:
                        estimates[f'{li}_{ni}_{ti}_{method}']=prepared[method]['means']
                    for label,eps in [('fixed',.025),('shrinking',n**(-.25))]:
                        outputs=evaluate(prepared,pop,eps)
                        condition=dict(base,tolerance=label,epsilon=eps)
                        for name in METHODS:
                            item=outputs[name];hh=item['H'];cap=item['cap']
                            inside_report=np.arange(1,T+1)[None,:]<=hh[:,None]
                            errors=abs(item['means']-pop['truth'])
                            selected_error=np.max(np.where(inside_report,errors,0.),axis=1)
                            success=selected_error<=eps+1e-12
                            cover=np.all((errors<=item['width']+1e-12)|~item['inside'],axis=1)
                            surv=np.array([np.mean(hh>=h) for h in range(1,T+1)])
                            h90=max([0]+[h for h in range(1,T+1) if surv[h-1]>=.9])
                            lo,hi=wilson(int(success.sum()),REPS)
                            summaries.append(dict(condition,method=name,reps=REPS,mean_h=float(hh.mean()),
                                h_mcse=float(hh.std(ddof=1)/math.sqrt(REPS)),h90=h90,
                                abstention=float(np.mean(hh==0)),selected_accuracy=float(success.mean()),
                                accuracy_wilson_low=lo,accuracy_wilson_high=hi,candidate_coverage=float(cover.mean()),
                                error_q95=float(np.quantile(selected_error,.95)),
                                range_blocked=float(item['range_blocked'].mean()),
                                validation_shorter=float(item['validation_shorter'].mean())))
                            for h in range(1,T+1):survival.append(dict(condition,method=name,h=h,reported=int(np.sum(hh>=h)),reps=REPS))
                            for rep in range(REPS):
                                writer.writerow(dict(condition,method=name,replicate=rep,H=int(hh[rep]),cap=int(cap[rep]),
                                    fallback=item['fallback'],selected_max_error=float(selected_error[rep]),
                                    selected_success=int(success[rep]),candidate_coverage=int(cover[rep]),
                                    range_blocked=int(item['range_blocked'][rep]),validation_shorter=int(item['validation_shorter'][rep])))
                                record_count+=1
                        for other in ['A2','C','S','A3-add','A3-noX','A3-oracle']:
                            diff=outputs['A3']['H']-outputs[other]['H']
                            paired.append(dict(condition,left='A3',right=other,mean_difference=float(diff.mean()),
                                mcse=float(diff.std(ddof=1)/math.sqrt(REPS)),win=float(np.mean(diff>0)),
                                tie=float(np.mean(diff==0)),loss=float(np.mean(diff<0))))
                        print(law,n,tau,label,{m:round(float(outputs[m]['H'].mean()),3) for m in METHODS},flush=True)
    for name,rows in [('summary.csv',summaries),('paired.csv',paired),('prediction_risks.csv',risks),('survival.csv',survival)]:
        write_csv(out/name,rows)
    np.savez_compressed(out/'horizon_estimates.npz',**estimates)
    assert hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()==protocol_hash
    environment=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),
        elapsed_seconds=time.time()-start,master_seed=SEED,independent_datasets=18*REPS,
        condition_rows=len(summaries),method_records=record_count,estimate_arrays=len(estimates),
        protocol_sha256=protocol_hash,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),omp_threads=os.getenv('OMP_NUM_THREADS'))
    (out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(environment,indent=2),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    if args.check:print(json.dumps(checks(),indent=2))
    else:run(args.out)
