"""Budgets calculations for the causal-horizon experiments."""
from pathlib import Path
import csv
import gzip
import hashlib
import importlib.util
import json
import os
import platform
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('revision_study', ROOT.parent/'binary/run.py')
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)
N, T, EPS, ALPHA, REPS, SEED = 262144, 24, .025, .05, 1000, 2026092503
SETTINGS = [('noise', 0., 0), ('near', .99, 0), ('perfect', 1., 0), ('changing', 1., 6)]
METHODS = ['O', 'C_half', 'C_full', 'S_half', 'S_full']


def evaluate(index):
    name, kappa, d = SETTINGS[index]
    length, group, x, y, p, ind, ratios, truth = study.population(T, kappa, d)
    rng = np.random.default_rng(np.random.SeedSequence([SEED, index]))
    train = rng.multinomial(N//2, p, size=REPS)
    valid = rng.multinomial(N//2, p, size=REPS)
    original, _ = study.evaluate(train, valid, group, y, ind, ratios, EPS)
    out = {'O': original['O'], 'C_full': original['C'], 'S_full': original['S']}
    fullcap = np.full(REPS, T)
    cm, cv, cn = study.old.conditional_moments(valid, y, ind)
    h, w, inside = study.old.selected(cv, cn, 2., fullcap, EPS, ALPHA, allocation='uniform')
    out['C_half'] = (h, cm, w, inside, fullcap)
    sm, sw, _, _ = study.stratified(valid, group, y, ind)
    h = np.cumprod(sw <= EPS, axis=1).sum(1).astype(int)
    out['S_half'] = (h, sm, sw, np.ones_like(sw, bool), fullcap)
    return out, truth


def main(outdir=None):
    start = time.time()
    outdir = Path(outdir) if outdir is not None else ROOT/'results'
    outdir.mkdir(parents=True, exist_ok=True)
    records, summaries, paired = [], [], []
    protocol_hash = hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    inherited_checks = study.checks()
    for index, (name, kappa, d) in enumerate(SETTINGS):
        outputs, truth = evaluate(index)
        horizons = {}
        for method in METHODS:
            hh, estimates, widths, inside, cap = outputs[method]
            chosen = np.arange(1, T+1)[None, :] <= hh[:, None]
            errors = np.max(np.where(chosen, abs(estimates-truth), 0.), axis=1)
            success = errors <= EPS+1e-12
            cover = np.all((abs(estimates-truth) <= widths+1e-12) | ~inside, axis=1)
            radius_ratio = np.max(np.where(chosen, widths/EPS, 0.), axis=1)
            base = dict(population=name, n=N, T=T, kappa=kappa, d=d, epsilon=EPS, method=method)
            summaries.append(dict(base, reps=REPS, mean_h=float(hh.mean()),
                h_mcse=float(hh.std(ddof=1)/np.sqrt(REPS)),
                h_q05=float(np.quantile(hh, .05)), h_q95=float(np.quantile(hh, .95)),
                selected_accuracy=float(success.mean()), abstention=float(np.mean(hh == 0)),
                candidate_coverage=float(cover.mean()), error_q95=float(np.quantile(errors, .95)),
                error_ratio_q95=float(np.quantile(errors/EPS, .95)),
                selected_radius_ratio_mean=float(radius_ratio[hh > 0].mean()) if np.any(hh > 0) else None))
            for rep in range(REPS):
                records.append(dict(base, replicate=rep, H=int(hh[rep]), cap=int(cap[rep]),
                    selected_max_error=float(errors[rep]), selected_success=bool(success[rep]),
                    candidate_coverage=bool(cover[rep]),
                    selected_radius_ratio=float(radius_ratio[rep]) if hh[rep] else None))
            horizons[method] = hh
        for left, right in [('C_full','C_half'), ('S_full','S_half'),
                            ('O','C_half'), ('O','S_half'), ('O','S_full')]:
            diff = horizons[left]-horizons[right]
            paired.append(dict(population=name, left=left, right=right,
                mean_difference=float(diff.mean()), mcse=float(diff.std(ddof=1)/np.sqrt(REPS))))
        print(name, {m: float(horizons[m].mean()) for m in METHODS}, flush=True)
        # Deterministic replay of every output in this small study.
        replay, replay_truth = evaluate(index)
        np.testing.assert_array_equal(replay_truth, truth)
        for method in METHODS:
            for a, b in zip(outputs[method], replay[method]):
                np.testing.assert_array_equal(a, b)
    for filename, rows in [('summary.csv', summaries), ('paired.csv', paired)]:
        with (outdir/filename).open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    with gzip.open(outdir/'replicates.csv.gz', 'wt', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)
    checks = dict(inherited=inherited_checks, deterministic_replay=True,
                  independent_datasets=4000, method_records=len(records), summary_rows=len(summaries))
    (outdir/'checks.json').write_text(json.dumps(checks, indent=2)+'\n', encoding='utf-8')
    assert hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest() == protocol_hash
    environment = dict(seed=SEED, python=platform.python_version(), numpy=np.__version__,
        system=platform.system(), elapsed_seconds=time.time()-start,
        openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'), omp_threads=os.getenv('OMP_NUM_THREADS'),
        protocol_sha256=protocol_hash, run_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    (outdir/'environment.json').write_text(json.dumps(environment, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(checks, indent=2))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=ROOT/'results')
    main(parser.parse_args().out)
