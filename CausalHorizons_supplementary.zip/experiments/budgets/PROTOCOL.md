# Budgets

Four populations at n=262144, T=24, epsilon=.025, alpha=.05, M=1, with 1000 datasets each. Compare O, conditional means and stratification using either the same validation half or the full sample. These datasets are shared with the betting comparisons. All population/method cells, errors and coverage records are retained.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
