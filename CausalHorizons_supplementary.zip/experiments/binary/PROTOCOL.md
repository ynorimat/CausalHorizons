# Binary

Binary baseline populations, stratification, conditional means, split regression and comparator kernels. The source specifies exact cell probabilities, fixed support bounds, confidence allocations and seeds. Reported studies import these functions; their population grids are described in Appendix D.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
