"""Binary calculations for the causal-horizon experiments."""
from pathlib import Path
import itertools
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
states = list(itertools.product([-1, 1], itertools.product([0, 1], repeat=3), [-1, 1]))
b = .75
largest_identity_error = 0.
largest_ratio = 0.
checked = 0
for kappa in [0, .5, .9, .99, .999]:
    for h in [1, 2, 3]:
        for fraction in [.01, .1, .5, 1.]:
            theta = fraction*(1-kappa)/4
            P, Q = [], []
            for x, actions, sign in states:
                p = (1+kappa*x)/2
                q = p+theta if all(actions[:h]) else p
                P.append((p if sign == 1 else 1-p)/16)
                Q.append((q if sign == 1 else 1-q)/16)
            P, Q = np.array(P), np.array(Q)
            assert np.isclose(P.sum(), 1) and np.isclose(Q.sum(), 1)
            kl = np.sum(P*np.log(P/Q))
            bernoulli_kl = 0.
            for x in [-1, 1]:
                p = (1+kappa*x)/2; q = p+theta
                assert q*(1-q) >= (1-kappa*kappa)/8-1e-15
                bernoulli_kl += .5*(p*np.log(p/q)+(1-p)*np.log((1-p)/(1-q)))
            largest_identity_error = max(largest_identity_error, abs(kl-2**(-h)*bernoulli_kl))
            upper = 8*2**(-h)*theta*theta/(1-kappa*kappa)
            assert kl <= upper+1e-14
            largest_ratio = max(largest_ratio, kl/upper)
            target = sum(prob*b*sgn for prob, (x, a, sgn) in zip(Q, states) if all(a[:h]))*2**h
            assert abs(target-2*b*theta) < 1e-14
            tv = .5*np.abs(P-Q).sum()
            assert tv <= np.sqrt(kl/2)+1e-14
            checked += 1
result = dict(configurations=checked, full_law_kl_identity_max_error=largest_identity_error,
              maximum_kl_to_upper_bound_ratio=largest_ratio, target_shift_and_pinsker_checked=True,
              interpretation='Finite-law checks supplement the written proof; they are not a formal proof certificate.')
out = ROOT.parents[1] / 'work'
out.mkdir(exist_ok=True)
(out/'imperfect_prediction_checks.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
