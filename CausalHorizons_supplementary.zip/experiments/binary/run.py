"""Binary calculations for the causal-horizon experiments."""
from pathlib import Path
import csv
import gzip
import hashlib
import importlib.util
import json
import os
import platform
import sys
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_adaptivity', ROOT.parent/'kernels/run.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
M = 1.0
ALPHA = .05
REPS = 1000
SEED = 2026092501
METHODS = ['O', 'U', 'I', 'C', 'S', 'F', 'B']


def population(T, kappa=1., d=0):
    length, group, x, y, p, ind, ratios = old.cells(T, kappa)
    if d:
        y = .5*x + .4*np.minimum(length, d)/d
        h = np.arange(1, T+1)
        truth = .4*np.where(h < d, (h+1-np.exp2(h-d))/d, 1.)
    else:
        truth = np.zeros(T)
    np.testing.assert_allclose(p@(y[:, None]*ratios), truth, atol=1e-12)
    return length, group, x, y, p, ind, ratios, truth


def stratified(counts, group, y, ind, alpha=ALPHA, bound=M):
    """Simultaneous fixed-grid intervals under the full bounded binary class.

    Conditional on membership counts, outcomes in each group/event are iid
    from its conditional law. A union bound is valid despite nested events and
    dependence between the group proportion and conditional outcome estimates.
    """
    n = counts.sum(1)
    T = ind.shape[1]
    phat = counts[:, group == 1].sum(1)/n
    perr = np.sqrt(np.log(4/alpha)/(2*n))
    plo, phi = np.maximum(0, phat-perr), np.minimum(1, phat+perr)
    means, lows, highs = [], [], []
    for g in [0, 1]:
        c = counts*(group == g)
        mean, var, size = old.conditional_moments(c, y, ind)
        rad = old.eb(var, size, 2*bound, alpha/(4*T))
        means.append(mean)
        lows.append(np.maximum(-bound, mean-rad))
        highs.append(np.minimum(bound, mean+rad))
    mean = (1-phat[:, None])*means[0]+phat[:, None]*means[1]
    lo = np.minimum((1-plo[:, None])*lows[0]+plo[:, None]*lows[1],
                    (1-phi[:, None])*lows[0]+phi[:, None]*lows[1])
    hi = np.maximum((1-plo[:, None])*highs[0]+plo[:, None]*highs[1],
                    (1-phi[:, None])*highs[0]+phi[:, None]*highs[1])
    radius = np.maximum(mean-lo, hi-mean)
    return mean, radius, lo, hi


def evaluate(train, valid, group, y, ind, ratios, epsilon):
    reps, T = len(train), ind.shape[1]
    N = int(train.sum(1)[0]); n = 2*N
    pred = old.fit_group_means(train, group, y)
    _, tv = old.score_moments(train, group, y, ratios, pred)
    vm, vv = old.score_moments(valid, group, y, ratios, pred)
    ranges = old.original.score_ranges(T, M)
    k0 = old.original.fallback(N, T, M, epsilon, ALPHA)
    cap = old.pilot(tv, N, ranges, epsilon, ALPHA/2, k0)
    out = {}
    for name, allocation in [('O', 'geometric'), ('U', 'uniform')]:
        h, w, inside = old.selected(vv, N, ranges, cap, epsilon, ALPHA/2, k0, allocation)
        out[name] = (h, vm, w, inside, cap)
    zero = np.zeros((reps, 2))
    _, iv = old.score_moments(train, group, y, ratios, zero)
    im, ivv = old.score_moments(valid, group, y, ratios, zero)
    irange = 2*M*np.exp2(np.arange(1, T+1))
    icap = old.pilot(iv, N, irange, epsilon, ALPHA/2, k0)
    h, w, inside = old.selected(ivv, N, irange, icap, epsilon, ALPHA/2, k0)
    out['I'] = (h, im, w, inside, icap)
    full = train+valid
    cm, cv, cn = old.conditional_moments(full, y, ind)
    fullcap = np.full(reps, T)
    h, w, inside = old.selected(cv, cn, 2*M, fullcap, epsilon, ALPHA, allocation='uniform')
    out['C'] = (h, cm, w, inside, fullcap)
    sm, sw, _, _ = stratified(full, group, y, ind)
    h = np.cumprod(sw <= epsilon, axis=1).sum(1).astype(int)
    out['S'] = (h, sm, sw, np.ones_like(sw, bool), fullcap)
    fixed = max(0, min(T, int(np.floor(np.log2(n*epsilon**2/(3*M*M*np.log(4/ALPHA)))))))
    fm = np.clip((full*y)@ratios/n, -M, M)
    out['F'] = (np.full(reps, fixed), fm, None, None, np.full(reps, fixed))
    out['B'] = (np.full(reps, k0), vm, None, None, np.full(reps, k0))
    return out, k0


def checks():
    baseline = old.checks()
    rng = np.random.default_rng(4825)
    max_interval_error = 0.
    max_truth_error = 0.
    for d in [0, 2, 4, 6]:
        l, g, x, y, p, ind, ratios, truth = population(6, .99 if not d else 1., d)
        max_truth_error = max(max_truth_error, float(np.max(abs(p@(y[:, None]*ratios)-truth))))
        counts = rng.multinomial(2048, p, size=4)
        sm, sw, lo, hi = stratified(counts, g, y, ind)
        for rep in range(4):
            idx = np.repeat(np.arange(len(p)), counts[rep])
            phat = np.mean(g[idx] == 1)
            pe = np.sqrt(np.log(4/ALPHA)/(2*len(idx)))
            ps = [max(0, phat-pe), min(1, phat+pe)]
            for h in range(1, 7):
                mus, a, b = [], [], []
                for group in [0, 1]:
                    yy = y[idx[(g[idx] == group) & (l[idx] >= h)]]
                    mu = yy.mean() if len(yy) else 0.
                    if len(yy) < 2:
                        left, right = -M, M
                    else:
                        lam = np.log(16*6/ALPHA)
                        rad = np.sqrt(2*yy.var(ddof=1)*lam/len(yy))+14*M*lam/(3*(len(yy)-1))
                        left, right = max(-M, mu-rad), min(M, mu+rad)
                    mus.append(mu); a.append(left); b.append(right)
                em = (1-phat)*mus[0]+phat*mus[1]
                el = min((1-q)*a[0]+q*a[1] for q in ps)
                eu = max((1-q)*b[0]+q*b[1] for q in ps)
                max_interval_error = max(max_interval_error, abs(sm[rep, h-1]-em),
                                         abs(lo[rep, h-1]-el), abs(hi[rep, h-1]-eu))
        # Check the tight IPW support using the actual population cells.
        assert np.all(abs(ratios*y[:, None]) <= M*np.exp2(np.arange(1, 7)))
    # Empty and singleton conditional groups retain the full outcome interval.
    l, g, x, y, p, ind, ratios, truth = population(4)
    c = np.zeros((1, len(p)), dtype=np.int64)
    c[0, np.flatnonzero(p)[0]] = 10
    m, w, lo, hi = stratified(c, g, y, ind)
    assert np.all(np.isfinite(w)) and np.all(lo <= m) and np.all(hi >= m)
    assert max_interval_error < 1e-7
    return dict(original_checks=baseline, expanded_interval_max_error=max_interval_error,
                analytic_truth_max_error=max_truth_error, tight_ipw_range_checked=True,
                empty_group_interval_checked=True)


def run():
    outdir = ROOT/'results'; outdir.mkdir(exist_ok=True)
    check = checks()
    (outdir/'checks.json').write_text(json.dumps(check, indent=2)+'\n')
    protocol_hash = hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest()
    start = time.time()
    summaries, paired = [], []
    fields = ['study', 'n', 'T', 'kappa', 'd', 'epsilon', 'method', 'replicate',
              'H', 'cap', 'fallback', 'selected_max_error', 'selected_success',
              'candidate_coverage', 'informative_coordinates', 'selected_truth_range']
    with gzip.open(outdir/'replicates.csv.gz', 'wt', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader()
        def condition(study, n, T, kappa, d, epsilons):
            l, g, x, y, p, ind, ratios, truth = population(T, kappa, d)
            study_id = {'predictability': 1, 'shrinking': 2, 'changing': 3}[study]
            rng = np.random.default_rng(np.random.SeedSequence([SEED, study_id, n, round(1000*kappa), d]))
            train = rng.multinomial(n//2, p, size=REPS)
            valid = rng.multinomial(n//2, p, size=REPS)
            for eps in epsilons:
                methods, k0 = evaluate(train, valid, g, y, ind, ratios, eps)
                horizons = {}
                base = dict(study=study, n=n, T=T, kappa=kappa, d=d, epsilon=eps)
                for name in METHODS:
                    hh, est, width, inside, cap = methods[name]
                    chosen = np.arange(1, T+1)[None, :] <= hh[:, None]
                    err = np.max(np.where(chosen, abs(est-truth), 0.), axis=1)
                    success = err <= eps+1e-12
                    cover = None if width is None else np.all((abs(est-truth) <= width+1e-12) | ~inside, axis=1)
                    informative = np.sum(chosen & (abs(truth)[None, :] > eps), axis=1)
                    trange = np.where(hh > 0, truth[np.maximum(hh-1, 0)]-truth[0], 0.)
                    row = dict(base, method=name, reps=REPS, mean_h=float(hh.mean()),
                               h_mcse=float(hh.std(ddof=1)/np.sqrt(REPS)),
                               h_q05=float(np.quantile(hh, .05)), h_median=float(np.median(hh)),
                               h_q95=float(np.quantile(hh, .95)), fallback=k0,
                               abstention=float(np.mean(hh == 0)), selected_success=float(success.mean()),
                               candidate_coverage=float(cover.mean()) if cover is not None else None,
                               error_mean=float(err.mean()), error_q95=float(np.quantile(err, .95)),
                               mean_cap=float(cap.mean()), informative_coordinates=float(informative.mean()),
                               selected_truth_range=float(trange.mean()))
                    summaries.append(row); horizons[name] = hh
                    for rep in range(REPS):
                        writer.writerow(dict(base, method=name, replicate=rep, H=int(hh[rep]), cap=int(cap[rep]),
                                             fallback=k0, selected_max_error=float(err[rep]),
                                             selected_success=bool(success[rep]),
                                             candidate_coverage=bool(cover[rep]) if cover is not None else None,
                                             informative_coordinates=int(informative[rep]),
                                             selected_truth_range=float(trange[rep])))
                for name in METHODS[1:]:
                    diff = horizons['O']-horizons[name]
                    paired.append(dict(base, comparator=name, mean_difference=float(diff.mean()),
                                       difference_mcse=float(diff.std(ddof=1)/np.sqrt(REPS)),
                                       fraction_O_longer=float(np.mean(diff > 0)), fraction_equal=float(np.mean(diff == 0))))
            print(f'{study}: n={n}, kappa={kappa}, d={d}; {time.time()-start:.1f}s', flush=True)
        for n in [2**14, 2**16, 2**18]:
            for kappa in [0., .9, .99, .999, 1.]:
                condition('predictability', n, 24, kappa, 0, [.2, .1, .05, .025])
        for exponent in range(14, 33, 2):
            for kappa in [.9, .99, .999, 1.]:
                condition('shrinking', 2**exponent, exponent, kappa, 0, [(2**exponent)**(-.25)])
        for n in [2**16, 2**18]:
            for d in [2, 4, 6]:
                condition('changing', n, 24, 1., d, [.025, .05])
    for filename, rows in [('summary.csv', summaries), ('paired.csv', paired)]:
        with (outdir/filename).open('w', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    meta = dict(date='2026-09-25', seed=SEED, repetitions=REPS, independent_datasets=61000,
                design_cells=112, summary_rows=len(summaries), method_records=len(summaries)*REPS,
                python=platform.python_version(), numpy=np.__version__, system=platform.system(),
                machine=platform.machine(), processor=platform.processor(), elapsed_seconds=time.time()-start,
                openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'), omp_threads=os.getenv('OMP_NUM_THREADS'),
                protocol_sha256=protocol_hash, run_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    assert len(summaries) == 784
    assert hashlib.sha256((ROOT/'PROTOCOL.md').read_bytes()).hexdigest() == protocol_hash
    (outdir/'environment.json').write_text(json.dumps(meta, indent=2)+'\n')
    print(json.dumps(meta, indent=2), flush=True)


if __name__ == '__main__':
    if '--check' in sys.argv:
        print(json.dumps(checks(), indent=2))
    else:
        run()
