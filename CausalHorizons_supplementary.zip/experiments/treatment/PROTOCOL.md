# Treatment

First-six-action response Y=.5V+.4 min(ell,6)/6. Use four sample sizes, three predictability levels and 1000 datasets per population. Compare O, W, WA, S and C on shared datasets. All 60 method/population cells are retained, including abstaining conditions. Fixed T=24 and fixed noise levels are finite illustrations, not asymptotic coefficient estimates.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
