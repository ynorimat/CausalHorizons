"""Treatment calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse
import importlib.util
import itertools
import json
import math
import os
import platform
import time
import numpy as np

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT.parent
spec = importlib.util.spec_from_file_location('pilot_v5', PACKAGE/'betting/run.py')
pilot = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)
comparison = pilot.comparison
betting = pilot.betting
ALPHA, M, B, A, D, T, REPS = .05, 1., .5, .4, 6, 24, 1000


def population(periods, kappa, d=D):
    length, group, x, residual, p, ind, ratios = comparison.old.cells(periods, kappa)
    keep = p > 0
    length, group, x, residual, p, ind, ratios = (
        arr[keep] for arr in [length, group, x, residual, p, ind, ratios])
    y = B*(residual/comparison.old.B)+A*np.minimum(length, d)/d
    h = np.arange(1, periods+1)
    truth = A*np.where(h < d, (h+1-np.exp2(h-d))/d, 1.)
    assert np.all(abs(y) < M) and abs(p.sum()-1) < 1e-14
    np.testing.assert_allclose(p@(y[:, None]*ratios), truth, atol=2e-15)
    return length, group, y, p, ind, ratios, truth


def enumeration(periods, d, kappa, f):
    actions = np.array(list(itertools.product([0, 1], repeat=periods)), dtype=int)
    ll = np.where(actions == 0, np.arange(periods), periods).min(axis=1)
    fval = np.array([f[tuple(row[:d])] for row in actions])
    length = np.repeat(ll, 4)
    x = np.tile([-1, -1, 1, 1], len(actions))
    v = np.tile([-1, 1, -1, 1], len(actions))
    shifts = np.repeat(fval, 4)
    p = np.exp2(-periods)*.5*(1+kappa*x*v)/2
    y = shifts+B*v
    return length, x, v, shifts, y, p


def checks():
    rng = np.random.default_rng(2026092562)
    errors = {'target': 0., 'conditional_variance': 0., 'baseline_score_variance': 0.,
              'kl': 0., 'perturbed_target': 0., 'expanded_moments': 0.,
              'stratified_interval': 0., 'contamination_tv': 0.}
    cases = dict(enumerated_targets=0, conditional_variances=0, score_variances=0,
                 kl_perturbations=0, contamination_products=0, sample_moments=0,
                 stratified_endpoints=0, actual_betting_decisions=0)
    for d in [1, 3, 6]:
        periods = 6
        effect = {key: A*sum(key)/d for key in itertools.product([0,1], repeat=d)}
        for kappa in [0., .9, 1.]:
            length, x, v, shifts, y, p = enumeration(periods, d, kappa, effect)
            for h in range(1, periods+1):
                mask = length >= h
                expected = A*(d+min(h,d))/(2*d)
                actual = float(p@(2.**h*mask*y))
                errors['target'] = max(errors['target'], abs(actual-expected))
                cases['enumerated_targets'] += 1
                if h >= d:
                    for xx in [-1,1]:
                        cell = mask & (x == xx)
                        cond = p[cell]/p[cell].sum()
                        mu = float(cond@y[cell])
                        variance = float(cond@((y[cell]-mu)**2))
                        errors['conditional_variance'] = max(errors['conditional_variance'],
                            abs(variance-B*B*(1-kappa*kappa)))
                        cases['conditional_variances'] += 1
                    if kappa == 1.:
                        marginal = B*x+A/2
                        z = marginal+2.**h*mask*(y-marginal)
                        actual_variance = float(p@((z-p@z)**2))
                        formula = B*B+(2.**h-1)*(A/2)**2
                        errors['baseline_score_variance'] = max(errors['baseline_score_variance'],
                            abs(actual_variance-formula))
                        cases['score_variances'] += 1
                if kappa < 1.:
                    theta = (1-kappa)/8
                    altered = p+np.exp2(-periods)*.5*mask*v*theta
                    assert np.all(altered > 0)
                    positive = p > 0
                    kl = float(np.sum(p[positive]*np.log(p[positive]/altered[positive])))
                    px = np.array([(1-kappa)/2,(1+kappa)/2])
                    exact = 2.**(-h)*.5*np.sum(px*np.log(px/(px+theta))+
                        (1-px)*np.log((1-px)/(1-px-theta)))
                    errors['kl'] = max(errors['kl'],abs(kl-exact))
                    assert kl <= 8*2.**(-h)*theta**2/(1-kappa*kappa)+1e-14
                    shift = float((altered-p)@(2.**h*mask*y))
                    errors['perturbed_target'] = max(errors['perturbed_target'],abs(shift-2*B*theta))
                    cases['kl_perturbations'] += 1
        # Full product total variation on a small finite sample space.
        length, x, v, shifts, y, p = enumeration(periods,d,.7,effect)
        h, delta = 4,.15
        mask = length >= h
        # Keep distinct latent labels for replacement atoms; summing these
        # indistinguishable labels does not change TV, since P has no mass there.
        ref = np.concatenate([p,np.zeros_like(p)])
        alt = np.concatenate([p*(1-delta*mask),p*delta*mask])
        prod_tv = .5*np.abs(ref[:,None]*ref-alt[:,None]*alt).sum()
        formula = 1-(1-delta*2.**(-h))**2
        errors['contamination_tv'] = max(errors['contamination_tv'],abs(prod_tv-formula))
        yy = np.concatenate([y,np.full_like(y,M)])
        rr = np.tile(2.**h*mask,2)
        tau = float(p@(y*2.**h*mask))
        errors['perturbed_target'] = max(errors['perturbed_target'],
            abs(float(alt@(yy*rr))-tau-delta*(M-tau)))
        cases['contamination_products'] += 1
    # Compare the compressed run-length model to complete binary paths.
    effect = {key:A*next((j for j,z in enumerate(key) if z == 0),6)/6
              for key in itertools.product([0,1],repeat=6)}
    for kappa in [0.,.9,1.]:
        length, group, y, p, ind, ratios, truth = population(8,kappa)
        le,xe,ve,fe,ye,pe = enumeration(8,6,kappa,effect)
        for h in range(1,9):
            val = float(pe@(2.**h*(le>=h)*ye))
            errors['target'] = max(errors['target'],abs(val-truth[h-1]))
            cases['enumerated_targets'] += 1
        train = rng.multinomial(1024,p,size=3)
        valid = rng.multinomial(1024,p,size=3)
        pred = comparison.old.fit_group_means(train,group,y)
        mean,var = comparison.old.score_moments(valid,group,y,ratios,pred)
        full = train+valid
        sm,sw,lo,hi = comparison.stratified(full,group,y,ind)
        for rep in range(3):
            ids = np.repeat(np.arange(len(p)),valid[rep])
            zz = pred[rep,group[ids]][:,None]+ratios[ids]*(y[ids]-pred[rep,group[ids]])[:,None]
            errors['expanded_moments'] = max(errors['expanded_moments'],
                float(np.max(abs(zz.mean(0)-mean[rep]))),float(np.max(abs(zz.var(0,ddof=1)-var[rep]))))
            cases['sample_moments'] += 8
            all_ids = np.repeat(np.arange(len(p)),full[rep])
            phat = float(np.mean(group[all_ids] == 1))
            pe = math.sqrt(math.log(4/ALPHA)/(2*len(all_ids)))
            ps = [max(0.,phat-pe),min(1.,phat+pe)]
            for h in range(1,9):
                means,lows,highs = [],[],[]
                for gg in [0,1]:
                    vals = y[all_ids[(group[all_ids] == gg)&(length[all_ids]>=h)]]
                    mu = float(vals.mean()) if len(vals) else 0.
                    if len(vals)<2: left,right=-M,M
                    else:
                        lam=math.log(16*8/ALPHA)
                        rad=math.sqrt(2*vals.var(ddof=1)*lam/len(vals))+14*M*lam/(3*(len(vals)-1))
                        left,right=max(-M,mu-rad),min(M,mu+rad)
                    means.append(mu);lows.append(left);highs.append(right)
                exact_mean=(1-phat)*means[0]+phat*means[1]
                exact_lo=min((1-pp)*lows[0]+pp*lows[1] for pp in ps)
                exact_hi=max((1-pp)*highs[0]+pp*highs[1] for pp in ps)
                errors['stratified_interval']=max(errors['stratified_interval'],abs(exact_mean-sm[rep,h-1]),
                    abs(exact_lo-lo[rep,h-1]),abs(exact_hi-hi[rep,h-1]))
                cases['stratified_endpoints'] += 1
    # Check betting pass/fail decisions at production sizes using independent
    # interval inversion rather than only the wealth-at-epsilon shortcut.
    for n in [2**14,2**16,2**18,2**20]:
        for kappa in [0.,.9,1.]:
            l,g,y,p,ind,ratios,truth=population(T,kappa)
            counts=rng.multinomial(n//2,p,size=4)
            pred=comparison.old.fit_group_means(counts,g,y)
            ev=pilot.width_evidence(counts,g,y,l,pred,.025,T)
            fallback=comparison.old.original.fallback(n//2,T,M,.025,ALPHA)
            cap=pilot.select_cap(ev,fallback)
            for h in range(1,int(cap.max())+1):
                ids=np.flatnonzero(cap>=h)
                z,cc=betting.score_histogram(counts[ids],g,y,l,pred[ids],h)
                support=M*(2**(h+1)-1)
                levels=(ALPHA/2)*np.exp2(h-cap[ids]-1.)
                lower,upper=betting.betting_interval((z+support)/(2*support),cc,levels)
                mu=(z*cc).sum(1)/(n//2)
                radius=np.maximum(mu-(2*support*lower-support),2*support*upper-support-mu)
                direct=ev[ids,h-1] > np.log(2/levels)
                reliable=abs(radius-.025)>1e-8
                assert np.array_equal(direct[reliable],(radius<.025)[reliable])
                cases['actual_betting_decisions'] += int(reliable.sum())
    for name,value in errors.items():
        assert value < (1e-7 if name in ['expanded_moments','stratified_interval'] else 1e-12),(name,value)
    return dict(cases=cases,maximum_absolute_errors=errors)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    start=time.time();check=checks()
    (args.out/'checks.json').write_text(json.dumps(check,indent=2)+'\n',encoding='utf-8')
    if args.check:
        print(json.dumps(check,indent=2));return
    protocol_hash=betting.sha(ROOT/'PROTOCOL.md')
    summaries,records,survival,paired=[],[],[],[]
    for n in [2**14,2**16,2**18,2**20]:
        for kappa in [0.,.9,1.]:
            l,g,y,p,ind,ratios,truth=population(T,kappa)
            rng=np.random.default_rng(np.random.SeedSequence([2026092561,n,round(1000*kappa)]))
            train=rng.multinomial(n//2,p,size=REPS)
            valid=rng.multinomial(n//2,p,size=REPS)
            methods=pilot.evaluate(train,valid,g,y,l,ind,ratios,truth,.025)
            cm,cv,cn=comparison.old.conditional_moments(train+valid,y,ind)
            fullcap=np.full(REPS,T)
            hh,ww,inside=comparison.old.selected(cv,cn,2*M,fullcap,.025,ALPHA,allocation='uniform')
            methods['C']=(hh,cm,fullcap,np.all(abs(cm-truth)<=ww+1e-12,axis=1))
            base=dict(n=n,log2_n=int(math.log2(n)),T=T,d=D,kappa=kappa,epsilon=.025)
            for label,(hh,est,cap,cov) in methods.items():
                chosen=np.arange(1,T+1)[None,:]<=hh[:,None]
                err=np.max(np.where(chosen,abs(est-truth),0.),axis=1)
                success=err<=.025+1e-12
                acc_lo,acc_hi=betting.wilson(int(success.sum()),REPS)
                summaries.append(dict(base,method=label,repetitions=REPS,mean_h=float(hh.mean()),
                    h_mcse=float(hh.std(ddof=1)/math.sqrt(REPS)),empirical_h90=betting.frequent_horizon(hh,T),
                    mean_cap=float(cap.mean()),selected_accuracy=float(success.mean()),accuracy_lower=acc_lo,
                    accuracy_upper=acc_hi,candidate_coverage=float(cov.mean()),abstention=float(np.mean(hh==0)),
                    error_q95=float(np.quantile(err,.95)),error_q95_ratio=float(np.quantile(err,.95)/.025)))
                for rep in range(REPS):
                    records.append(dict(base,method=label,replicate=rep,H=int(hh[rep]),cap=int(cap[rep]),
                        selected_max_error=float(err[rep]),selected_success=bool(success[rep]),
                        candidate_coverage=bool(cov[rep])))
                for h in range(1,T+1):
                    count=int(np.sum(hh>=h));lo,hi=betting.wilson(count,REPS)
                    survival.append(dict(base,method=label,horizon=h,successes=count,repetitions=REPS,
                        reporting_frequency=count/REPS,wilson_lower=lo,wilson_upper=hi))
            for aa,bb in [('WA','O'),('WA','W'),('S','WA'),('C','WA')]:
                diff=methods[aa][0]-methods[bb][0]
                paired.append(dict(base,comparison=aa+'-'+bb,mean_difference=float(diff.mean()),
                    difference_mcse=float(diff.std(ddof=1)/math.sqrt(REPS)),fraction_longer=float(np.mean(diff>0))))
            print('n',n,'kappa',kappa,{key:round(float(val[0].mean()),3) for key,val in methods.items()},flush=True)
    for name,rows in [('summary.csv',summaries),('replicates.csv.gz',records),('survival.csv',survival),('paired.csv',paired)]:
        betting.save_csv(args.out/name,rows)
    assert protocol_hash==betting.sha(ROOT/'PROTOCOL.md')
    meta=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),
        processor=platform.processor(),elapsed_seconds=time.time()-start,openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),
        omp_threads=os.getenv('OMP_NUM_THREADS'),protocol_sha256=protocol_hash,source_sha256=betting.sha(Path(__file__)),
        new_independent_datasets=12000,methods=5,method_records=len(records),repetitions=REPS,
        seed_components=[2026092561,'n','round(1000*kappa)'])
    (args.out/'environment.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(meta,indent=2),flush=True)


if __name__=='__main__':
    main()
