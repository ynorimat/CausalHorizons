"""Additive calculations for the causal-horizon experiments."""
from pathlib import Path
import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import platform
import time
import numpy as np

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pilot_v5',ROOT.parent/'betting/run.py')
pilot=importlib.util.module_from_spec(spec)
spec.loader.exec_module(pilot)
bet=pilot.betting
M,ALPHA,EPS,A,B=1.,.05,.025,.6,.3

def population(T,kappa):
    rows=[]
    for ell in range(T+1):
        suffix=T-ell-1
        for k in range(max(suffix+1,1)):
            action_p=2.**(-T) if ell==T else math.comb(suffix,k)*2.**(-T)
            total=ell+k
            for x in [-1,1]:
                for v in [-1,1]:
                    prob=action_p*(1+kappa*x*v)/4
                    if prob>0:
                        rows.append((ell,total,x,v,B*v+A*total/T,prob))
    array=np.array(rows,dtype=float)
    truth=A*(T+np.arange(1,T+1))/(2*T)
    return array,truth

def fits(counts,pop,T):
    x,y=pop[:,2],pop[:,4]
    n=counts.sum(1)
    baseline=np.empty((len(counts),2))
    for g,xx in enumerate([-1,1]):
        mask=x==xx;den=counts[:,mask].sum(1)
        baseline[:,g]=np.divide(counts[:,mask]@y[mask],den,out=np.zeros(len(counts)),where=den>0)
    design=np.column_stack([np.ones(len(pop)),x,pop[:,1]/T])
    gram=np.einsum('rc,ci,cj->rij',counts,design,design,optimize=True)/n[:,None,None]
    rhs=(counts@(design*y[:,None]))/n[:,None]
    # Minimum-norm least squares also defines the fit in rank-deficient samples.
    coef=np.stack([np.linalg.lstsq(g,b,rcond=None)[0] for g,b in zip(gram,rhs)])
    qh=coef[:,0,None,None]+coef[:,1,None,None]*np.array([-1,1])[None,:,None]
    qh=qh+coef[:,2,None,None]*(T+np.arange(1,T+1))[None,None,:]/(2*T)
    qb=np.repeat(baseline[:,:,None],T,axis=2)
    return {'B':np.clip(qb,-M,M),'H':np.clip(qh,-M,M)},coef

def histogram(counts,pop,q,h):
    # Outside C_h only the baseline value matters; inside, also retain Y.
    keys=[(int(row[2]),float(row[4]) if row[0]>=h else None) for row in pop]
    unique=list(dict.fromkeys(keys))
    indices={key:j for j,key in enumerate(unique)}
    membership=np.array([indices[key] for key in keys])
    cc=np.stack([counts[:,membership==j].sum(1) for j in range(len(unique))],axis=1)
    zz=np.empty(cc.shape,dtype=float)
    for j,(x,y) in enumerate(unique):
        base=q[:,(x+1)//2]
        zz[:,j]=base if y is None else base+2**h*(y-base)
    return zz,cc

def moments(z,cc):
    n=cc.sum(1)
    mean=(cc*z).sum(1)/n
    variance=(cc*(z-mean[:,None])**2).sum(1)/(n-1)
    return mean,variance

def eb_cap(var,N,eps,fallback):
    R,T=var.shape;caps=np.full(R,fallback,dtype=int)
    h=np.arange(1,T+1);L=2*M*(2.**(h+1)-1)
    for k in range(1,T+1):
        lam=math.log(16/ALPHA)+(k-h[:k])*math.log(2)
        widths=np.sqrt(2*var[:,:k]*lam/N)+7*L[:k]*lam/(3*(N-1))
        good=np.max(widths,axis=1)<=eps
        caps=np.where(good,np.maximum(caps,k),caps)
    return caps

def eb_select(var,N,eps,caps,fallback):
    h=np.arange(1,var.shape[1]+1)[None,:]
    inside=h<=caps[:,None]
    lam=math.log(16/ALPHA)+np.maximum(caps[:,None]-h,0)*math.log(2)
    widths=np.sqrt(2*var*lam/N)+7*2*M*(2.**(h+1)-1)*lam/(3*(N-1))
    selected=np.maximum(fallback,np.cumprod((widths<=eps)&inside,axis=1).sum(1)).astype(int)
    return selected,widths,inside

def evaluate(train,valid,pop,truth,T,epsilon=EPS,verify_inverse=False):
    N=int(train[0].sum());assert np.all(valid.sum(1)==N)
    fallback=max(0,min(T,math.floor(math.log2(N*epsilon**2/(10*M*M*math.log(8/ALPHA))))))
    predictors,coef=fits(train,pop,T)
    output={};inverse_cases=0
    for label,q in predictors.items():
        means=np.empty((len(train),T));tv=np.empty_like(means);vv=np.empty_like(means)
        tev=np.empty_like(means);vev=np.empty_like(means);true_wealth=np.empty_like(means)
        cached=[]
        for h in range(1,T+1):
            z,ct=histogram(train,pop,q[:,:,h-1],h)
            zv,cv=histogram(valid,pop,q[:,:,h-1],h)
            _,tv[:,h-1]=moments(z,ct);means[:,h-1],vv[:,h-1]=moments(zv,cv)
            support=M*(2**(h+1)-1)
            vt=(z+support)/(2*support);vval=(zv+support)/(2*support)
            tev[:,h-1]=pilot.evidence(vt,ct,epsilon/(2*support))
            vev[:,h-1]=pilot.evidence(vval,cv,epsilon/(2*support))
            target=np.full(len(train),(truth[h-1]+support)/(2*support))
            true_wealth[:,h-1]=np.maximum(bet.logwealth(vval,cv,target),bet.logwealth(1-vval,cv,1-target))
            if verify_inverse: cached.append((vval,cv,support))
        ec=eb_cap(tv,N,epsilon,fallback)
        eh,ew,inside=eb_select(vv,N,epsilon,ec,fallback)
        coverage=np.all((abs(means-truth)<=ew+1e-12)|~inside,axis=1)
        output['EB-'+label]=(eh,means,ec,coverage)
        bc=pilot.select_cap(tev,fallback)
        bh=pilot.select(vev,bc,fallback)
        h=np.arange(1,T+1)[None,:]
        coverage=np.all((true_wealth<=math.log(8/ALPHA)+(bc[:,None]-h)*math.log(2))|(h>bc[:,None]),axis=1)
        output['Bet-'+label]=(bh,means,bc,coverage)
        if verify_inverse:
            good=np.zeros((len(train),T),dtype=bool)
            for hi,(vval,cv,support) in enumerate(cached,1):
                ids=np.flatnonzero(bc>=hi)
                if not len(ids): continue
                alpha=(ALPHA/2)*2.**(hi-bc[ids]-1)
                lo,up=bet.betting_interval(vval[ids],cv[ids],alpha)
                center=(vval[ids]*cv[ids]).sum(1)/N
                radius=2*support*np.maximum(center-lo,up-center)
                good[ids,hi-1]=radius<epsilon
                inverse_cases+=len(ids)
            inverse=np.maximum(fallback,np.cumprod(good,axis=1).sum(1)).astype(int)
            np.testing.assert_array_equal(inverse,bh)
    return output,dict(inverse_cases=inverse_cases,fallback=fallback)

def checks():
    import itertools
    rng=np.random.default_rng(2026092572)
    expanded_rng=np.random.default_rng(2026092573)
    expanded_selections=0
    max_truth=max_var=max_fit=max_moment=0.;cases=0
    for T in [3,5,8]:
        for kappa in [0.,.9,1.]:
            p,truth=population(T,kappa);mass=p[:,5]
            np.testing.assert_allclose(mass.sum(),1.,atol=1e-14)
            # A separately enumerated complete action law checks compression.
            action_law={}
            for path in itertools.product([0,1],repeat=T):
                ell=next((i for i,a in enumerate(path) if a==0),T)
                key=(ell,sum(path));action_law[key]=action_law.get(key,0.)+2.**(-T)
            for (ell,total),expected in action_law.items():
                observed=mass[(p[:,0]==ell)&(p[:,1]==total)].sum()
                np.testing.assert_allclose(observed,expected,atol=1e-14)
            for h in range(1,T+1):
                R=2**h*(p[:,0]>=h)
                target=mass@(R*p[:,4]);max_truth=max(max_truth,abs(target-truth[h-1]))
                for mode in ['B','H']:
                    offset=A/2 if mode=='B' else truth[h-1]
                    q=kappa*B*p[:,2]+offset
                    z=q+R*(p[:,4]-q)
                    expected=kappa*kappa*B*B+2**h*(B*B*(1-kappa*kappa)+A*A*(T-h)/(4*T*T))
                    if mode=='B':expected+=(2**h-1)*(A*h/(2*T))**2
                    observed=mass@(z-target)**2
                    max_var=max(max_var,abs(observed-expected));cases+=1
            ct=rng.multinomial(96,mass,size=5)
            cv=expanded_rng.multinomial(96,mass,size=5)
            predictions,coef=fits(ct,p,T)
            for i in range(len(ct)):
                ids=np.repeat(np.arange(len(p)),ct[i]);expanded=p[ids]
                valid_expanded=p[np.repeat(np.arange(len(p)),cv[i])]
                design=np.column_stack([np.ones(len(ids)),expanded[:,2],expanded[:,1]/T])
                direct=np.linalg.lstsq(design,expanded[:,4],rcond=None)[0]
                max_fit=max(max_fit,float(np.max(abs(direct-coef[i]))))
                for mode,q in predictions.items():
                    direct_train=[];direct_valid=[];compressed_train=[];compressed_valid=[]
                    for h in range(1,T+1):
                        z,cc=histogram(ct[i:i+1],p,q[i:i+1,:,h-1],h)
                        mm,ss=moments(z,cc)
                        qe=q[i,((expanded[:,2]+1)/2).astype(int),h-1]
                        ze=qe+2**h*(expanded[:,0]>=h)*(expanded[:,4]-qe)
                        max_moment=max(max_moment,abs(mm[0]-ze.mean()),abs(ss[0]-ze.var(ddof=1)))
                        qv=q[i,((valid_expanded[:,2]+1)/2).astype(int),h-1]
                        zve=qv+2**h*(valid_expanded[:,0]>=h)*(valid_expanded[:,4]-qv)
                        zv,vc=histogram(cv[i:i+1],p,q[i:i+1,:,h-1],h)
                        _,vs=moments(zv,vc)
                        direct_train.append(ze.var(ddof=1));direct_valid.append(zve.var(ddof=1))
                        compressed_train.append(ss[0]);compressed_valid.append(vs[0])
                    # Independent scalar implementation, with thresholds that
                    # exercise both empty and nonempty reports on small samples.
                    def direct_radius(variance,j,k):
                        lam=math.log(16/ALPHA)+(k-j)*math.log(2)
                        return math.sqrt(2*variance*lam/96)+7*(2*M*(2**(j+1)-1))*lam/(3*95)
                    for epsilon in [.5,2.,5.,10.]:
                        cap=0
                        for k in range(1,T+1):
                            if all(direct_radius(direct_train[j-1],j,k)<=epsilon for j in range(1,k+1)):
                                cap=k
                        selected=0
                        for j in range(1,cap+1):
                            if direct_radius(direct_valid[j-1],j,cap)>epsilon:break
                            selected=j
                        computed_cap=eb_cap(np.array([compressed_train]),96,epsilon,0)
                        computed_h,_,_=eb_select(np.array([compressed_valid]),96,epsilon,computed_cap,0)
                        assert int(computed_cap[0])==cap and int(computed_h[0])==selected
                        expanded_selections+=1
    assert max_truth<1e-12 and max_var<1e-10 and max_fit<1e-10 and max_moment<1e-9
    inverse=0
    for n in [65536,262144,1048576]:
        for kappa in [0.,.9,1.]:
            p,truth=population(16,kappa)
            ct=rng.multinomial(n//2,p[:,5],size=3);cv=rng.multinomial(n//2,p[:,5],size=3)
            _,info=evaluate(ct,cv,p,truth,16,verify_inverse=True)
            inverse+=info['inverse_cases']
    return dict(populations_enumerated=9,population_variance_cases=cases,
        max_truth_error=max_truth,max_variance_error=max_var,max_fit_error=max_fit,
        max_expanded_moment_error=max_moment,expanded_eb_cap_and_selection_cases=expanded_selections,
        independent_interval_inversions=inverse)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=ROOT/'results')
    parser.add_argument('--check',action='store_true');args=parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True);start=time.time()
    result=checks();(args.out/'checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    if args.check:print(json.dumps(result,indent=2));return
    reps=500;T=16;rows=[];records=[];paired=[];survival=[]
    protocol_hash=bet.sha(ROOT/'PROTOCOL.md')
    for n in [65536,262144,1048576]:
        for kappa in [0.,.9,1.]:
            pop,truth=population(T,kappa)
            rng=np.random.default_rng(np.random.SeedSequence([2026092571,n,round(1000*kappa)]))
            train=rng.multinomial(n//2,pop[:,5],size=reps)
            valid=rng.multinomial(n//2,pop[:,5],size=reps)
            output,_=evaluate(train,valid,pop,truth,T)
            base=dict(n=n,T=T,kappa=kappa,epsilon=EPS)
            for name,(hh,est,cap,cov) in output.items():
                selected=np.arange(1,T+1)[None,:]<=hh[:,None]
                error=np.max(np.where(selected,abs(est-truth),0.),axis=1)
                success=error<=EPS+1e-12
                rows.append(dict(base,method=name,repetitions=reps,mean_h=float(hh.mean()),
                    h_mcse=float(hh.std(ddof=1)/math.sqrt(reps)),empirical_h90=bet.frequent_horizon(hh,T),
                    mean_cap=float(cap.mean()),selected_accuracy=float(success.mean()),
                    candidate_coverage=float(cov.mean()),abstention=float(np.mean(hh==0)),error_q95=float(np.quantile(error,.95))))
                for i in range(reps):
                    records.append(dict(base,method=name,replicate=i,H=int(hh[i]),cap=int(cap[i]),
                        selected_max_error=float(error[i]),selected_success=bool(success[i]),candidate_coverage=bool(cov[i])))
                for h in range(1,T+1):
                    num=int(np.sum(hh>=h));lo,hi=bet.wilson(num,reps)
                    survival.append(dict(base,method=name,horizon=h,successes=num,repetitions=reps,
                        reporting_frequency=num/reps,wilson_lower=lo,wilson_upper=hi))
            for a,b in [('EB-H','EB-B'),('Bet-H','Bet-B'),('Bet-B','EB-B'),('Bet-H','EB-H')]:
                delta=output[a][0]-output[b][0]
                paired.append(dict(base,comparison=a+' minus '+b,mean_difference=float(delta.mean()),
                    difference_mcse=float(delta.std(ddof=1)/math.sqrt(reps)),fraction_longer=float(np.mean(delta>0))))
            print(n,kappa,{k:float(v[0].mean()) for k,v in output.items()},flush=True)
    for name,data in [('summary.csv',rows),('paired.csv',paired),('survival.csv',survival),('replicates.csv.gz',records)]:
        bet.save_csv(args.out/name,data)
    assert bet.sha(ROOT/'PROTOCOL.md')==protocol_hash
    metadata=dict(python=platform.python_version(),numpy=np.__version__,system=platform.system(),processor=platform.processor(),
        elapsed_seconds=time.time()-start,openblas_threads=os.getenv('OPENBLAS_NUM_THREADS'),omp_threads=os.getenv('OMP_NUM_THREADS'),
        protocol_sha256=protocol_hash,source_sha256=bet.sha(Path(__file__)),new_datasets=reps*9,records=len(records),
        fixed_design=True,known_bound=M,alpha=ALPHA)
    (args.out/'environment.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(metadata,indent=2),flush=True)

if __name__=='__main__':main()
