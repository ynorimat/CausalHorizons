# Additive

Exact-count helpers for Y=.3V+.6 mean(A), with fair actions and a binary predictive baseline. The functions fit baseline and horizon predictors using training data, calculate moments and control candidate selection. The paper reports the six-method common-envelope comparison in action_adjustment, which uses these helpers and the same underlying seeds.

The settings were fixed before the corresponding runs, after inspecting related simulations. These designs are exploratory and were not independently preregistered.
