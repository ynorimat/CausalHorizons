# Code and results for certified causal horizons

Companion materials for **How Far Can We Estimate? Precision Limits and
Certified Causal Horizons**. The manuscript is `CausalHorizons_main.pdf`;
LaTeX sources are in `CausalHorizons_source.zip`.

## Contents and requirements

- `experiments/`: numerical methods, dated protocols, synthetic result records
  and numerical checks.
- `verification/`: recorded checks of numerical identities, paired records
  and manuscript values.
- `reproduce.py`: numerical checks and simulation replay entry point.
- `compact_support.py` and `RESTORE_MANIFEST.json`: exact regeneration of
  eight omitted detailed files.
- `SHA256SUMS`: hashes of the distributed files.

Use Python 3.12 and NumPy 2.3.5 (`python -m pip install -r requirements.txt`).
Unzip the complete archive and run commands from the directory containing
this README. Numerical checks require no TeX installation. Use a working
copy when running scripts that refresh result or audit files.

## Numerical checks and exact regeneration

```text
python reproduce.py check
```

This runs nine numerical check groups, binary theory checks, a 4000-record
conditional-mean C replay and an 8000-record O/S comparison. The interval
record audit is skipped until its detailed inputs have been restored.
Outputs are written under `work/`, and paired audit outputs are refreshed.

```text
python reproduce.py restore
python reproduce.py check-full
```

`restore` regenerates eight omitted files with the supplied programs, seeds
and settings under `work/`. It checks decompressed CSV content and every
NPZ array against `RESTORE_MANIFEST.json`, and compares 26 regenerated
summary/check files with the supplied records before installing missing
files. No network is needed. Detailed files use about 27 MB of compressed
storage; temporary files need additional space. Allow several minutes.
Use the pinned versions for exact floating-point comparisons.

`check-full` includes the 180000-record interval audit after restoration.
The supplied verification reports distinguish numerical checks from full
simulation replays. The full Monte Carlo suite was not rerun for the most
recent verification records in `verification/`.

```text
python reproduce.py replay
python reproduce.py replay-intervals
```

These run the full replay comparisons under `work/` (41 and 11 numerical
output files respectively), restoring missing inputs if necessary. Gzip
records are compared after decompression and NPZ files by their arrays.
Execution times and environment metadata can differ between computers.
Run `restore` before scripts consuming omitted detailed records, including
`reporting/run.py`, `intervals/run.py`, `intervals/focused.py`,
`intervals/audit.py` and `three_set/diagnostics.py`.

## Check manuscript values

With the source archive extracted:

```text
python check_manuscript.py --paper /path/to/source/paper
python experiments/numerical_diagnostics/run.py --paper /path/to/source/paper
```

The first command checks 91 Figure 1 coordinates and 383 displayed values
in Tables 2-5, including 40 S thresholds recomputed from survival counts.
The second checks Table 6 and the drift paragraph, recomputes mean lengths
and MCSEs from 50400 retained method records, evaluates Appendix B.6's bound
with 60-digit arithmetic, and checks 32 drift cases by finite enumeration.
Method records reuse datasets and are not 50400 independent datasets.
Both commands use only the standard library and leave simulation records
unchanged. Add `--write-tex` to the second command to regenerate its two
manuscript fragments. Its default output is
`experiments/numerical_diagnostics/results/`.

## Study map

| Manuscript material | Generator and records under `experiments/` |
|---|---|
| Figure 1; all 40 noise populations | `noise/`, `reporting/`, `intervals/theory_results/`, `intervals/focused_results/` |
| Tables 2 and 3; all 36 matched EB/betting conditions | `three_set/`, `intervals/` |
| Terminal noise comparison, same 1000 datasets | `intervals/focused.py`, `intervals/focused_results/` |
| Finite projection and sufficient bound, Appendix B.6 | `intervals/theory.py`, `intervals/theory_results/` |
| Table 4; fixed/fitted betting caps and contamination | `betting/`, `reporting/` |
| Full/half sample budgets and paired conditional means | `budgets/`, `paired/` |
| Table 5; action adjustment and growing grid; Appendices C.5 and D.5 | `action_adjustment/`, with `additive/` helpers |
| First-six-action effects, all 60 cells; Appendices C.5 and D.4 | `treatment/` |
| Table 6; continuous nonlinear baseline, eight tolerance cells / 48 method summaries | `noise/` |
| Nuisance-drift and table checks | `numerical_diagnostics/` |
| Shared exact-count and interval kernels | `kernels/`, `binary/` |
| Complete-condition numerical summaries | Each study's saved CSV files |
| Noisy action-dependent theory checks and reference method | `noisy_action/` |
| Interaction learner, oracle and omitted-feature comparisons; Appendices C.3 and D.1 | `three_set/` |
| Next-candidate stopping diagnosis | `three_set/diagnostics.py`, `three_set/results/stopping_*` |

## Data and provenance

All data are synthetic. These are exploratory studies, not independent
preregistrations. Each protocol and generator specifies its design and seed.
All condition-level summaries are retained, including unfavorable comparisons.
The omitted detailed files are listed in `RESTORE_MANIFEST.json`; their
values are regenerated without rounding or sampling fewer repetitions.
Methods share data within a comparison; two tolerances applied to one
dataset do not count as independent replications.

The matched interval study reuses the 18000 datasets from the three-set
study, yielding 180000 additional method/dataset/tolerance records. The
terminal comparison reuses 1000 datasets from the noise-rate study,
yielding 4000 EB/betting records. Neither adds independent datasets.
The protocols state that the EB results were known when these interval
comparisons were designed. All 40 noise populations, 36 matched interval
conditions and omitted-feature comparisons are supplied as summaries.

The PDF uses F0 for the fallback stored as `B` in noise/reporting records.
B denotes the baseline fit in the action-adjustment study. Record labels
are preserved so that the generators and saved data remain consistent.

Execution metadata retain the source/protocol hashes from their runs;
packaging changes do not rewrite this historical execution metadata.
The protocols likewise retain their original study descriptions. Current
supported entry points and package contents are documented in this README.
`SHA256SUMS` identifies the files as distributed. Metadata for the matched
and terminal interval studies were generated by a successful replay of
the distributed programs. Computational checks are supplied with each
study's results.

No release license is asserted; the manuscript checklist records that a code/data license is
unspecified.

## Detailed files regenerated by `restore`

- `experiments/action_adjustment/results/horizon_estimates.npz`
- `experiments/action_adjustment/results/replicates.csv.gz`
- `experiments/intervals/results/replicates.csv.gz`
- `experiments/noise/results/vanishing_replicates.csv.gz`
- `experiments/reporting/results/betting_replicates.csv.gz`
- `experiments/three_set/results/horizon_estimates.npz`
- `experiments/three_set/results/replicates.csv.gz`
- `experiments/treatment/results/replicates.csv.gz`
