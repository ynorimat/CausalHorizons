"""Compare Figure 1 and Tables 2-5 with the companion LaTeX source.

Usage: python check_manuscript.py --paper /path/to/manuscript/paper
Only the Python standard library is required; LaTeX is not executed.
"""
import argparse
import csv
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent


def records(relative):
    with (ROOT/'experiments'/relative).open(newline='', encoding='utf8') as stream:
        return list(csv.DictReader(stream))


def one(rows, **conditions):
    found = [r for r in rows if all(str(r[k]) == str(v) for k, v in conditions.items())]
    assert len(found) == 1, conditions
    return found[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--paper', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT/'work/manuscript_checks.json')
    args = parser.parse_args()
    paper = args.paper
    reporting = records('reporting/results/reporting_summary.csv')
    survival = records('reporting/results/reporting_survival.csv')
    ceilings = records('intervals/theory_results/noise_grid.csv')
    focused = records('intervals/focused_results/summary.csv')
    source = (paper/'figures/reporting_frontier.tex').read_text(encoding='utf8')
    plots = [[tuple(map(int, pair)) for pair in re.findall(r'\((\d+),(\d+)\)', block)]
             for block in re.findall(r'coordinates\s*\{([^}]+)\}', source)]
    expected = []
    for rate in ('0.0', '0.125', '0.25', '0.5'):
        pairs = []
        for exponent in range(14, 33, 2):
            row = one(reporting, s=rate, log2_n=exponent, method='S')
            threshold = max([0] + [int(r['horizon']) for r in survival
                if r['s'] == rate and r['log2_n'] == str(exponent)
                and r['method'] == 'S' and 10*int(r['successes']) >= 9*int(r['repetitions'])])
            assert threshold == int(row['empirical_h90'])
            pairs.append((exponent, threshold))
        expected.append(pairs)
    for method, field in [('O', 'empirical_h90'), ('S', 'empirical_h90'),
                          ('C', 'empirical_h90'), ('O', 'range_cap')]:
        expected.append([(e, int(one(reporting, s='0.25', log2_n=e, method=method)[field]))
                         for e in range(14, 33, 2)])
    expected.append([(e, int(one(ceilings, s='0.25', log2_n=e)['necessary_ceiling']))
                     for e in range(14, 33, 2)])
    expected.append([(32, int(one(focused, method='S-B')['h90']))])
    assert plots == expected, 'Figure 1 coordinates differ from retained results'

    interval = records('three_set/results/summary.csv') + records('intervals/results/summary.csv')
    table_values = 0
    table_rows = {}
    for filename, full in [('interval_main.tex', False), ('interval_all.tex', True)]:
        count = 0
        for line in (paper/'generated'/filename).read_text(encoding='utf8').splitlines():
            if not line.startswith(('Add.', 'Int.')): continue
            parts = [p.strip().rstrip('\\') for p in line.split('&')]
            law = 'additive' if parts[0] == 'Add.' else 'interaction'
            n, tau, tol, start = (int(parts[1]), float(parts[2]),
                                 'fixed' if parts[3] == 'F' else 'shrinking', 4) if full else (393216, float(parts[1]), 'fixed', 2)
            for method, cell in zip(('C', 'S', 'A2', 'A3'), parts[start:]):
                for suffix, displayed in zip(('', '-B'), cell.split('/')):
                    value = float(one(interval, law=law, n=n, tau=tau,
                                      tolerance=tol, method=method+suffix)['mean_h'])
                    assert abs(float(displayed)-value) <= 0.000500001, (filename, law, n, tau, method)
                    table_values += 1
            count += 1
        table_rows[filename] = count
    assert list(table_rows.values()) == [6, 36]

    betting = records('betting/results/summary.csv')
    budgets = records('budgets/results/summary.csv')
    lines = [line for line in (paper/'generated/pilot_main_table.tex').read_text(encoding='utf8').splitlines()
             if line.startswith(('$\\kappa=', 'Changing,'))]
    assert len(lines) == 4
    for population, line in zip(('noise', 'near', 'perfect', 'changing'), lines):
        displayed = [float(p.strip().rstrip('\\')) for p in line.split('&')[1:]]
        values = [float(one(betting, study='matched', population=population, method=m)['mean_h'])
                  for m in ('O', 'W', 'WA', 'S')]
        values.append(float(one(budgets, population=population, method='C_full')['mean_h']))
        assert len(displayed) == 5 and all(abs(x-y) <= 0.000500001 for x, y in zip(displayed, values))
        table_values += 5

    action = records('action_adjustment/results/summary.csv')
    count = 0
    for line in (paper/'generated/action_main.tex').read_text(encoding='utf8').splitlines():
        if not re.match(r'\d+\s*&', line): continue
        cells = [p.strip().rstrip('\\') for p in line.split('&')]
        n, kappa = 2**int(cells[0]), float(cells[1])
        for field, methods in zip(cells[2:], [('EB-B', 'EB-H', 'EB-A'), ('Bet-B',), ('Bet-H', 'Bet-A')]):
            for method in methods:
                value = float(one(action, study='matched', n=n, kappa=kappa, method=method)['mean_h'])
                assert abs(float(field)-value) <= 0.000500001
            table_values += 1
        count += 1
    assert count == 9 and table_values == 383
    report = dict(figure_coordinates=sum(map(len, plots)),
                  method_S_thresholds_checked_against_survival=40,
                  table_rows={'2': 6, '3': 36, '4': 4, '5': 9},
                  displayed_table_values=table_values,
                  all_passed=True,
                  scope='Figure coordinates and displayed table values; no simulation rerun.')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+'\n', encoding='utf8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
