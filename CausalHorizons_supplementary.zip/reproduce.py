"""Check implementations or replay reported numerical studies."""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
EXP=ROOT/'experiments'
WORK=ROOT/'work'
WORK.mkdir(exist_ok=True)
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')

def run(args,cwd=ROOT,log=None):
    if log:
        with log.open('w',encoding='utf-8') as f:
            p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
        if p.returncode:
            raise RuntimeError(log.read_text(encoding='utf-8',errors='replace')[-6000:])
    else:
        subprocess.run(args,cwd=cwd,check=True)

def python(path,*args): run([sys.executable,str(path),*map(str,args)])

def load(name):
    spec=importlib.util.spec_from_file_location('check_'+name,EXP/name/'run.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def check():
    # This checks numerical identities and replays C, not every simulation.
    before={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in EXP.glob('*/results/*')
            if p.is_file() and p.parent.parent.name!='paired'}
    results={}
    for name in ['noise','reporting','betting','treatment','additive','action_adjustment','noisy_action','three_set','intervals']:
        results[name]=load(name).checks()
        print('Checked '+name,flush=True)
    interval_inputs = [EXP/'intervals/results/replicates.csv.gz',
                       EXP/'three_set/results/horizon_estimates.npz']
    if all(path.exists() for path in interval_inputs):
        python(EXP/'intervals/audit.py')
    else:
        results['_skipped_checks'] = ['interval record audit: run check-full to restore detailed data first']
        print('Interval record audit skipped: compact package; use check-full for this audit.', flush=True)
    python(EXP/'binary/check_theory.py')
    python(EXP/'paired/report.py','--replay-c')
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==h for p,h in before.items())
    (WORK/'checks.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print('Numerical checks and 4000-record C replay passed; saved simulation results unchanged.',flush=True)

def equal(a,b):
    if a.suffix=='.gz': return gzip.decompress(a.read_bytes())==gzip.decompress(b.read_bytes())
    if a.suffix=='.npz':
        import numpy as np
        with np.load(a) as x,np.load(b) as y:
            return x.files==y.files and all(np.array_equal(x[k],y[k]) for k in x.files)
    return a.read_bytes()==b.read_bytes()

def replay():
    # Recompute the paper's reported experiments into a separate directory.
    scope={
      'noise':['continuous_paired.csv','continuous_replicates.csv.gz','continuous_summary.csv','vanishing_replicates.csv.gz','vanishing_summary.csv','checks.json'],
      'budgets':['paired.csv','replicates.csv.gz','summary.csv','checks.json'],
      'reporting':['reporting_summary.csv','reporting_survival.csv','betting_summary.csv','betting_paired.csv','betting_replicates.csv.gz','checks.json'],
      'betting':['summary.csv','paired.csv','survival.csv','replicates.csv.gz','checks.json'],
      'treatment':['summary.csv','paired.csv','survival.csv','replicates.csv.gz','checks.json'],
      'action_adjustment':['summary.csv','paired.csv','survival.csv','diagnostics.csv','replicates.csv.gz','checks.json','horizon_estimates.npz'],
      'noisy_action':['checks.json'],
      'three_set':['checks.json','summary.csv','paired.csv','prediction_risks.csv',
                   'survival.csv','replicates.csv.gz','horizon_estimates.npz']}
    compared={}
    for name,files in scope.items():
        out=WORK/'replay'/name
        out.mkdir(parents=True,exist_ok=True)
        if name=='noise':
            module=load(name);module.OUT=out
            (out/'checks.json').write_text(json.dumps(module.checks(),indent=2)+'\n',encoding='utf-8')
            module.continuous();module.vanishing()
        elif name=='budgets':
            module=load(name)
            # The budget generator accepts its output directory in main.
            python(EXP/name/'run.py','--out',out)
        else:
            python(EXP/name/'run.py','--out',out)
        for filename in files:
            assert equal(EXP/name/'results'/filename,out/filename),(name,filename)
            compared[name+'/'+filename]=True
        print('Replayed '+name,flush=True)
    (WORK/'replay_checks.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')

def replay_intervals():
    out=WORK/'replay_intervals'
    python(EXP/'intervals/run.py','--out',out/'results')
    python(EXP/'intervals/focused.py','--out',out/'focused_results')
    python(EXP/'intervals/theory.py','--out',out/'theory_results')
    compared=[]
    for sub,files in {
      'results':['summary.csv','paired.csv','survival.csv','replicates.csv.gz'],
      'focused_results':['summary.csv','replicates.csv'],
      'theory_results':['bounds.csv','noise_grid.csv','witnesses.json','figure_witness.json','checks.json']}.items():
        for file in files:
            assert equal(EXP/'intervals'/sub/file,out/sub/file),(sub,file)
            compared.append(sub+'/'+file)
    (WORK/'interval_replay_checks.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')
    print('Matched interval and finite-bound replay passed: '+str(len(compared))+' files.',flush=True)

def restore():
    from compact_support import restore as restore_records
    restore_records(ROOT)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('mode',nargs='?',default='check',choices=['check','restore','check-full','replay','replay-intervals'])
    mode=p.parse_args().mode
    if mode in ['restore','check-full','replay','replay-intervals']:
        restore()
    if mode != 'restore':
        {'check':check,'check-full':check,'replay':replay,'replay-intervals':replay_intervals}[mode]()
