"""Restore omitted synthetic records using the original experiment programs."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import uuid


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(path, reference):
    if reference['kind'] == 'gzip':
        actual = sha(gzip.decompress(path.read_bytes()))
        if actual != reference['uncompressed_sha256']:
            raise ValueError('Decompressed CSV content differs: '+path.name)
    elif reference['kind'] == 'npz':
        import numpy as np
        with np.load(path, allow_pickle=False) as arrays:
            if set(arrays.files) != set(reference['arrays']):
                raise ValueError('Array names differ: '+path.name)
            for key, expected in reference['arrays'].items():
                value = arrays[key]
                actual = dict(dtype=value.dtype.str, shape=list(value.shape),
                              sha256=sha(value.tobytes(order='C')))
                if actual != expected:
                    raise ValueError('Array content differs: '+path.name+' / '+key)
    else:
        raise ValueError('Unknown reference format')


def restore(root):
    root = Path(root).resolve()
    manifest = json.loads((root/'RESTORE_MANIFEST.json').read_text(encoding='utf-8'))
    references = manifest['omitted_files']
    missing = []
    for relative, reference in references.items():
        target = root/relative
        if target.exists():
            verify(target, reference)
        else:
            missing.append(relative)
    if not missing:
        print('All eight detailed files are present and verified.', flush=True)
        return

    # Recreate dependencies together, leaving distributed summaries untouched.
    scratch = root/'work'/('restore_'+uuid.uuid4().hex[:12])
    scratch.mkdir(parents=True)
    shutil.copytree(root/'experiments', scratch/'experiments',
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
               PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    print('Restoring detailed files in '+scratch.relative_to(root).as_posix()+'.', flush=True)
    for name in ['noise', 'reporting', 'treatment', 'action_adjustment', 'three_set', 'intervals']:
        log = scratch/(name+'.log')
        with log.open('w', encoding='utf-8') as stream:
            completed = subprocess.run([sys.executable, 'experiments/'+name+'/run.py'],
                                       cwd=scratch, env=env, stdout=stream,
                                       stderr=subprocess.STDOUT)
        if completed.returncode:
            raise RuntimeError('Regeneration failed for '+name+':\n'+
                               log.read_text(encoding='utf-8', errors='replace')[-6000:])
        print('Regenerated '+name+'.', flush=True)

    try:
        for relative, reference in references.items():
            verify(scratch/relative, reference)
        for relative, expected in manifest['retained_comparisons'].items():
            if sha((scratch/relative).read_bytes()) != expected:
                raise ValueError('Regenerated numerical output differs: '+relative)
    except ValueError as exc:
        raise RuntimeError(str(exc)+'. Use the documented Python 3.12 / NumPy 2.3.5 runtime. '
                           'No omitted files have been installed.') from exc

    # Install only missing records after every comparison has succeeded.
    for relative in missing:
        target = root/relative
        if target.exists():
            verify(target, references[relative])
            continue
        shutil.copy2(scratch/relative, target)
    report = dict(restored=missing, verified_detailed_files=len(references),
                  compared_summary_files=len(manifest['retained_comparisons']),
                  generated_in=scratch.relative_to(root).as_posix())
    (root/'work/restoration_checks.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print('Restoration verified: eight detailed files and '+
          str(len(manifest['retained_comparisons']))+' numerical summary/check files.', flush=True)
